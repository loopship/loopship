# fastflow

`@cueintent/fastflow` is a portable workflow compiler, catalog resolver,
deterministic scheduler, and AFN executor protocol. A single root workflow can
compose signed Loopship, Fastbrowser, and other registry workflows. The root is
declarative YAML/IR composition; one scheduler authority owns each execution.

Consumer code never loads into the scheduler. Browser, macOS, mobile, Git,
process, inference, provider, and filesystem effects run behind exact AFN
contracts on authenticated executor nodes.

## Federated node configuration

```js
import { configureFastflowNode } from "@cueintent/fastflow";

configureFastflowNode({
  identity,
  roles: ["scheduler"],
  catalogs: { mounts, registry },
  platform: {
    executionStore,
    authority,
    wake,
    clock,
    random,
    crypto,
    catalogStore: registry,
    capabilityEvidence,
  },
  trust: { mode: "production", ownerPolicy },
  connectivity: { directWss: { listen, dial }, relayRendezvous: rendezvous },
  executors: [],
});
```

Roles are `compiler`, `scheduler`, `executor`, `gateway`, and `dashboard`.
The Bun process-local runtime shell is an internal implementation detail used
by authoring and executor integrations; it is not a public node configuration
API and does not add a second workflow or scheduler model. Node deployments
use `configureFastflowNode`.

The public contracts are:

- `fastflow.catalog-bundle/v1`: signed contract-only catalog closure;
- `fastflow.workflow-ir/v1`: deterministic pure-JSON workflow IR;
- `fastflow.pinned-plan/v4`: exact closure and contract-pinned execution plan;
- `fastflow.afn-offer/v1`: leased executor capability offer;
- `fastflow.resource-handle/v1` and `fastflow.resource-lease/v1`: typed,
  owner-bound stateful resources; and
- `fastflow.scheduler-afn-assignment/v1`: atomic assignment and dispatch
  identity.

Mount tables map registry names to exact signed bundle digests, so one closure
can call `loopship.workflow.*` and `fastbrowser.workflow.*`. Catalog bundles
contain contract schemas and semantics, never implementation registries or
executor facts. Implementation provenance is verified by scheduler trust policy
when an authenticated offer is admitted. The scheduler selects a compatible
offer and records the implementation and executor atomically at assignment.

No eligible offer means a durable wait. Typed resource handles keep browser
profiles, worktrees, devices, and provider sessions on their owning executor.
Reassignment is allowed only when the contract replay policy permits it.

## Protocol and topology

The current v2 session is one typed Protobuf protocol over WSS with frames:
`HELLO`, `PAIR`, `OFFER`, `WITHDRAW`, `ASSIGN`, `ACK`, `RESULT`, `SIGNAL`,
`HEARTBEAT`, and `CLOSE`. The scheduler and executor may dial directly in
either direction, or both may dial an ephemeral rendezvous relay. The relay
forwards authenticated frames and stores no workflow, assignment, mailbox, or
catalog state. Scheduler storage is never public.

`createAfnWssSessionTopology` exposes the platform shell for these direct and
rendezvous paths through injected carrier ports. It does not select a carrier,
persist relay state, or replace scheduler admission.

Remote sessions require key possession, fresh credentials, enrollment,
authorization, implementation provenance, and revocation checks. Personal
pairing is invite-only and single-use. Invocation consent remains separate from
node enrollment.

## Runtime boundary

The kernel boundary is:

```text
current state + authoritative event -> state changes + commands
```

The kernel imports no platform APIs, opens no storage or socket, reads no
ambient clock, and schedules no native timer. Bun/SQLite is the first durable
authority. Cloudflare Durable Objects provide the same atomic authority and
alarm semantics. The injected Cloudflare Computer preview adapter is the
preferred evaluation target for stateful executor work. Its `container` backend
is internal adapter plumbing; direct Cloudflare Containers remain a separately
gated fallback. Worker/HTTP and Browser Rendering source adapters exist;
provider instantiation, deployment, and placement remain gated work.
Browser, mobile, and MCU runtimes may pause safely while inactive and make no
background-liveness claim while suspended or powered off.

## Public commands

```bash
fastflow workflows run <workflow-ref> --json '{"input":"value"}'
fastflow workflows resume <execution-id> --nonce <nonce>
fastflow workflows calls list --registry fastbrowser
fastflow secrets session status --store bitwarden-cli
fastflow secrets session migrate --store bitwarden-cli
fastflow snapshots capture --json '{"label":"checkpoint"}'
fastflow scaffold sample-app --dir ./sample-app
fastflow cmdproto execjson workflows run '{"workflowRef":"...","inputs":{}}'
```

The `fastflow-bw` entrypoint runs Bitwarden through the vendored Secret Manager
helper and Fastflow's app-scoped secure profile. Fastflow deployment and
verification paths use it so a bare Bitwarden process never needs access to the
app-scoped session or credential material. Run `secrets session migrate`
explicitly when `status` reports that a legacy profile must be moved.

## Development checks

```bash
npm test
npm run proto:check
npm run test:types
npm run test:afn-interop
npm run release-artifacts:check
```

HITL relay coverage uses managed headless Chrome/CDP. `npm test` does not open a
visible system browser.

See [the architecture contract](./docs/federated-fastflow-nodes.md),
[platform support](./docs/platform-support.md), and
[security](./docs/security-and-migration.md).
