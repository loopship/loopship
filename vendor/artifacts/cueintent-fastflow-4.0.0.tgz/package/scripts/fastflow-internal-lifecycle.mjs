#!/usr/bin/env bun

import {
  assertCanonicalBunApplicationRuntime,
} from "../src/lib/application-runtime.mjs";
import { configureFastflowRuntime } from "../src/lib/runtime-shell.mjs";

assertCanonicalBunApplicationRuntime("Fastflow internal lifecycle CLI");

const { fileURLToPath } = await import("node:url");
const {
  executeFastflowInternalWorkflowDevSeedRequest,
  executeFastflowInternalWorkflowPromoteRequest,
  executeFastflowInternalReleaseKeyRequest,
  executeFastflowInternalWorkflowValidationRequest,
  listFastflowInternalLifecycleCommands,
} = await import("../src/internal/workflow-lifecycle.mjs");

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try {
    const result = await runInternalLifecycle(
      process.argv.slice(2),
      configureFastflowRuntime(),
    );
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  } catch (error) {
    process.stderr.write(`${error?.message || String(error)}\n`);
    process.exitCode = 1;
  }
}

export async function runInternalLifecycle(
  argv = [],
  hostRuntime = configureFastflowRuntime(),
) {
  const args = [...argv];
  if (args[0] === "internal") {
    args.shift();
  }
  const command = args.join(" ");
  if (command === "commands list") {
    return listFastflowInternalLifecycleCommands();
  }
  if (args[0] === "release-key") {
    return executeFastflowInternalReleaseKeyRequest(
      parseReleaseKeyArgs(args.slice(1)),
    );
  }
  if (args[0] !== "workflows") {
    throw new Error("Expected internal workflows lifecycle or release-key command.");
  }
  if (args[1] === "validate") {
    return executeFastflowInternalWorkflowValidationRequest(
      parseValidateArgs(args.slice(2)),
      hostRuntime,
    );
  }
  if (args[1] === "dev" && args[2] === "seed") {
    const workflowRef = args[3];
    if (!workflowRef || workflowRef.startsWith("-")) {
      throw new Error("internal workflows dev seed requires a workflow ref.");
    }
    return executeFastflowInternalWorkflowDevSeedRequest(
      { workflowRef },
      hostRuntime,
    );
  }
  if (args[1] === "promote") {
    return executeFastflowInternalWorkflowPromoteRequest(
      parsePromoteArgs(args.slice(2)),
      hostRuntime,
    );
  }
  throw new Error(`Unknown internal lifecycle command: ${command}`);
}

function parseReleaseKeyArgs(args) {
  const request = {};
  while (args.length > 0) {
    const token = args.shift();
    if (token === "--refresh") {
      request.refresh = true;
      continue;
    }
    if (token === "--full") {
      request.cacheOnly = false;
      continue;
    }
    if (token === "--cache-only") {
      request.cacheOnly = true;
      continue;
    }
    if (token === "--generate") {
      request.generate = true;
      continue;
    }
    if (token === "--import-bitwarden") {
      request.importBitwarden = true;
      continue;
    }
    if (token === "--no-import-bitwarden") {
      request.importBitwarden = false;
      continue;
    }
    if (token === "--store-bitwarden") {
      request.storeBitwarden = true;
      continue;
    }
    if (token === "--no-store-bitwarden") {
      request.storeBitwarden = false;
      continue;
    }
    if (token === "--publish") {
      request.publish = true;
      continue;
    }
    if (token === "--no-publish") {
      request.publish = false;
      continue;
    }
    if (token === "--configure-git") {
      request.configureGit = true;
      continue;
    }
    if (token === "--no-configure-git") {
      request.configureGit = false;
      continue;
    }
    if (token === "--repo-root") {
      request.repoRoot = requireValue(args.shift(), token);
      continue;
    }
    if (token === "--provider") {
      request.provider = requireValue(args.shift(), token);
      continue;
    }
    if (token === "--host") {
      request.host = requireValue(args.shift(), token);
      continue;
    }
    if (token === "--user") {
      request.user = requireValue(args.shift(), token);
      continue;
    }
    if (token === "--name") {
      request.name = requireValue(args.shift(), token);
      continue;
    }
    if (token === "--email") {
      request.email = requireValue(args.shift(), token);
      continue;
    }
    if (token === "--bitwarden-item") {
      request.bitwardenItem = requireValue(args.shift(), token);
      continue;
    }
    const assignment = readLongOptionAssignment(token);
    if (assignment) {
      const [name, value] = assignment;
      if (name === "repo-root") {
        request.repoRoot = value;
        continue;
      }
      if (name === "provider") {
        request.provider = value;
        continue;
      }
      if (name === "host") {
        request.host = value;
        continue;
      }
      if (name === "user") {
        request.user = value;
        continue;
      }
      if (name === "name") {
        request.name = value;
        continue;
      }
      if (name === "email") {
        request.email = value;
        continue;
      }
      if (name === "bitwarden-item") {
        request.bitwardenItem = value;
        continue;
      }
    }
    if (token?.startsWith("-")) {
      throw new Error(`Unknown internal release-key option: ${token}`);
    }
    if (!request.path) {
      request.path = token;
      continue;
    }
    throw new Error(`Unexpected internal release-key argument: ${token}`);
  }
  if (!request.path) {
    throw new Error("internal release-key requires a release-auth policy path.");
  }
  return request;
}

function readLongOptionAssignment(token) {
  if (!token?.startsWith("--") || !token.includes("=")) {
    return null;
  }
  const index = token.indexOf("=");
  return [token.slice(2, index), token.slice(index + 1)];
}

function parseValidateArgs(args) {
  const request = {};
  while (args.length > 0) {
    const token = args.shift();
    if (token === "--mode") {
      request.mode = args.shift();
      continue;
    }
    if (token === "--workflow-path") {
      request.workflowPath = args.shift();
      continue;
    }
    if (token === "--fix") {
      request.fix = true;
      continue;
    }
    throw new Error(`Unknown internal workflows validate option: ${token}`);
  }
  return request;
}

function parsePromoteArgs(args) {
  const workflowRefs = [];
  let summary = null;
  while (args.length > 0) {
    const token = args.shift();
    if (token === "--workflow-ref") {
      workflowRefs.push(requireValue(args.shift(), token));
      continue;
    }
    if (token === "--summary") {
      summary = requireValue(args.shift(), token);
      continue;
    }
    if (token?.startsWith("--summary=")) {
      summary = token.slice("--summary=".length);
      continue;
    }
    if (token?.startsWith("-")) {
      throw new Error(`Unknown internal workflows promote option: ${token}`);
    }
    workflowRefs.push(token);
  }
  if (workflowRefs.length === 0) {
    throw new Error("internal workflows promote requires a workflow ref.");
  }
  return {
    workflowRef: workflowRefs[0],
    workflowRefs: workflowRefs.slice(1),
    ...(summary ? { summary } : {}),
  };
}

function requireValue(value, flag) {
  if (!value || value.startsWith("-")) {
    throw new Error(`${flag} requires a value.`);
  }
  return value;
}
