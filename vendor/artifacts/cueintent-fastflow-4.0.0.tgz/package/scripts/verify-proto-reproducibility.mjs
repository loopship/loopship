#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, readdir, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const temporary = await mkdtemp(path.join(os.tmpdir(), "fastflow-proto-reproducible-"));

try {
  const generated = [];
  for (const label of ["first", "second"]) {
    const output = path.join(temporary, label);
    const template = path.join(temporary, `${label}.json`);
    await writeFile(template, `${JSON.stringify({
      version: "v2",
      clean: true,
      plugins: [{
        local: path.join(root, "node_modules", ".bin", "protoc-gen-es"),
        out: output,
        include_imports: true,
        opt: ["target=js+dts", "import_extension=js"],
      }],
      inputs: [{ directory: "proto" }],
    }, null, 2)}\n`);
    execFileSync("buf", ["generate", "--template", template], {
      cwd: root,
      stdio: "inherit",
    });
    generated.push(await digestTree(output));
  }
  assertSameTree(generated[0], generated[1], "two clean Protobuf generations differ");
  assertSameTree(
    generated[0],
    await digestTree(path.join(root, "src", "gen")),
    "src/gen differs from a clean Protobuf generation",
  );
  execFileSync(process.execPath, ["scripts/generate-afn-goldens.mjs"], {
    cwd: root,
    stdio: "inherit",
  });
} finally {
  await rm(temporary, { recursive: true, force: true });
}

async function digestTree(directory) {
  const result = new Map();
  await visit(directory, "", result);
  return result;
}

async function visit(directory, relativeDirectory, result) {
  const entries = await readdir(path.join(directory, relativeDirectory), {
    withFileTypes: true,
  });
  for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
    const relativePath = path.join(relativeDirectory, entry.name);
    if (entry.isDirectory()) await visit(directory, relativePath, result);
    else if (entry.isFile()) {
      result.set(
        relativePath.split(path.sep).join("/"),
        createHash("sha256").update(await readFile(path.join(directory, relativePath))).digest("hex"),
      );
    }
  }
}

function assertSameTree(left, right, message) {
  const leftEntries = JSON.stringify([...left]);
  const rightEntries = JSON.stringify([...right]);
  if (leftEntries !== rightEntries) throw new Error(message);
}
