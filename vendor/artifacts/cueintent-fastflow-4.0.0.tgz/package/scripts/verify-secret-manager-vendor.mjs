#!/usr/bin/env node

import { createHash } from "node:crypto";
import { existsSync, readFileSync, readdirSync, lstatSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const EXPECTED_COMMIT = "88290f653484bc3b76bb8fa36997494cfeb324ad";
const EXPECTED_CHECKOUT_PROJECTION_SHA256 =
  "d20a96502904f523570b5e4c397765240c8c31465f6172baeb6d9d51263f34a6";
const EXPECTED_PACKED_PROJECTION_SHA256 =
  "71184ebef228964d4fee5e66f8f0e77d5100f7101b49b001b9495e6a59d3371b";
const NORMALIZED_DELTAS = Object.freeze({
  "src/index.d.ts": Object.freeze({
    producerBlobSha1: "51e80e8117d4897d3b85c03bac7a5375823cd6d6",
    vendoredBlobSha1: "1e9c8ba9dd61d8916030ee4545c26075738c4457",
    reason: "Expose the implemented child exit signal and enrollment receipt discriminator to TypeScript consumers.",
  }),
});
const PACK_OMITTED_PATHS = new Set([
  ".gitignore",
  ".npmignore",
  "tsconfig.types.json",
  "scripts/ensure-cmdproto-deps.mjs",
  "scripts/verify-cmdproto-assets.mjs",
  "scripts/verify-proto-reproducibility.mjs",
]);
const SOURCE_ONLY_PATHS = [...PACK_OMITTED_PATHS, "test"];
const REQUIRED_EXPORTS = [
  "migrateSecretStoreProfile",
  "spawnBitwardenCli",
];

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const snapshotRoot = path.join(root, "vendor", "secret-manager");
const manifestPath = path.join(snapshotRoot, "package.json");
const provenancePath = path.join(snapshotRoot, "VENDORED_COMMIT");
const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
if (manifest.name !== "@cueintent/secret-manager") {
  throw new Error(
    `Fastflow vendored Secret Manager snapshot is invalid (expected @cueintent/secret-manager, got ${manifest.name || "unknown"}).`,
  );
}
const provenance = readFileSync(provenancePath, "utf8").trim();
if (provenance !== EXPECTED_COMMIT) {
  throw new Error(
    `Fastflow expects Secret Manager commit ${EXPECTED_COMMIT}, got ${provenance}.`,
  );
}

const entries = [];
visit(snapshotRoot, "");
const checkoutLayout = existsSync(path.join(root, ".git")) ||
  SOURCE_ONLY_PATHS.some((relative) => existsSync(path.join(snapshotRoot, relative)));
const selectedEntries = entries.filter((entry) =>
  entry.path !== "VENDORED_COMMIT" &&
  (checkoutLayout || !isPackedOmitted(entry.path)),
);
const digest = createHash("sha256");
for (const entry of selectedEntries.sort((left, right) =>
  left.path < right.path ? -1 : left.path > right.path ? 1 : 0
)) {
  const vendoredBlobSha1 = gitBlobSha1(entry.filename);
  const delta = NORMALIZED_DELTAS[entry.path];
  if (delta && vendoredBlobSha1 !== delta.vendoredBlobSha1) {
    throw new Error(`Fastflow Secret Manager normalized delta '${entry.path}' is not the reviewed version.`);
  }
  digest.update(`${entry.path}\0${entry.mode}\0${delta?.producerBlobSha1 || vendoredBlobSha1}\n`);
}
const actualDigest = digest.digest("hex");
const expectedDigest = checkoutLayout
  ? EXPECTED_CHECKOUT_PROJECTION_SHA256
  : EXPECTED_PACKED_PROJECTION_SHA256;
if (actualDigest !== expectedDigest) {
  const layout = checkoutLayout ? "checkout" : "packed";
  throw new Error(
    `Fastflow ${layout} Secret Manager snapshot does not match ${EXPECTED_COMMIT} outside its reviewed normalized deltas (expected ${expectedDigest}, got ${actualDigest}).`,
  );
}

const implementation = await import(
  pathToFileURL(path.join(snapshotRoot, "src", "index.mjs")).href
);
for (const name of REQUIRED_EXPORTS) {
  if (typeof implementation[name] !== "function") {
    throw new Error(`Fastflow vendored Secret Manager snapshot does not export ${name}.`);
  }
}

function visit(directory, relativeDirectory) {
  for (const name of readdirSync(directory).sort()) {
    const filename = path.join(directory, name);
    const relative = path.posix.join(relativeDirectory, name);
    const stat = lstatSync(filename);
    if (stat.isSymbolicLink()) {
      throw new Error(`Fastflow vendored Secret Manager snapshot contains a symlink: ${relative}`);
    }
    if (stat.isDirectory()) {
      visit(filename, relative);
    } else if (stat.isFile()) {
      entries.push({
        path: relative,
        filename,
        mode: (stat.mode & 0o111) === 0 ? "100644" : "100755",
      });
    } else {
      throw new Error(`Fastflow vendored Secret Manager snapshot contains an unsupported file: ${relative}`);
    }
  }
}

function isPackedOmitted(relative) {
  return PACK_OMITTED_PATHS.has(relative) || relative.startsWith("test/");
}

function gitBlobSha1(filename) {
  const contents = readFileSync(filename);
  return createHash("sha1")
    .update(`blob ${contents.length}\0`)
    .update(contents)
    .digest("hex");
}
