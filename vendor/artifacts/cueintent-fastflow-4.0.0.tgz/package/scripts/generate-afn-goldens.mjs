#!/usr/bin/env node

import { spawnSync } from "node:child_process";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  AFN_SESSION_V3_PROTOCOL_VERSION,
  AFN_SESSION_V3_SCHEMA_VERSION,
  createFastflowSessionFrame,
  encodeFastflowSessionFrame,
} from "../src/lib/afn-session-v3-codec.mjs";
import { sha256Hex } from "../src/lib/sha256.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const fixtureDirectory = path.join(root, "test", "fixtures", "afn-v3");
const write = process.argv.includes("--write");
const temporary = await mkdtemp(path.join(os.tmpdir(), "fastflow-afn-goldens-"));

try {
  const digest = `sha256:${"a".repeat(64)}`;
  const meta = (sequence) => ({
    schemaVersion: AFN_SESSION_V3_SCHEMA_VERSION,
    senderNodeId: "scheduler-fixture",
    recipientNodeId: "executor-fixture",
    sessionId: "fixture-session",
    sessionEpoch: 1,
    sequence,
    acknowledgedSequence: sequence - 1,
    issuedAt: "2026-08-16T00:00:00.000Z",
    expiresAt: "2026-08-16T00:05:00.000Z",
    keyId: "fixture-key",
    proof: "fixture-proof",
  });
  const frame = (type, payload, sequence) => createFastflowSessionFrame({
    type,
    payload: { meta: meta(sequence), ...payload },
  });
  const frames = new Map([
    ["hello.bin", frame("HELLO", {
      protocolVersion: AFN_SESSION_V3_PROTOCOL_VERSION,
      nodeRole: "executor",
      previousSessionId: "",
    }, 1)],
    ["offer.bin", frame("OFFER", {
      offerId: "fixture-offer",
      executorNodeId: "executor-fixture",
      expiresAt: "2026-08-16T00:04:00.000Z",
      maxInFlight: 1,
      available: 1,
      capabilities: [{
        callId: "fixture.afn.echo",
        contractDigest: digest,
        implementationDigest: digest,
        qualifiers: {},
        resourceHandles: [],
      }],
      offerDigest: digest,
    }, 2)],
    ["assign.bin", frame("ASSIGN", {
      executionId: "fixture-execution",
      workflowNodeId: "root/echo",
      invocationId: "fixture-invocation",
      attempt: 1,
      callId: "fixture.afn.echo",
      contractDigest: digest,
      executorNodeId: "executor-fixture",
      implementationDigest: digest,
      offerDigest: digest,
      assignmentDigest: digest,
      resourceLeases: [],
      input: { value: "fixture" },
      effectKey: "fixture-effect",
      routingMode: "capability-pool",
      replayPolicy: "idempotent",
      selectorDigest: digest,
    }, 3)],
    ["result.bin", frame("RESULT", {
      invocationId: "fixture-invocation",
      attempt: 1,
      assignmentDigest: digest,
      kind: "completed",
      output: JSON.parse('{"value":"fixture","empty":[],"none":null,"off":false,"zero":0,"blank":"","__proto__":{"nested":"\\ud800"},"prefix":"fastflow-json-string:hello","reserved":"\\u001ffastflow.afn.v3.json-escape/v1:x","surrogate":"\\ud800"}'),
      errorCode: "",
      errorMessage: "",
      resultDigest: digest,
    }, 4)],
  ]);
  const descriptorPath = path.join(temporary, "session-descriptor.bin");
  const descriptor = spawnSync("buf", [
    "build",
    "--path",
    "proto/fastflow/afn/v3/session.proto",
    "--as-file-descriptor-set",
    "--exclude-source-info",
    "--output",
    descriptorPath,
  ], { cwd: root, encoding: "utf8" });
  if (descriptor.status !== 0) {
    throw new Error(descriptor.stderr || descriptor.stdout || "buf build failed");
  }
  frames.set("session-descriptor.bin", new Uint8Array(await readFile(descriptorPath)));
  const files = new Map([...frames].map(([name, value]) => [
    name,
    value instanceof Uint8Array ? value : encodeFastflowSessionFrame(value),
  ]));
  const manifest = {
    schemaVersion: "fastflow.afn-golden-manifest/v3",
    protocol: AFN_SESSION_V3_PROTOCOL_VERSION,
    generator: "scripts/generate-afn-goldens.mjs",
    files: Object.fromEntries([...files].map(([name, bytes]) => [name, {
      bytes: bytes.byteLength,
      sha256: `sha256:${sha256Hex(bytes)}`,
    }])),
  };
  files.set("manifest.json", new TextEncoder().encode(`${JSON.stringify(manifest, null, 2)}\n`));

  if (write) await mkdir(fixtureDirectory, { recursive: true });
  const mismatches = [];
  for (const [name, bytes] of files) {
    const target = path.join(fixtureDirectory, name);
    if (write) {
      await writeFile(target, bytes);
      continue;
    }
    let existing = null;
    try {
      existing = new Uint8Array(await readFile(target));
    } catch {
      // Report a deterministic missing-fixture mismatch below.
    }
    if (!existing || !equalBytes(existing, bytes)) mismatches.push(name);
  }
  if (mismatches.length > 0) {
    throw new Error(
      `AFN v3 golden fixtures differ (${mismatches.join(", ")}); review the wire change, then run ` +
      "node scripts/generate-afn-goldens.mjs --write",
    );
  }
} finally {
  await rm(temporary, { recursive: true, force: true });
}

function equalBytes(left, right) {
  return left.byteLength === right.byteLength && left.every((value, index) => value === right[index]);
}
