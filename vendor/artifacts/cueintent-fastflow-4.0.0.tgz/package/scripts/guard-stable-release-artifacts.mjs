#!/usr/bin/env node

import { checkStableReleaseArtifacts } from "../src/lib/stable-release-artifacts.mjs";

const argv = process.argv.slice(2);
let staged = false;
let range = null;

while (argv.length > 0) {
  const token = argv.shift();
  if (token === "--staged") {
    staged = true;
    continue;
  }
  if (token === "--range") {
    range = argv.shift() || null;
    continue;
  }
  throw new Error(`Unknown release artifact guard option: ${token}`);
}

if (!staged && !range) {
  staged = true;
}

try {
  const result = await checkStableReleaseArtifacts({
    staged,
    ...(range ? { range } : {}),
  });
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
} catch (error) {
  process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n`);
  process.exitCode = 1;
}
