import * as implementation from "@cueintent/secret-manager";

for (const name of [
  "configureSecretManager",
  "migrateBrokerSecretStoreProfile",
  "migrateSecretStoreProfile",
  "spawnBitwardenCli",
  "resolveHostCredential",
]) {
  if (typeof implementation[name] !== "function")
    throw new Error(`Fastflow's installed Secret Manager artifact must export ${name}`);
}
