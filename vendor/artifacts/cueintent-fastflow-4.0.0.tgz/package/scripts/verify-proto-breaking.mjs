#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import { cp, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const importedFastflow = "cf7f6adc0255e15dafa9df87133877b88226ac9f";
const fastflowContract = "/fastflow/scheduler/v1/control.proto";
const explicitBase = process.env.FASTFLOW_PROTO_BASE_REF;
const baseRef = explicitBase || "main";
const git = (...args) => execFileSync("git", args, { cwd: root, encoding: "utf8" }).trim();

function contractAt(commit, directory) {
  const files = git("ls-tree", "-r", "--full-tree", "--name-only", commit, "--", directory)
    .split("\n").filter((entry) => entry.endsWith(".proto"));
  if (files.includes(directory + fastflowContract)) return { commit, directory, files };
}

const prefix = git("rev-parse", "--show-prefix");
const packageProto = prefix + "proto";
const baseCommit = git("rev-parse", "--verify", "--end-of-options", baseRef + "^{commit}");
let baseline = contractAt(baseCommit, packageProto);
// An explicit producer release may still have the standalone repository layout.
if (!baseline && explicitBase && prefix) baseline = contractAt(baseCommit, "proto");
if (!baseline && !explicitBase && prefix === "packages/fastflow/" &&
    !git("ls-tree", "--full-tree", baseCommit, "--", "packages/fastflow")) {
  // Before CueIntent main contains Fastflow, compare with its verified subtree import.
  git("merge-base", "--is-ancestor", importedFastflow, "HEAD");
  const importedProto = git("rev-parse", importedFastflow + ":" + packageProto);
  const originalProto = git("rev-parse", importedFastflow + "^2:proto");
  if (importedProto !== originalProto) throw new Error("Fastflow import contract does not match its producer");
  baseline = contractAt(importedFastflow, packageProto);
}
if (!baseline) throw new Error(`base ref '${baseRef}' contains no Fastflow Protobuf contract`);
process.stdout.write(`Fastflow protocol baseline: ${baseline.commit}:${baseline.directory}\n`);

const temporary = await mkdtemp(path.join(os.tmpdir(), "fastflow-proto-breaking-"));
try {
  const baselineProto = path.join(temporary, "proto");
  const cmdprotoProto = path.join(temporary, "cmdproto-proto");
  for (const sourcePath of baseline.files) {
    const relativePath = path.relative(baseline.directory, sourcePath);
    const target = path.join(baselineProto, relativePath);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(
      target,
      execFileSync("git", ["show", `${baseline.commit}:${sourcePath}`], { cwd: root }),
    );
  }
  await cp(path.join(root, ".cmdproto-deps", "proto"), cmdprotoProto, {
    recursive: true,
  });
  const configPath = path.join(temporary, "buf.yaml");
  await writeFile(configPath, [
    "version: v2",
    "modules:",
    "  - path: proto",
    "  - path: cmdproto-proto",
    "breaking:",
    "  use:",
    "    - FILE",
    "",
  ].join("\n"));
  const baselineImage = path.join(temporary, "baseline.binpb");
  execFileSync("buf", [
    "build",
    "proto",
    "--config",
    configPath,
    "--output",
    baselineImage,
  ], { cwd: temporary, stdio: "inherit" });
  execFileSync("buf", [
    "breaking",
    "proto",
    "--against",
    baselineImage,
    "--exclude-imports",
  ], {
    cwd: root,
    stdio: "inherit",
  });
} finally {
  await rm(temporary, { recursive: true, force: true });
}
