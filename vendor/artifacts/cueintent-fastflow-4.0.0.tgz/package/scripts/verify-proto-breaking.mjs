#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import { cp, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const baseRef = process.env.FASTFLOW_PROTO_BASE_REF || "main";
const temporary = await mkdtemp(path.join(os.tmpdir(), "fastflow-proto-breaking-"));

try {
  const baselineProto = path.join(temporary, "proto");
  const cmdprotoProto = path.join(temporary, "cmdproto-proto");
  const paths = execFileSync(
    "git",
    ["ls-tree", "-r", "--name-only", baseRef, "--", "proto"],
    { cwd: root, encoding: "utf8" },
  ).trim().split("\n").filter((entry) => entry.endsWith(".proto"));
  if (paths.length === 0) {
    throw new Error(`base ref '${baseRef}' contains no Protobuf contract`);
  }
  for (const sourcePath of paths) {
    const relativePath = path.relative("proto", sourcePath);
    const target = path.join(baselineProto, relativePath);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(
      target,
      execFileSync("git", ["show", `${baseRef}:${sourcePath}`], { cwd: root }),
    );
  }
  await cp(path.join(root, ".cmdproto-deps", "proto"), cmdprotoProto, {
    recursive: true,
  });
  const configPath = path.join(temporary, "buf.yaml");
  await writeFile(configPath, [
    "version: v2",
    "modules:",
    "  - path: proto",
    "  - path: cmdproto-proto",
    "breaking:",
    "  use:",
    "    - FILE",
    "",
  ].join("\n"));
  const baselineImage = path.join(temporary, "baseline.binpb");
  execFileSync("buf", [
    "build",
    "--config",
    configPath,
    "--output",
    baselineImage,
  ], { cwd: temporary, stdio: "inherit" });
  execFileSync("buf", [
    "breaking",
    "proto",
    "--against",
    baselineImage,
    "--exclude-imports",
    "--limit-to-input-files",
  ], {
    cwd: root,
    stdio: "inherit",
  });
} finally {
  await rm(temporary, { recursive: true, force: true });
}
