#!/usr/bin/env node
/**
 * Deploy the Fastflow 4 Cloudflare test project.
 *
 * Requirements:
 *   - wrangler login completed interactively, or CLOUDFLARE_API_TOKEN set
 *     with Workers Scripts + Durable Objects edit scope.
 *   - An isolated test account/project. This script never touches production.
 *
 * Usage: node scripts/deploy-cloudflare-test.mjs [--check]
 *   --check  only verify auth and print the deploy plan without deploying.
 */
import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

import { configureFastflowRuntime } from "../src/lib/runtime-shell.mjs";
import { ensureSecretStoreReadyInteractive } from "../vendor/secret-manager/src/lib/daemon/secret-client.mjs";
import { resolveSecretLocator } from "../vendor/secret-manager/src/lib/secret-store.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const WRANGLER = path.join(ROOT, "node_modules", ".bin", "wrangler");
const CONFIG = path.join(ROOT, "wrangler.jsonc");
const checkOnly = process.argv.includes("--check");
const CLOUDFLARE_SECRET_LOCATOR = Object.freeze({
  kind: "named_secret",
  store: "bitwarden-cli",
  name: "Browser Auth - API Key - Cloudflare - fastflow-test",
  field_path: "/custom_fields/CLOUDFLARE_API_TOKEN",
});

function run(args, token) {
  return execFileSync(WRANGLER, args, {
    cwd: ROOT,
    encoding: "utf8",
    env: {
      ...process.env,
      ...(token ? { CLOUDFLARE_API_TOKEN: token } : {}),
    },
    stdio: "inherit",
  });
}

async function resolveCloudflareToken() {
  const ambient = String(process.env.CLOUDFLARE_API_TOKEN || "").trim();
  if (ambient) return ambient;

  configureFastflowRuntime({ appName: "fastflow" });
  await ensureSecretStoreReadyInteractive({
    store: CLOUDFLARE_SECRET_LOCATOR.store,
    promptIfLocked: true,
  });
  const resolution = await resolveSecretLocator(CLOUDFLARE_SECRET_LOCATOR);
  const token = typeof resolution?.payload === "string"
    ? resolution.payload.trim()
    : "";
  if (!token) {
    throw new Error(
      "Fastflow Secret Manager resolved an empty Cloudflare API token from Bitwarden.",
    );
  }
  return token;
}

async function main() {
  if (!existsSync(WRANGLER)) {
    console.error("wrangler is not installed; run: pnpm add -D wrangler@4");
    process.exit(2);
  }
  if (!existsSync(CONFIG)) {
    console.error("missing " + CONFIG);
    process.exit(2);
  }
  const token = await resolveCloudflareToken();
  run(["whoami"], token);
  console.log("[deploy-cloudflare-test] authenticated.");
  if (checkOnly) {
    console.log("[deploy-cloudflare-test] --check only; deploy plan:");
    console.log("  wrangler deploy --config wrangler.jsonc");
    return;
  }
  run(["deploy", "--config", "wrangler.jsonc"], token);
  console.log("[deploy-cloudflare-test] deployed to the isolated test project.");
}

main().catch((error) => {
  console.error(`[deploy-cloudflare-test] ${error.message}`);
  process.exitCode = 1;
});
