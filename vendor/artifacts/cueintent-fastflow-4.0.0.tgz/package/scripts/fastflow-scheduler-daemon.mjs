#!/usr/bin/env bun

import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";

import {
  assertCanonicalBunApplicationRuntime,
} from "../src/lib/application-runtime.mjs";

assertCanonicalBunApplicationRuntime("Fastflow scheduler daemon");

let appModule = null;
if (process.env.FASTFLOW_APP_MODULE) {
  appModule = await import(pathToModuleUrl(process.env.FASTFLOW_APP_MODULE));
}

const { NATIVE_SCHEDULER_PROFILE_ID } = await import(
  "../src/lib/native-contracts.mjs"
);
const { createBunSqliteFastflowNode } = await import(
  "../src/fastflow-node.mjs"
);
const { createCloudflareCatalogTrustPolicy } = await import(
  "../src/cloudflare-node.mjs"
);

let closing = false;
let node = null;

async function close() {
  if (closing) return;
  closing = true;
  if (typeof node?.close === "function") {
    await node.close();
  } else {
    await node?.stop?.();
  }
}

async function fail(error) {
  process.stderr.write(`${JSON.stringify({
    ok: false,
    code: String(error?.code || "FASTFLOW_SCHEDULER_DAEMON_FAILED"),
    message: "Native scheduler authority stopped after a fatal failure.",
  })}\n`);
  process.exitCode = 1;
  await close();
}

process.once("SIGINT", () => void close().then(() => process.exit(0)));
process.once("SIGTERM", () => void close().then(() => process.exit(0)));

try {
  const schedulerDbPath = resolveSchedulerDbPath();
  const descriptorPath = resolveDescriptorPath();
  const catalogDbPath = resolveCatalogDbPath(schedulerDbPath);
  node = await createConfiguredNode(appModule, {
    schedulerDbPath,
    catalogDbPath,
    descriptorPath,
    onError: (error) => void fail(error),
  });
  const startedDescriptor = await node.start();
  const descriptor = node.schedulerDescriptor || startedDescriptor;
  process.stdout.write(`${JSON.stringify({
    ok: true,
    scheduler: NATIVE_SCHEDULER_PROFILE_ID,
    profile: "local-durable",
    dbPath: schedulerDbPath,
    instanceId: descriptor.instanceId,
    controlBaseUrl: descriptor.controlBaseUrl,
    descriptorPath,
  })}\n`);
} catch (error) {
  await fail(error);
}

async function createConfiguredNode(module, input) {
  if (module) {
    const exports = Object.keys(module);
    if (exports.length !== 1 || exports[0] !== "createFastflowSchedulerNode" ||
      typeof module.createFastflowSchedulerNode !== "function") {
      throw new TypeError(
        "FASTFLOW_APP_MODULE must export only createFastflowSchedulerNode(input)",
      );
    }
    return validateNode(
      await module.createFastflowSchedulerNode({
        schedulerDbPath: input.schedulerDbPath,
        descriptorPath: input.descriptorPath,
        env: Object.freeze({ ...process.env }),
      }),
      "FASTFLOW_APP_MODULE createFastflowSchedulerNode",
    );
  }
  return createBunSqliteFastflowNode({
    identity: process.env.FASTFLOW_NODE_IDENTITY || "fastflow/scheduler",
    schedulerDbPath: input.schedulerDbPath,
    catalogDbPath: input.catalogDbPath,
    descriptorPath: input.descriptorPath,
    catalogs: { mounts: [] },
    trust: {
      mode: "production",
      owner: process.env.FASTFLOW_NODE_OWNER || "fastflow",
      catalogs: createCloudflareCatalogTrustPolicy({
        mode: "production",
        trustRoots: process.env.FASTFLOW_CATALOG_TRUST_ROOTS || null,
      }),
    },
    authority: { onError: input.onError },
  });
}

function validateNode(value, source) {
  if (!value || typeof value.start !== "function" ||
    typeof value.close !== "function" ||
    !("schedulerDescriptor" in value)) {
    throw new TypeError(
      `${source} must return a Fastflow node with start(), close(), and schedulerDescriptor`,
    );
  }
  return value;
}

function resolveSchedulerDbPath() {
  const configured = process.env.FASTFLOW_SCHEDULER_DB;
  if (configured !== undefined && configured !== "") {
    return requireAbsolutePath(configured, "FASTFLOW_SCHEDULER_DB");
  }
  return path.join(os.homedir(), ".fastflow", "scheduler", "fastflow.sqlite");
}

function resolveCatalogDbPath(schedulerDbPath) {
  const configured = process.env.FASTFLOW_CATALOG_DB;
  if (configured !== undefined && configured !== "") {
    return requireAbsolutePath(configured, "FASTFLOW_CATALOG_DB");
  }
  return `${schedulerDbPath}.catalog.sqlite`;
}

function resolveDescriptorPath() {
  const configured = process.env.FASTFLOW_SCHEDULER_DESCRIPTOR;
  if (configured !== undefined && configured !== "") {
    return requireAbsolutePath(configured, "FASTFLOW_SCHEDULER_DESCRIPTOR");
  }
  return path.join(os.homedir(), ".fastflow", "scheduler", "fastflow.runtime.json");
}

function requireAbsolutePath(value, name) {
  if (!path.isAbsolute(value)) {
    const error = new TypeError(`${name} and scheduler paths must be absolute paths`);
    error.code = "FASTFLOW_INVALID_SCHEDULER_DB_PATH";
    throw error;
  }
  return path.normalize(value);
}

function pathToModuleUrl(value) {
  if (/^[a-z]+:/iu.test(value)) return value;
  return pathToFileURL(path.resolve(value)).href;
}
