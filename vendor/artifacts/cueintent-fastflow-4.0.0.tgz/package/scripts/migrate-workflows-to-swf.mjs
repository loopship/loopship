import fsp from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { convertLegacyWorkflowToSwf } from "../src/lib/legacy-to-swf.mjs";
import {
  getGlobalWorkflowsDir,
  loadWorkflowRecord,
  patchWorkflowCallDigestsInPlace,
  pathSegmentsToNamespace,
  validateWorkflowRecord,
} from "../src/lib/workflows.mjs";
import { writeYamlFile } from "../src/lib/workspace.mjs";
import { parseYamlFile } from "../src/lib/yaml-runtime.mjs";

const MODULE_FILE = fileURLToPath(import.meta.url);
const MODULE_DIR = path.dirname(MODULE_FILE);

async function main() {
  const options = parseArgs(process.argv.slice(2));
  const workflowRoots = buildWorkflowRoots(options);
  const fileRecords = [];
  for (const root of workflowRoots) {
    const files = await collectWorkflowFiles(root.rootDir, options.fileFilters);
    for (const filePath of files) {
      const sourceWorkflow = parseYamlFile(filePath);
      const relative = path.relative(root.rootDir, filePath);
      const [target, scope, fileName] = relative.split(path.sep);
      const name = path.basename(fileName, ".yaml");
      const converted = isSwfWorkflow(sourceWorkflow)
        ? sourceWorkflow
        : convertLegacyWorkflowToSwf(sourceWorkflow, {
            store: root.store,
            scope,
            namespace: pathSegmentsToNamespace(target, scope),
            registry: root.store === "global" ? "sys" : "workspace",
            resolveReference: (legacyRef) => resolveLegacyReference(legacyRef),
          });
      fileRecords.push({
        store: root.store,
        filePath,
        target,
        scope,
        name,
        legacy: sourceWorkflow,
        converted,
      });
    }
  }

  for (const record of fileRecords) {
    await patchWorkflowCallDigestsInPlace(record.converted, {
      workspaceRoot: options.workspaceRoot,
    });
    await writeYamlFile(record.filePath, record.converted);
  }

  for (const record of fileRecords) {
    const loaded = await loadWorkflowRecord(record.filePath, record.store);
    await validateWorkflowRecord(loaded);
  }

  console.log(
    JSON.stringify(
      {
        ok: true,
        migrated: fileRecords.length,
        roots: workflowRoots.map((root) => root.rootDir),
        workspaceRoot: options.workspaceRoot,
        files: fileRecords.map((record) => record.filePath),
      },
      null,
      2,
    ),
  );
}

function parseArgs(argv) {
  const options = {
    workspaceRoot: process.cwd(),
    projectWorkflowsRoot: null,
    store: "all",
    fileFilters: [],
  };

  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === "--workspace-root") {
      const value = argv[index + 1];
      if (!value) {
        throw new Error("--workspace-root requires a path");
      }
      options.workspaceRoot = path.resolve(value);
      index += 1;
      continue;
    }
    if (token === "--project-workflows-root") {
      const value = argv[index + 1];
      if (!value) {
        throw new Error("--project-workflows-root requires a path");
      }
      options.projectWorkflowsRoot = path.resolve(value);
      index += 1;
      continue;
    }
    if (token === "--store") {
      const value = String(argv[index + 1] || "").trim();
      if (!value || !new Set(["all", "global", "project"]).has(value)) {
        throw new Error("--store must be one of: all, global, project");
      }
      options.store = value;
      index += 1;
      continue;
    }
    if (token === "--file") {
      const value = argv[index + 1];
      if (!value) {
        throw new Error("--file requires a path");
      }
      options.fileFilters.push(value);
      index += 1;
      continue;
    }
    throw new Error(`Unknown argument '${token}'`);
  }

  return {
    ...options,
    fileFilters: options.fileFilters.map((value) =>
      path.resolve(options.workspaceRoot, value),
    ),
  };
}

function isSwfWorkflow(value) {
  return (
    !!value &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    value.document &&
    Array.isArray(value.do)
  );
}

function buildWorkflowRoots(options) {
  const projectWorkflowsRoot =
    options.projectWorkflowsRoot ||
    path.join(options.workspaceRoot, ".fastflow", "call-catalog");
  const roots = [];
  if (options.store === "all" || options.store === "global") {
    roots.push({ store: "global", rootDir: getGlobalWorkflowsDir() });
  }
  if (options.store === "all" || options.store === "project") {
    roots.push({ store: "project", rootDir: projectWorkflowsRoot });
  }
  return roots;
}

function resolveLegacyReference(reference) {
  const parts = String(reference || "")
    .trim()
    .split(":");
  if (parts.length !== 4) {
    throw new Error(`Invalid legacy workflow reference '${reference}'`);
  }
  const [storeToken, target, scope, name] = parts;
  return {
    registry: storeToken === "global" ? "sys" : "workspace",
    kind: "workflow",
    target,
    scope,
    namespace: pathSegmentsToNamespace(target, scope),
    name,
    version: "1.0.0",
  };
}

async function collectWorkflowFiles(rootDir, fileFilters = []) {
  try {
    const normalizedFilters = new Set(
      (Array.isArray(fileFilters) ? fileFilters : []).map((value) =>
        path.resolve(value),
      ),
    );
    const entries = await fsp.readdir(rootDir, { withFileTypes: true });
    const files = [];
    for (const entry of entries) {
      const nextPath = path.join(rootDir, entry.name);
      if (entry.isDirectory()) {
        files.push(...(await collectWorkflowFiles(nextPath, fileFilters)));
        continue;
      }
      if (
        entry.isFile() &&
        entry.name.endsWith(".yaml") &&
        entry.name !== "index.yaml" &&
        (normalizedFilters.size === 0 ||
          normalizedFilters.has(path.resolve(nextPath)))
      ) {
        files.push(nextPath);
      }
    }
    files.sort();
    return files;
  } catch {
    return [];
  }
}

main().catch((error) => {
  console.error(
    error instanceof Error ? error.stack || error.message : String(error),
  );
  process.exitCode = 1;
});
