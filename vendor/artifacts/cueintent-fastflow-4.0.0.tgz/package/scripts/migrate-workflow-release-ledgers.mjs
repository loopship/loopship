import fsp from "node:fs/promises";
import path from "node:path";
import process from "node:process";

import { hashSwfWorkflow } from "../src/lib/swf-compat.mjs";
import { writeWorkflowCallCatalog } from "../src/lib/call-catalog.mjs";
import { writeYamlFile } from "../src/lib/workspace.mjs";
import {
  getGlobalWorkflowsDir,
  getWorkflowProvenanceRoot,
} from "../src/lib/workflows.mjs";
import {
  appendStableWorkflowRelease,
  buildStableWorkflowReleaseEntry,
  buildWorkflowChannelFileName,
  createWorkflowVersionsManifest,
  DEV_WORKFLOW_CHANNEL,
  loadWorkflowVersionsManifest,
  parseManagedWorkflowFileName,
  parseYamlFile,
  resolveGitRef,
  resolveGitRemoteUrl,
  STABLE_WORKFLOW_CHANNEL,
  WORKFLOW_VERSIONS_FILE,
} from "../src/lib/workflow-release-ledger.mjs";

async function main() {
  const { workflowsRoot } = parseArgs(process.argv.slice(2));
  const provenanceRoot =
    workflowsRoot === getGlobalWorkflowsDir()
      ? getWorkflowProvenanceRoot()
      : path.dirname(workflowsRoot);
  const workflowGitRepo =
    process.env.FASTFLOW_MIGRATION_WORKFLOW_GIT_REPO ||
    resolveGitRemoteUrl(provenanceRoot) ||
    null;
  const runtimeGitRepo =
    process.env.FASTFLOW_MIGRATION_RUNTIME_GIT_REPO ||
    resolveGitRemoteUrl(provenanceRoot) ||
    null;
  const gitRef =
    process.env.FASTFLOW_MIGRATION_GIT_REF ||
    resolveGitRef(provenanceRoot);
  const promotedAt =
    process.env.FASTFLOW_MIGRATION_PROMOTED_AT ||
    new Date().toISOString();
  const workflowDirs = await findWorkflowDirs(workflowsRoot);
  for (const workflowDir of workflowDirs) {
    await migrateWorkflowDir(workflowDir, {
      workflowGitRepo,
      runtimeGitRepo,
      gitRef,
      promotedAt,
    });
  }
  await writeWorkflowCallCatalog({
    registry: "sys",
    store: "global",
    workflowsRoot,
  });
}

function parseArgs(argv) {
  let workflowsRoot =
    process.env.FASTFLOW_WORKFLOWS_ROOT?.trim() ||
    getGlobalWorkflowsDir();
  const tokens = [...argv];
  while (tokens.length > 0) {
    const token = tokens.shift();
    if (token === "--workflows-root") {
      workflowsRoot = String(tokens.shift() || "").trim();
      continue;
    }
    if (token?.startsWith("--workflows-root=")) {
      workflowsRoot = token.slice("--workflows-root=".length).trim();
      continue;
    }
    throw new Error(
      `Unknown migrate-workflow-release-ledgers option: ${token}`,
    );
  }
  if (!workflowsRoot) {
    throw new Error("A workflows root is required.");
  }
  return {
    workflowsRoot: path.resolve(workflowsRoot),
  };
}

async function findWorkflowDirs(rootDir) {
  const surfaceEntries = await fsp.readdir(rootDir, { withFileTypes: true });
  const results = [];
  for (const surfaceEntry of surfaceEntries) {
    if (!surfaceEntry.isDirectory()) {
      continue;
    }
    if (surfaceEntry.name === "call-catalog") {
      continue;
    }
    const surfaceDir = path.join(rootDir, surfaceEntry.name);
    const targetEntries = await fsp.readdir(surfaceDir, {
      withFileTypes: true,
    });
    for (const targetEntry of targetEntries) {
      if (!targetEntry.isDirectory()) {
        continue;
      }
      results.push(path.join(surfaceDir, targetEntry.name));
    }
  }
  results.sort();
  return results;
}

async function migrateWorkflowDir(workflowDir, context) {
  const dirEntries = await fsp.readdir(workflowDir, { withFileTypes: true });
  const legacyFiles = [];
  for (const entry of dirEntries) {
    if (!entry.isFile()) {
      continue;
    }
    const parsed = parseManagedWorkflowFileName(entry.name);
    if (parsed?.kind === "workflow" && parsed.isVersioned !== true) {
      legacyFiles.push({
        workflowName: parsed.workflowName,
        filePath: path.join(workflowDir, entry.name),
      });
    }
  }

  for (const legacyFile of legacyFiles) {
    const stablePath = path.join(
      workflowDir,
      buildWorkflowChannelFileName(
        legacyFile.workflowName,
        STABLE_WORKFLOW_CHANNEL,
      ),
    );
    const devPath = path.join(
      workflowDir,
      buildWorkflowChannelFileName(
        legacyFile.workflowName,
        DEV_WORKFLOW_CHANNEL,
      ),
    );
    await fsp.rename(legacyFile.filePath, stablePath);
    await fsp.copyFile(stablePath, devPath);
  }

  const workflowEntries = await collectVersionedWorkflows(workflowDir);
  if (workflowEntries.size === 0) {
    return null;
  }

  const existingManifest = await loadWorkflowVersionsManifest(workflowDir);
  let manifest = createWorkflowVersionsManifest({
    workflowGitRepo: context.workflowGitRepo,
    runtimeGitRepo: context.runtimeGitRepo,
  });

  for (const [workflowName, variants] of workflowEntries.entries()) {
    const existingWorkflow = existingManifest?.workflows?.[workflowName] || {};
    const stableEntry = await buildReleaseEntry(
      workflowDir,
      variants.stable,
      context,
      existingWorkflow.stable?.release || 1,
      existingWorkflow.stable?.summary ||
        `Initial stable import from legacy ${workflowName}.yaml.`,
    );
    manifest = appendStableWorkflowRelease(manifest, workflowName, stableEntry);
  }

  await fsp.rm(path.join(workflowDir, "index.yaml"), { force: true });
  await writeYamlFile(path.join(workflowDir, WORKFLOW_VERSIONS_FILE), manifest);
}

async function collectVersionedWorkflows(workflowDir) {
  const dirEntries = await fsp.readdir(workflowDir, { withFileTypes: true });
  const workflows = new Map();
  for (const entry of dirEntries) {
    if (!entry.isFile()) {
      continue;
    }
    const parsed = parseManagedWorkflowFileName(entry.name);
    if (!parsed || parsed.kind !== "workflow") {
      continue;
    }
    const current = workflows.get(parsed.workflowName) || {};
    current[parsed.channel] = path.join(workflowDir, entry.name);
    workflows.set(parsed.workflowName, current);
  }
  for (const [workflowName, variants] of workflows.entries()) {
    if (!variants.stable || !variants.dev) {
      throw new Error(
        `Workflow '${workflowName}' in ${workflowDir} must have both stable and dev variants after migration.`,
      );
    }
  }
  return workflows;
}

async function buildReleaseEntry(
  workflowDir,
  filePath,
  context,
  release,
  summary,
) {
  const rawWorkflow = parseYamlFile(filePath);
  return buildStableWorkflowReleaseEntry({
    release,
    workflowPath: path.relative(workflowDir, filePath),
    workflowVersion: rawWorkflow?.document?.version || null,
    workflowGitRef: context.gitRef,
    workflowStoreGitRef: context.gitRef,
    workflowDigest: `sha256:${hashSwfWorkflow(rawWorkflow)}`,
    promotedAt: context.promotedAt,
    summary,
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
