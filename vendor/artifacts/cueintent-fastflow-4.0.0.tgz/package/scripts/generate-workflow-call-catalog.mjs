#!/usr/bin/env node

import path from "node:path";
import process from "node:process";

import { writeWorkflowCallCatalog } from "../src/lib/call-catalog.mjs";
import { getGlobalWorkflowsDir } from "../src/lib/workflows.mjs";

const args = parseArgs(process.argv.slice(2));
const workflowsRoot = path.resolve(args.workflowsRoot || getGlobalWorkflowsDir());
const registry = args.registry || "sys";
const store = args.store || (registry === "workspace" ? "project" : "global");
const outputRoot = args.outputRoot
  ? path.resolve(args.outputRoot)
  : path.join(workflowsRoot, "call-catalog");

const result = await writeWorkflowCallCatalog({
  registry,
  store,
  workflowsRoot,
  outputRoot,
});
console.log(JSON.stringify(result, null, 2));

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === "--workflows-root") {
      result.workflowsRoot = argv[++index];
    } else if (token === "--output-root") {
      result.outputRoot = argv[++index];
    } else if (token === "--registry") {
      result.registry = argv[++index];
    } else if (token === "--store") {
      result.store = argv[++index];
    } else {
      throw new Error(`Unknown option: ${token}`);
    }
  }
  return result;
}
