import assert from "node:assert/strict";
import test from "node:test";

import {
  APP_NAME,
  configureFastflowFor__PASCAL_NAME__,
} from "../src/fastflow.mjs";

test("__APP_NAME__ configures Fastflow identity", () => {
  assert.equal(APP_NAME, "__APP_NAME__");
  configureFastflowFor__PASCAL_NAME__();
});
