import fs from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const FASTFLOW_SOURCE_ENV = "FASTFLOW_SOURCE_DIR";
const FASTFLOW_PACKAGE_NAME = "@cueintent/fastflow";
let selectedRoot = null;
const REQUIRED_EXPORTS = Object.freeze({
  root: ["configureFastflowNode"],
  "runtime-shell": ["configureFastflowRuntime"],
  cmdproto: ["runFastflowCmdprotoCli"],
  "application-runtime": ["assertCanonicalBunApplicationRuntime"],
});

export function assertFastflowBunRuntime(component = "Fastflow application entrypoint") {
  if (process.versions?.bun) return process.execPath;
  const error = new Error(
    `FASTFLOW_BUN_RUNTIME_REQUIRED: ${component} requires Bun as its canonical application runtime.`,
  );
  error.code = "FASTFLOW_BUN_RUNTIME_REQUIRED";
  throw error;
}

export const assertCanonicalBunApplicationRuntime = assertFastflowBunRuntime;

export async function loadFastflowRoot() {
  return loadFastflowModule("root");
}

export async function loadFastflowModule(kind) {
  const explicit = String(process.env[FASTFLOW_SOURCE_ENV] || "").trim();
  let module;
  if (!explicit) {
    selectedRoot = resolveInstalledSourceRoot();
    if (kind === "root") module = await import(FASTFLOW_PACKAGE_NAME);
    else if (kind === "cmdproto") module = await import(`${FASTFLOW_PACKAGE_NAME}/cmdproto`);
    else if (kind === "runtime-shell") {
      module = await import(pathToFileURL(path.join(selectedRoot, "src/lib/runtime-shell.mjs")).href);
    }
    else if (kind === "application-runtime") module = await import(`${FASTFLOW_PACKAGE_NAME}/application-runtime`);
    else throw new Error(`Unsupported Fastflow module kind '${kind}'`);
  } else {
    const root = resolveExplicitSourceRoot(explicit);
    selectedRoot = root;
    const relativePath = {
      root: "src/index.mjs",
      "runtime-shell": "src/lib/runtime-shell.mjs",
      cmdproto: "src/cmdproto/app.mjs",
      "application-runtime": "src/application-runtime.mjs",
    }[kind];
    if (!relativePath) throw new Error(`Unsupported Fastflow module kind '${kind}'`);
    module = await import(pathToFileURL(path.join(root, relativePath)).href);
  }
  assertRequiredExports(module, kind);
  return module;
}

export function getFastflowSourceRoot() {
  if (selectedRoot) return selectedRoot;
  const explicit = String(process.env[FASTFLOW_SOURCE_ENV] || "").trim();
  selectedRoot = explicit
    ? resolveExplicitSourceRoot(explicit)
    : resolveInstalledSourceRoot();
  return selectedRoot;
}

export async function getFastflowSourceIdentity() {
  const root = getFastflowSourceRoot();
  const provenance = await import(
    pathToFileURL(path.join(root, "src/lib/source-provenance.mjs")).href
  );
  if (typeof provenance.readFastflowSourceIdentity !== "function") {
    throw new Error(
      "Fastflow source-provenance module is incomplete; missing readFastflowSourceIdentity",
    );
  }
  return provenance.readFastflowSourceIdentity(root);
}

function resolveInstalledSourceRoot() {
  return fs.realpathSync(
    path.dirname(
      fileURLToPath(import.meta.resolve(`${FASTFLOW_PACKAGE_NAME}/package.json`)),
    ),
  );
}

function resolveExplicitSourceRoot(value) {
  const root = path.resolve(value);
  let packageJson;
  try {
    packageJson = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
  } catch (error) {
    throw new Error(`FASTFLOW_SOURCE_DIR must point to a complete Fastflow source directory: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (packageJson.name !== FASTFLOW_PACKAGE_NAME) {
    throw new Error(`FASTFLOW_SOURCE_DIR package identity must be ${FASTFLOW_PACKAGE_NAME}`);
  }
  for (const relativePath of [
    "src/index.mjs",
    "src/cmdproto/app.mjs",
    "src/application-runtime.mjs",
    "src/lib/runtime-shell.mjs",
    "src/lib/source-provenance.mjs",
    "schemas/config.yaml",
  ]) {
    if (!fs.existsSync(path.join(root, relativePath))) {
      throw new Error(`FASTFLOW_SOURCE_DIR is incomplete; missing ${relativePath}`);
    }
  }
  return fs.realpathSync(root);
}

function assertRequiredExports(module, kind) {
  const missing = (REQUIRED_EXPORTS[kind] || []).filter(
    (name) => typeof module?.[name] !== "function",
  );
  if (missing.length > 0) {
    throw new Error(
      `Fastflow ${kind} module is incomplete; missing exports: ${missing.join(", ")}`,
    );
  }
}
