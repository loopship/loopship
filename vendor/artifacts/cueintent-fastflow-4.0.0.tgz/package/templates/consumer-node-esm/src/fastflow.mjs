import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { loadFastflowModule } from "./fastflow-runtime.mjs";

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));
const APP_ROOT = path.resolve(MODULE_DIR, "..");
const PACKAGE_JSON = JSON.parse(
  fs.readFileSync(path.join(APP_ROOT, "package.json"), "utf8"),
);
__EXTENSION_SCHEMA_CONST__
export const APP_NAME = "__APP_NAME__";
let configured = false;

export async function configureFastflowFor__PASCAL_NAME__() {
  const { configureFastflowRuntime } = await loadFastflowModule("runtime-shell");
  const runtimeIdentity = PACKAGE_JSON.name || "__APP_NAME__";
  const runtimeVersion = PACKAGE_JSON.version || "0.0.0";
  configureFastflowRuntime({
    appName: APP_NAME,
    integrations: {
      runtimeIdentity,
      runtimeVersion,
      externalExecutableCwd: APP_ROOT,
      adapterRoot: APP_ROOT,
__EXTENSION_ADAPTER_FIELDS__
    },
  });
  configured = true;
}

export async function runFastflowFrom__PASCAL_NAME__(argv, options = {}) {
  if (!configured) {
    await configureFastflowFor__PASCAL_NAME__();
  }
  const { runFastflowCmdprotoCli } = await loadFastflowModule("cmdproto");
  return runFastflowCmdprotoCli(argv, options);
}
