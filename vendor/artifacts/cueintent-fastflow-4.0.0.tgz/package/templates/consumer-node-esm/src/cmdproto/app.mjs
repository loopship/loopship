import { realpathSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import {
  CmdProtoError,
  createRuntimeFromFile,
  runMain,
} from "cmdproto";
import {
  loadFastflowModule,
} from "../fastflow-runtime.mjs";

import {
  APP_NAME,
  configureFastflowFor__PASCAL_NAME__,
  runFastflowFrom__PASCAL_NAME__,
} from "../fastflow.mjs";

const CMDPROTO_MODULE_PATH = fileURLToPath(import.meta.url);

export const __PASCAL_NAME___SCHEMA_PATH = join(
  dirname(fileURLToPath(import.meta.url)),
  "../../dist/cmdproto/schema.binpb",
);
export const __PASCAL_NAME___MANIFEST_PATH = join(
  dirname(fileURLToPath(import.meta.url)),
  "../../dist/cmdproto/runtime.binpb",
);

export const __PASCAL_NAME___METHODS = Object.freeze({
  about: "__ABOUT_METHOD__",
});

const COMMAND_BY_METHOD = new Map([
  [__PASCAL_NAME___METHODS.about, "about"],
]);

export const handlers = Object.fromEntries(
  [...COMMAND_BY_METHOD].map(([methodName, commandPath]) => [
    methodName,
    async (params) => {
      const { assertCanonicalBunApplicationRuntime } = await loadFastflowModule("application-runtime");
      assertCanonicalBunApplicationRuntime("__APP_NAME__ cmdproto handler");
      try {
        return await execute__PASCAL_NAME__CmdprotoCommand(commandPath, params);
      } catch (error) {
        throw toCmdprotoError(error);
      }
    },
  ]),
);

export function create__PASCAL_NAME__Runtime({
  schemaPath = __PASCAL_NAME___SCHEMA_PATH,
  manifestPath = __PASCAL_NAME___MANIFEST_PATH,
} = {}) {
  return createRuntimeFromFile(handlers, schemaPath, manifestPath);
}

export async function run__PASCAL_NAME__CmdprotoCli(
  argv = process.argv.slice(2),
  {
    schemaPath = __PASCAL_NAME___SCHEMA_PATH,
    manifestPath = __PASCAL_NAME___MANIFEST_PATH,
    stdin,
  } = {},
) {
  const { assertCanonicalBunApplicationRuntime } = await loadFastflowModule("application-runtime");
  assertCanonicalBunApplicationRuntime("__APP_NAME__ cmdproto CLI");
  await configureFastflowFor__PASCAL_NAME__();
  if (shouldRouteToFastflow(argv)) {
    return runFastflowFrom__PASCAL_NAME__(argv, { stdin });
  }
  return runMain({
    handlers,
    schemaPath,
    manifestPath,
    argv,
    stdin,
  });
}

async function execute__PASCAL_NAME__CmdprotoCommand(commandPath, params = {}) {
  switch (commandPath) {
    case "about":
      void params;
      return {
        schemaVersion: `${APP_NAME}/about/v1`,
        appName: APP_NAME,
        packageName: "__PACKAGE_NAME__",
        fastflowPackage: "@cueintent/fastflow",
      };
    default:
      throw new CmdProtoError(
        "METHOD_NOT_FOUND",
        `Unsupported __APP_NAME__ command ${commandPath}`,
      );
  }
}

function shouldRouteToFastflow(argv) {
  if (!Array.isArray(argv) || argv.length === 0) {
    return false;
  }
  if (["workflows", "secrets", "snapshots", "scaffold"].includes(argv[0])) {
    return true;
  }
  return (
    argv[0] === "cmdproto" &&
    argv[1] === "execjson" &&
    ["workflows", "secrets", "snapshots", "scaffold"].includes(argv[2])
  );
}

function toCmdprotoError(error) {
  if (error instanceof CmdProtoError) {
    return error;
  }
  return error;
}

function is__PASCAL_NAME__CmdprotoEntrypoint(entrypointPath) {
  if (!entrypointPath) return false;
  try {
    return realpathSync(resolve(entrypointPath)) === realpathSync(CMDPROTO_MODULE_PATH);
  } catch {
    return resolve(entrypointPath) === CMDPROTO_MODULE_PATH;
  }
}

if (is__PASCAL_NAME__CmdprotoEntrypoint(process.argv[1])) {
  await run__PASCAL_NAME__CmdprotoCli();
}
