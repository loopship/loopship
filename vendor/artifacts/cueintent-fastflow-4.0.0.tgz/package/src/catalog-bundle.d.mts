import type { JsonValue } from "./native-scheduler.mjs";
import type { CallDescriptor } from "./index.d.ts";

export declare const CATALOG_BUNDLE_SCHEMA_VERSION: "fastflow.catalog-bundle/v1";
export declare const CATALOG_BUNDLE_DEFAULT_LIMITS: Readonly<{
  maxFiles: number;
  maxFileBytes: number;
  maxBundleBytes: number;
}>;

export interface CatalogBundleLimits {
  maxFiles?: number;
  maxFileBytes?: number;
  maxBundleBytes?: number;
}

export interface CatalogBundleFileInput {
  path: string;
  mediaType: string;
  bytes: string | Uint8Array;
}

export interface CatalogBundleFile {
  path: string;
  mediaType: string;
  byteLength: number;
  digest: string;
  content: { encoding: "base64"; data: string };
}

export interface CatalogBundleWorkflow {
  callId: string;
  version: string;
  workflowDigest: string;
  sourcePath: string;
  sourceDigest: string;
  irPath: string;
  irFileDigest: string;
  irDigest: string;
  dependencies: string[];
}

export interface CatalogBundleWorkflowInput extends Omit<
  CatalogBundleWorkflow,
  "workflowDigest" | "sourceDigest" | "irFileDigest" | "irDigest"
  > {
  workflowDigest: string | null;
  sourceDigest: string | null;
  irFileDigest: string | null;
  irDigest: string | null;
}

export type CatalogAfnReplayPolicy =
  | "idempotent"
  | "replay-safe"
  | "assigned-executor-only"
  | "at-most-once";

export interface CatalogAfnGrantRequirement {
  kind: string;
  scope?: JsonValue;
}

export interface CatalogAfnResourceRequirement {
  type: string;
  operations: string[];
  exclusive: boolean;
}

export interface CatalogAfnContract {
  schemaVersion: "fastflow.afn-contract/v1";
  callId: string;
  contractDigest: `sha256:${string}`;
  inputSchema: JsonValue;
  outputSchema: JsonValue;
  effects: string[];
  grantRequirements: CatalogAfnGrantRequirement[];
  resourceRequirements: CatalogAfnResourceRequirement[];
  qualifierSchema: Record<string, JsonValue>;
  replayPolicy: CatalogAfnReplayPolicy;
}

export interface CatalogSignerEvidence {
  kind: string;
  signerId: string;
  algorithm: string;
  signature: string;
}

export interface CatalogBundlePayload {
  schemaVersion: "fastflow.catalog-bundle/v1";
  registryId: string;
  releaseVersion: string;
  rootCatalogPath: string;
  files: CatalogBundleFile[];
  closure: {
    files: string[];
    workflows: CatalogBundleWorkflow[];
    afnContracts: Array<{
      callId: string;
      contractDigest: string;
      catalogPath: string;
    }>;
    registries: Array<{ registryId: string; bundleDigest: string }>;
  };
}

export interface CatalogBundle extends CatalogBundlePayload {
  payloadDigest: string;
  signerEvidence: CatalogSignerEvidence[];
  bundleDigest: string;
}

export type CatalogBundleTrustPolicy =
  | {
      mode: "production";
      trustedSignerIds: readonly string[];
      verifyEvidence(input: {
        evidence: CatalogSignerEvidence;
        payload: string;
        payloadDigest: string;
      }): boolean | Promise<boolean>;
    }
  | {
      mode: "local-development";
      trustedSignerIds?: readonly string[];
      verifyEvidence?(input: {
        evidence: CatalogSignerEvidence;
        payload: string;
        payloadDigest: string;
      }): boolean | Promise<boolean>;
    };

export interface BuildCatalogBundleInput {
  registryId: string;
  releaseVersion: string;
  rootCatalogPath: string;
  files: CatalogBundleFileInput[];
  closure: {
    files: string[];
    workflows: CatalogBundleWorkflowInput[];
    afnContracts: Array<{
      callId: string;
      contractDigest: string;
      catalogPath: string;
    }>;
    registries: Array<{ registryId: string; bundleDigest: string }>;
  };
  signPayload?(input: {
    payload: string;
    payloadDigest: string;
    registryId: string;
    releaseVersion: string;
  }): CatalogSignerEvidence[] | Promise<CatalogSignerEvidence[]>;
  limits?: CatalogBundleLimits;
}

export declare function buildCatalogBundle(input: BuildCatalogBundleInput): Promise<{
  bundle: Readonly<CatalogBundle>;
  bytes: Uint8Array;
}>;
export declare function decodeCatalogBundle(bytes: string | Uint8Array): CatalogBundle;
export declare function verifyCatalogBundle(input: {
  bytes: string | Uint8Array;
  expectedDigest: string;
  trustPolicy: CatalogBundleTrustPolicy;
  limits?: CatalogBundleLimits;
}): Promise<Readonly<CatalogBundle>>;

export interface CatalogBundleRegistry {
  readonly kind: string;
  registerCatalogBundle(input: Parameters<typeof verifyCatalogBundle>[0]): Promise<CatalogBundle>;
  readCatalogBundle(bundleDigest: string): Promise<CatalogBundle | null>;
  listCatalogBundles(): Promise<Array<{
    registryId: string;
    releaseVersion: string;
    bundleDigest: string;
    payloadDigest: string;
  }>>;
  unregisterCatalogBundle(bundleDigest: string): Promise<boolean>;
  close?(): void;
}

export declare function registerCatalogBundle(
  input: Parameters<typeof verifyCatalogBundle>[0] & { registry?: CatalogBundleRegistry | null },
): Promise<CatalogBundle>;
export declare function createMemoryCatalogBundleRegistry(input?: {
  isBundleInUse?: (bundleDigest: string) => boolean | Promise<boolean>;
}): CatalogBundleRegistry;
export declare function createSqliteCatalogBundleRegistry(input: {
  dbPath: string;
  isBundleInUse?: (bundleDigest: string) => boolean | Promise<boolean>;
  trustPolicy?: Extract<CatalogBundleTrustPolicy, { mode: "production" }>;
}): CatalogBundleRegistry;

export interface CatalogBundleMountResolver {
  readonly mounts: import("./workflow-ir.mjs").RegistryMountTable;
  readMountedBundle(registryId: string): Promise<CatalogBundle>;
  verifyMountClosure(): Promise<Array<{
    registryId: string;
    releaseVersion: string;
    bundleDigest: string;
    payloadDigest: string;
  }>>;
  listCatalogCalls(): Promise<ReadonlyArray<CallDescriptor>>;
  resolveWorkflow(callId: string, selector?: {
    version?: string | null;
    digest?: string | null;
  }): Promise<{
    bundleDigest: string;
    workflow: CatalogBundleWorkflow;
    sourceBytes: Uint8Array;
    ir: import("./workflow-ir.mjs").WorkflowIr;
  }>;
  resolveAfnContract(call: {
    callId: string;
    contractDigest: string;
  }): Promise<{
    bundleDigest: string;
    contract: Readonly<CatalogAfnContract>;
  }>;
  authorizePinnedPlan(plan: import("./pinned-plan-v4.mjs").PinnedPlanV4): Promise<{
    plan: Readonly<import("./pinned-plan-v4.mjs").PinnedPlanV4>;
    workflow?: Awaited<ReturnType<CatalogBundleMountResolver["resolveWorkflow"]>>;
  }>;
}

export declare function createCatalogBundleMountResolver(input: {
  registry: CatalogBundleRegistry;
  mounts: import("./workflow-ir.mjs").RegistryMountTable;
}): CatalogBundleMountResolver;
export declare const AFN_CONTRACT_SCHEMA_VERSION: "fastflow.afn-contract/v1";
export declare function validateAfnContract(value: unknown, label?: string): CatalogAfnContract;
export declare function digestAfnContract(value: unknown): `sha256:${string}`;
export declare function readCatalogBundleFile(
  bundle: CatalogBundle,
  filePath: string,
): Uint8Array;
