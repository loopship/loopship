export declare function createCloudflareEdhocStateProtection(input: {
  env: Record<string, unknown>;
  keyName?: string;
  keyIdName?: string;
}): Promise<{
  wrap(input: { sessionId: string; sessionEpoch: number; keyId: string | null; state: unknown }): Promise<string>;
  unwrap(input: { sessionId: string; sessionEpoch: number; keyId: string | null; wrappedState: string }): Promise<unknown>;
}>;
