export declare const AFN_SESSION_V3_SCHEMA_VERSION: "fastflow.afn-session/v3";
export declare const AFN_SESSION_V3_PROTOCOL_VERSION: "fastflow.afn.v3";
export declare const DEFAULT_AFN_SESSION_V3_MAX_MESSAGE_BYTES: number;
export declare const MAX_AFN_SESSION_V3_MESSAGE_BYTES: number;
export declare const MAX_AFN_SESSION_V3_EDHOC_MESSAGE_BYTES: number;
export declare const FRAME_TYPES: readonly [
  "HELLO",
  "PAIR",
  "EDHOC",
  "OFFER",
  "WITHDRAW",
  "ASSIGN",
  "ACK",
  "RESULT",
  "SIGNAL",
  "HEARTBEAT",
  "CLOSE",
];

export interface FastflowSessionV3Meta {
  schemaVersion: "fastflow.afn-session/v3";
  senderNodeId: string;
  recipientNodeId: string;
  sessionId: string;
  sessionEpoch: number;
  sequence: number;
  acknowledgedSequence: number;
  issuedAt: string;
  expiresAt: string;
  keyId: string;
  proof: string;
  frameDigest: `sha256:${string}`;
}

export interface FastflowSessionCredential {
  principalId: string;
  nodeId: string;
  keyId: string;
  issuer: string;
  credentialDigest: `sha256:${string}`;
  issuedAt: number;
  expiresAt: number;
}

export interface FastflowSessionEdhoc {
  meta: FastflowSessionV3Meta;
  messageNumber: 1 | 2 | 3;
  /** Base64-encoded raw RFC 9528 EDHOC message bytes. */
  message: string;
}

export type FastflowSessionV3Frame = {
  type: (typeof FRAME_TYPES)[number];
  payload: Record<string, unknown> & {
    meta: FastflowSessionV3Meta;
    sessionCredential?: FastflowSessionCredential;
  };
};

export declare function createFastflowSessionFrame(input: {
  type: FastflowSessionV3Frame["type"];
  payload: Omit<FastflowSessionV3Frame["payload"], "meta"> & {
    meta: Omit<FastflowSessionV3Meta, "frameDigest"> & { frameDigest?: string };
  };
}): Readonly<FastflowSessionV3Frame>;
export declare function validateFastflowSessionFrame(value: unknown): FastflowSessionV3Frame;
export declare function digestFastflowSessionFrame(value: unknown): `sha256:${string}`;
export declare function encodeFastflowSessionFrame(
  value: FastflowSessionV3Frame,
  options?: { maxMessageBytes?: number },
): Uint8Array;
export declare function decodeFastflowSessionFrame(
  bytes: Uint8Array | ArrayBuffer | ArrayBufferView,
  options?: { maxMessageBytes?: number },
): FastflowSessionV3Frame;
