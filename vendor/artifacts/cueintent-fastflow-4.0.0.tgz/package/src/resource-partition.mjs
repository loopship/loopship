export * from "./lib/resource-partition.mjs";
