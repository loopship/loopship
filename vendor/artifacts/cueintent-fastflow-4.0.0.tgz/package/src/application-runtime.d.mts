export declare const BUN_RUNTIME_REQUIRED_ERROR_CODE:
  "FASTFLOW_BUN_RUNTIME_REQUIRED";

export declare function assertCanonicalBunApplicationRuntime(
  component?: string,
): string;

export declare function resolveCanonicalBunExecutable(): string;
