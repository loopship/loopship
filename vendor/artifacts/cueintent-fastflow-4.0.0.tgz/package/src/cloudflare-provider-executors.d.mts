import type {
  AfnDispatchPort,
  DispatchRoute,
  JsonValue,
} from "./native-scheduler.mjs";
import type { ExecutorOffer } from "./executor-offer.mjs";

export type CloudflareHttpMethod =
  | "GET"
  | "POST"
  | "PUT"
  | "PATCH"
  | "DELETE"
  | "HEAD";

export interface CloudflareHttpPair {
  name: string;
  value: string;
}

export interface CloudflareHttpRequest {
  routeId: string;
  method: CloudflareHttpMethod;
  path: string;
  query: readonly CloudflareHttpPair[];
  headers: readonly CloudflareHttpPair[];
  body: JsonValue;
}

export interface CloudflareHttpResponse {
  status: number;
  headers: readonly CloudflareHttpPair[];
  body: JsonValue;
}

export interface CloudflareBoundaryReceiptContext {
  operation: string;
  executionId: string;
  invocationId: string;
  attempt: number;
  assignmentDigest: string;
  profileDigest: string;
}

export interface CloudflareBoundaryOutcome<TResult> {
  result: TResult;
  receipt: import("./sandbox-profile.mjs").SandboxReceipt;
}

export interface CloudflareHttpProviderPort {
  execute(input: CloudflareBoundaryReceiptContext & {
    request: CloudflareHttpRequest;
  }):
    CloudflareBoundaryOutcome<CloudflareHttpResponse> |
    Promise<CloudflareBoundaryOutcome<CloudflareHttpResponse>>;
}

export interface CloudflareProviderRoute extends DispatchRoute {
  qualifiers?: Record<string, JsonValue>;
  resourceHandles?: Array<{ type: string; handleId: string }>;
  replayPolicy?:
    | "idempotent"
    | "replay-safe"
    | "assigned-executor-only"
    | "at-most-once";
}

export interface CloudflareHttpRoute extends CloudflareProviderRoute {
  method: CloudflareHttpMethod;
}

export interface CloudflareInferenceOutputSpec {
  format: "text" | "json";
  schema: JsonValue;
}

export interface CloudflareInferenceRequest {
  routeId: string;
  prompt: string;
  input: JsonValue;
  output: CloudflareInferenceOutputSpec;
  maxTokens: number;
}

export interface CloudflareInferenceUsage {
  inputTokens: number;
  outputTokens: number;
}

export interface CloudflareInferenceResponse {
  output: JsonValue;
  finishReason: "stop" | "length" | "content-filter";
  usage: CloudflareInferenceUsage;
}

export interface CloudflareInferenceProviderPort {
  execute(input: CloudflareBoundaryReceiptContext & {
    request: CloudflareInferenceRequest;
  }):
    CloudflareBoundaryOutcome<CloudflareInferenceResponse> |
    Promise<CloudflareBoundaryOutcome<CloudflareInferenceResponse>>;
}

export interface CloudflareProviderExecutorOptions<
  TProvider extends object,
  TRoute extends CloudflareProviderRoute,
> {
  provider: TProvider;
  routes: readonly TRoute[];
  sandboxBoundary: {
    provider: string;
    profileDigest: string;
    enforcementReceipt: import("./sandbox-profile.mjs").SandboxReceipt;
    profile: import("./sandbox-profile.mjs").SandboxProfile;
  };
  executorNodeId?: string;
  sessionId?: string;
  sessionEpoch?: number;
  offerId?: string;
  offerExpiresAt?: string | null;
  durableMailbox?: boolean;
}

export interface CloudflareHttpExecutor {
  readonly provider: "cloudflare-http-provider-port";
  readonly dispatchPort: AfnDispatchPort;
  readonly offer: Readonly<ExecutorOffer>;
  close(): Promise<void>;
}

export interface CloudflareInferenceExecutor {
  readonly provider: "cloudflare-inference-provider-port";
  readonly dispatchPort: AfnDispatchPort;
  readonly offer: Readonly<ExecutorOffer>;
  close(): Promise<void>;
}

export declare const CLOUDFLARE_HTTP_PROVIDER:
  "cloudflare-http-provider-port";
export declare const CLOUDFLARE_INFERENCE_PROVIDER:
  "cloudflare-inference-provider-port";

export declare function createCloudflareHttpExecutor(
  input: CloudflareProviderExecutorOptions<
    CloudflareHttpProviderPort,
    CloudflareHttpRoute
  >,
): CloudflareHttpExecutor;

export declare function createCloudflareInferenceExecutor(
  input: CloudflareProviderExecutorOptions<
    CloudflareInferenceProviderPort,
    CloudflareProviderRoute
  >,
): CloudflareInferenceExecutor;
