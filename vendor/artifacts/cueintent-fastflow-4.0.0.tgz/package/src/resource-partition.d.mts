export interface ResourcePartition {
  schemaVersion: "fastflow.resource-partition/v1";
  partitionId: string;
  authorityId: string;
  maxInFlight: number;
  available: number;
}
export declare function createResourcePartition(input: Omit<ResourcePartition, "schemaVersion">): Readonly<ResourcePartition>;
export declare function validatePartitionSet(input: { partitions: ResourcePartition[]; maxInFlight: number }): Readonly<{ maxInFlight: number; partitions: ResourcePartition[] }>;
export declare function requireDrainedBeforeResize(input: { partition: ResourcePartition; inFlight?: number }): void;
export declare function createDurablePartitionStore(input: {
  storage: {
    get(key: string): unknown | Promise<unknown>;
    put(key: string, value: unknown): unknown | Promise<void>;
    transaction<T>(task: () => T | Promise<T>): T | Promise<T>;
  };
  maxInFlight: number;
  clock?: () => number;
}): Promise<{
  list(): Promise<ResourcePartition[]>;
  reserve(input: { partitionId: string; authorityId: string; amount?: number }): Promise<unknown>;
  release(input: { partitionId: string; amount?: number }): Promise<unknown>;
  upsert(partition: ResourcePartition): Promise<unknown>;
}>;
