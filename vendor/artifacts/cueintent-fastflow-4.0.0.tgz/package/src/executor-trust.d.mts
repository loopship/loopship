export declare const EXECUTOR_ARTIFACT_SCHEMA_VERSION: "fastflow.executor-artifact/v1";
export declare const EXECUTOR_PROVENANCE_SCHEMA_VERSION: "fastflow.executor-provenance/v1";
export declare const EXECUTOR_TRUST_POLICY_SCHEMA_VERSION: "fastflow.executor-trust-policy/v1";
export declare const EXECUTOR_ARTIFACT_CLASSES: readonly ["wasm-module", "provider-managed"];
export declare const EXECUTOR_TRUST_PLATFORMS: readonly ["bun", "cloudflare", "browser", "mobile", "zephyr", "mcu"];

export type ExecutorArtifactClass = (typeof EXECUTOR_ARTIFACT_CLASSES)[number];
export type ExecutorTrustPlatform = (typeof EXECUTOR_TRUST_PLATFORMS)[number];
export type ExecutorTrustDigest = `sha256:${string}`;

export interface ExecutorArtifactManifest {
  schemaVersion: "fastflow.executor-artifact/v1";
  implementationDigest: ExecutorTrustDigest;
  artifactDigest: ExecutorTrustDigest;
  artifactClass: ExecutorArtifactClass;
  platform: ExecutorTrustPlatform;
  publisherId: string;
  version: string;
  loader: {
    kind: "wasm-runtime" | "provider-runtime";
    owner: "executor" | "provider";
    runtimeDigest: ExecutorTrustDigest | null;
  };
  sandbox: {
    kind: "wasm-capability" | "provider-isolated";
    network: "none" | "allowlisted-egress" | "provider-managed";
    filesystem: "none" | "workspace-scoped" | "provider-managed";
    process: "none" | "isolated" | "provider-managed";
  };
  grants: string[];
  conformanceReceiptDigest: ExecutorTrustDigest;
  updatePolicy: { mode: "digest-pinned"; rollback: "owner-approved" };
}

export interface ExecutorProvenanceMaterial {
  uri: string;
  digest: ExecutorTrustDigest;
}

export interface ExecutorProvenance {
  schemaVersion: "fastflow.executor-provenance/v1";
  implementationDigest: ExecutorTrustDigest;
  artifactDigest: ExecutorTrustDigest;
  publisherId: string;
  publisherIssuer: string;
  predicateType: "https://slsa.dev/provenance/v1";
  builderId: string;
  buildType: string;
  sourceDigest: ExecutorTrustDigest;
  invocationDigest: ExecutorTrustDigest;
  materials: ExecutorProvenanceMaterial[];
  signedAt: string;
  expiresAt: string;
  sigstoreBundle: string;
}

export interface ExecutorTrustPublisherPolicy {
  publisherId: string;
  issuers: string[];
  platforms: ExecutorTrustPlatform[];
  artifactClasses: ExecutorArtifactClass[];
}

export interface ExecutorTrustSupportedArtifact {
  platform: ExecutorTrustPlatform;
  artifactClass: ExecutorArtifactClass;
  loaderKind: "wasm-runtime" | "provider-runtime";
  sandboxKind: "wasm-capability" | "provider-isolated";
  network: "none" | "allowlisted-egress" | "provider-managed";
  filesystem: "none" | "workspace-scoped" | "provider-managed";
  process: "none" | "isolated" | "provider-managed";
}

export interface ExecutorTrustPolicy {
  schemaVersion: "fastflow.executor-trust-policy/v1";
  ownerId: string;
  trustedIssuers: string[];
  trustedSigners: Array<{ signerId: string; issuer: string }>;
  trustedRoots: string;
  trustedLogRoots?: string;
  publishers: ExecutorTrustPublisherPolicy[];
  supportedArtifacts: ExecutorTrustSupportedArtifact[];
  maxProvenanceAgeMs: number;
  requireTransparencyLog: boolean;
  revocations: {
    publishers: string[];
    issuers: string[];
    artifacts: ExecutorTrustDigest[];
    implementations: ExecutorTrustDigest[];
  };
}

export interface ExecutorTrustDecision {
  schemaVersion: "fastflow.executor-trust-policy/v1";
  ownerId: string;
  implementationDigest: ExecutorTrustDigest;
  artifactDigest: ExecutorTrustDigest;
  publisherId: string;
  publisherIssuer: string;
  platform: ExecutorTrustPlatform;
  artifactClass: ExecutorArtifactClass;
  conformanceReceiptDigest: ExecutorTrustDigest;
}

export declare function createExecutorArtifact(input: Omit<ExecutorArtifactManifest, "schemaVersion">): Readonly<ExecutorArtifactManifest>;
export declare function validateExecutorArtifact(value: unknown): Readonly<ExecutorArtifactManifest>;
export declare function createExecutorProvenanceSigningPayload(value: ExecutorProvenance | Omit<ExecutorProvenance, "signature">): string;
export declare function createExecutorProvenance(input: Omit<ExecutorProvenance, "schemaVersion">): Readonly<ExecutorProvenance>;
export declare function validateExecutorProvenance(value: unknown): Readonly<ExecutorProvenance>;
export declare function createExecutorTrustPolicy(input: Omit<ExecutorTrustPolicy, "schemaVersion">): Readonly<ExecutorTrustPolicy>;
export declare function authorizeExecutorImplementation(input: {
  artifact: ExecutorArtifactManifest;
  provenance: ExecutorProvenance;
  trustPolicy: ExecutorTrustPolicy;
  verifyConformanceReceipt(input: {
    artifact: ExecutorArtifactManifest;
    provenance: ExecutorProvenance;
    policy: ExecutorTrustPolicy;
  }): boolean | Promise<boolean>;
  now?: number | string | Date;
  clockSkewMs?: number;
}): Promise<ExecutorTrustDecision>;

export declare const EXECUTOR_DEPLOYMENT_DESCRIPTOR_SCHEMA_VERSION: "fastflow.executor-deployment-descriptor/v1";
export interface ExecutorDeploymentDescriptor {
  schemaVersion: "fastflow.executor-deployment-descriptor/v1";
  provider: string; projectId: string; releaseId: string;
  codeDigest: string; configDigest: string; sandboxProfileDigest: string;
  afnContractDigests: string[]; sbomDigest: string;
  deployedAt: string; signerId: string; signature: string;
}
export declare function createExecutorDeploymentDescriptor(input: Omit<ExecutorDeploymentDescriptor,"schemaVersion">): Readonly<ExecutorDeploymentDescriptor>;
export declare function validateExecutorDeploymentDescriptor(value: unknown): Readonly<ExecutorDeploymentDescriptor>;
export interface DsseSignatureEntry {
  sig: string;
  keyid: string;
  issuer: string;
}
export interface DsseEnvelope {
  payload: string;
  payloadType: string;
  signatures: DsseSignatureEntry[];
}
export declare function createDsseEnvelope(input: {
  payload: string;
  payloadType: string;
  signature: string;
  signerId: string;
  issuer: string;
}): Readonly<DsseEnvelope>;
export declare function buildDssePreimage(input: { payload: string; payloadType: string }): string;
export declare function validateDsseEnvelope(value: unknown): Readonly<DsseEnvelope>;
