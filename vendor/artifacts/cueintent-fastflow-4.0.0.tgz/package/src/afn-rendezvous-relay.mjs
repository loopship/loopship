export {
  AFN_RENDEZVOUS_RELAY_SCHEMA_VERSION,
  createAfnRendezvousRelay,
} from "./lib/afn-rendezvous-relay.mjs";
