import type {
  RevocationRegistry,
  RevocationState,
} from "./revocation-registry.mjs";

export declare const REVOCATION_STATE_STORAGE_KEY: "ff:revocation-state";

export interface TransactionalRevocationStorage {
  get(key: string): Promise<unknown>;
  put(key: string, value: RevocationState): Promise<void>;
  transaction<T>(callback: (storage: TransactionalRevocationStorage) => Promise<T>): Promise<T>;
}

export interface TransactionalRevocationRegistry extends RevocationRegistry {
  readonly kind: "transactional";
  readonly storageKey: "ff:revocation-state";
}

export declare function createTransactionalRevocationRegistry(input: {
  storage: TransactionalRevocationStorage;
  authorityId: string;
  clock?: () => number | Date;
  publish?(state: RevocationState): void | Promise<void>;
}): Promise<TransactionalRevocationRegistry>;
