export declare const REVOCATION_STATE_SCHEMA_VERSION: "fastflow.revocation-state/v1";
export declare const REVOCATION_KINDS: readonly [
  "principals",
  "keys",
  "issuers",
  "credentials",
  "publishers",
  "artifacts",
  "enrollments",
  "implementations",
];

export type RevocationKind = (typeof REVOCATION_KINDS)[number];
export type RevocationDigest = `sha256:${string}`;

export interface RevocationState {
  schemaVersion: "fastflow.revocation-state/v1";
  authorityId: string;
  generation: number;
  updatedAt: number;
  revocations: {
    principals: string[];
    keys: string[];
    issuers: string[];
    credentials: RevocationDigest[];
    publishers: string[];
    artifacts: RevocationDigest[];
    enrollments: string[];
    implementations: RevocationDigest[];
  };
  stateDigest: RevocationDigest;
}

export interface RevocationMutationResult {
  changed: boolean;
  state: Readonly<RevocationState>;
}

export interface RevocationRegistry {
  readonly schemaVersion: "fastflow.revocation-state/v1";
  snapshot(): RevocationState;
  isRevoked(kind: RevocationKind, value: string): boolean;
  revoke(input: { kind: RevocationKind; value: string }): Promise<RevocationMutationResult>;
  apply(state: RevocationState): Promise<RevocationMutationResult>;
}

export declare function createRevocationState(input: {
  authorityId: string;
  generation?: number;
  updatedAt?: number;
  revocations?: RevocationState["revocations"];
}): Readonly<RevocationState>;
export declare function validateRevocationState(value: unknown): Readonly<RevocationState>;
export declare function digestRevocationState(value: unknown): RevocationDigest;
export declare function createRevocationRegistry(input: {
  authorityId: string;
  initialState?: RevocationState;
  clock?: () => number | Date;
  persist(state: RevocationState): void | Promise<void>;
  publish?(state: RevocationState): void | Promise<void>;
}): RevocationRegistry;
