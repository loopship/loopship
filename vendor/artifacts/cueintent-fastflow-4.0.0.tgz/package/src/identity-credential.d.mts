export declare const IDENTITY_CREDENTIAL_SCHEMA_VERSION: "fastflow.identity-credential/v1";
export declare const EDHOC_METHOD: 0;
export declare const EDHOC_SUITE: 2;
export declare const EDHOC_CIPHER: "AES-CCM-16-64-128";
export declare const EDHOC_HASH: "SHA-256";
export declare const EDHOC_KEX: "P-256";
export declare const EDHOC_SIGN: "ES256";
export declare function establishEdhocSession(input: {
  role: "initiator" | "responder";
  identity: { credential: Uint8Array; idCredential: Uint8Array };
  peerIdentity: { credential: Uint8Array; idCredential: Uint8Array };
  signPrivateKey: CryptoKey;
  peerVerifyKey: CryptoKey;
}): Promise<{
  role: "initiator" | "responder";
  machine: { completed: boolean; exporter: (label: number, context?: Uint8Array, length?: number) => Promise<Uint8Array> };
  message1: Uint8Array | null;
  message2: Uint8Array | null;
  message3: Uint8Array | null;
}>;
export declare function deriveEdhocSessionKeys(input: { edhocSession: { machine: { completed: boolean; exporter: (label: number, context?: Uint8Array, length?: number) => Promise<Uint8Array> } }; sessionId: string; direction: "scheduler->executor" | "executor->scheduler" }): Promise<{ direction: string; sessionId: string; key: Uint8Array }>;
export declare function exportCompletedEdhocSessionState(input: { edhocSession: { machine: unknown } }): {
  schemaVersion: "fastflow.edhoc-completed-state/v1";
  role: "initiator" | "responder";
  transcriptHash4: Uint8Array;
  prkExporter: Uint8Array;
};
export declare function importCompletedEdhocSessionState(input: { state: unknown }): {
  role: "initiator" | "responder";
  machine: { completed: boolean; exporter: (label: number, context?: Uint8Array, length?: number) => Promise<Uint8Array> };
};
export declare function createIdentityCredential(input: any): any;
export declare function validateIdentityCredential(value: unknown): any;
export declare function verifyIdentityCredential(input: any): Promise<any>;
export declare const COSE_ES256_ALG_ID: -7;
export declare function encodeCwtSign1(input: {
  claims: Record<string, unknown>;
  externalAad?: Uint8Array;
  signature?: Uint8Array | string;
}): Uint8Array | { protectedBytes: Uint8Array; payload: Uint8Array; sigStructure: Uint8Array; signingInput: Uint8Array };
export declare function decodeCwtSign1(bytes: Uint8Array): {
  protectedBytes: Uint8Array;
  payload: Uint8Array;
  signature: Uint8Array;
  claims: Record<string, string | null>;
};
export declare function cwtSigningInput(input: { protectedBytes: Uint8Array; payload: Uint8Array; externalAad?: Uint8Array }): Uint8Array;
