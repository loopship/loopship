import {
  existsSync,
  realpathSync,
} from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import {
  CmdProtoError,
  createRuntimeFromFile,
  runMain,
} from "cmdproto";

import { CliError } from "../lib/cli-abi.mjs";
import {
  assertCanonicalBunApplicationRuntime,
} from "../lib/application-runtime.mjs";
import { executeFastflowCmdprotoCommand } from "../lib/core-v1.mjs";

const CMDPROTO_MODULE_PATH = fileURLToPath(import.meta.url);
const CMDPROTO_MODULE_DIR = dirname(CMDPROTO_MODULE_PATH);
const FASTFLOW_REPO_ROOT = resolve(CMDPROTO_MODULE_DIR, "../..");
const FASTFLOW_CMDPROTO_DIR = join(FASTFLOW_REPO_ROOT, "dist/cmdproto");

export const FASTFLOW_SCHEMA_PATH = join(
  FASTFLOW_CMDPROTO_DIR,
  "schema.binpb",
);
export const FASTFLOW_MANIFEST_PATH = join(
  FASTFLOW_CMDPROTO_DIR,
  "runtime.binpb",
);

export const FASTFLOW_METHODS = Object.freeze({
  workflowsRun: "fastflow.v1.FastflowService.WorkflowsRun",
  workflowsResume: "fastflow.v1.FastflowService.WorkflowsResume",
  workflowsCallsList: "fastflow.v1.FastflowService.WorkflowsCallsList",
  secretsSession: "fastflow.v1.FastflowService.SecretsSession",
  secretsItem: "fastflow.v1.FastflowService.SecretsItem",
  snapshotsCapture: "fastflow.v1.FastflowService.SnapshotsCapture",
  scaffold: "fastflow.v1.FastflowService.Scaffold",
});

const COMMAND_BY_METHOD = new Map([
  [FASTFLOW_METHODS.workflowsRun, "workflows run"],
  [FASTFLOW_METHODS.workflowsResume, "workflows resume"],
  [FASTFLOW_METHODS.workflowsCallsList, "workflows calls list"],
  [FASTFLOW_METHODS.secretsSession, "secrets session"],
  [FASTFLOW_METHODS.secretsItem, "secrets item"],
  [FASTFLOW_METHODS.snapshotsCapture, "snapshots capture"],
  [FASTFLOW_METHODS.scaffold, "scaffold"],
]);

function makeHandlers(hostRuntime) {
  return Object.fromEntries(
    [...COMMAND_BY_METHOD].map(([methodName, commandPath]) => [
      methodName,
      async (params, context) => {
        assertCanonicalBunApplicationRuntime("Fastflow cmdproto handler");
        const runtime = hostRuntime ?? context?.requestContext?.hostRuntime ?? null;
        try {
          return await executeFastflowCmdprotoCommand(commandPath, params, runtime);
        } catch (error) {
          throw toCmdprotoError(error);
        }
      },
    ]),
  );
}

export const handlers = makeHandlers(null);

export function createHandlers(hostRuntime) {
  return makeHandlers(hostRuntime);
}

export function createFastflowRuntime({
  schemaPath = FASTFLOW_SCHEMA_PATH,
  manifestPath = FASTFLOW_MANIFEST_PATH,
  additionalHandlers = {},
} = {}) {
  ensureFastflowCmdprotoAssets({ schemaPath, manifestPath });
  return createRuntimeFromFile(
    { ...handlers, ...additionalHandlers },
    schemaPath,
    manifestPath,
  );
}

export async function runFastflowCmdprotoCli(
  argv = process.argv.slice(2),
  {
    schemaPath = FASTFLOW_SCHEMA_PATH,
    manifestPath = FASTFLOW_MANIFEST_PATH,
    stdin,
    hostRuntime = null,
  } = {},
) {
  assertCanonicalBunApplicationRuntime("Fastflow cmdproto CLI");
  ensureFastflowCmdprotoAssets({ schemaPath, manifestPath });
  const boundHandlers = hostRuntime ? makeHandlers(hostRuntime) : handlers;
  return runMain({
    handlers: boundHandlers,
    schemaPath,
    manifestPath,
    argv: normalizeFastflowCmdprotoArgv(argv),
    stdin,
  });
}

export function normalizeFastflowCmdprotoArgv(argv = []) {
  return [...argv];
}

export function ensureFastflowCmdprotoAssets({ schemaPath, manifestPath }) {
  const missing = [schemaPath, manifestPath].filter((filePath) => !existsSync(filePath));
  if (missing.length > 0) {
    throw new Error(
      `Fastflow cmdproto runtime assets are missing: ${missing.join(", ")}; ` +
      "run npm run cmdproto:schema before packaging",
    );
  }
}

function toCmdprotoError(error) {
  if (error instanceof CmdProtoError) {
    return error;
  }
  if (error instanceof CliError) {
    return new CmdProtoError(
      normalizeCmdprotoErrorCode(error.code),
      error.message,
      error.details ?? undefined,
    );
  }
  return error;
}

function normalizeCmdprotoErrorCode(code) {
  if (code === "invalid-request") {
    return "INVALID_ARGUMENT";
  }
  if (code === "unsupported-command") {
    return "METHOD_NOT_FOUND";
  }
  return String(code || "INTERNAL")
    .replace(/[^A-Za-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .toUpperCase() || "INTERNAL";
}

function isFastflowCmdprotoEntrypoint(entrypointPath) {
  if (!entrypointPath) return false;
  try {
    return realpathSync(resolve(entrypointPath)) === realpathSync(CMDPROTO_MODULE_PATH);
  } catch {
    return resolve(entrypointPath) === CMDPROTO_MODULE_PATH;
  }
}

if (isFastflowCmdprotoEntrypoint(process.argv[1])) {
  await runFastflowCmdprotoCli();
}
