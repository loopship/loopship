export declare const AFN_WSS_WEBSOCKET_SUBPROTOCOL: "fastflow.afn.v3";
export declare const DEFAULT_AFN_WSS_WEBSOCKET_MAX_MESSAGE_BYTES: 1048576;
export declare const MAX_AFN_WSS_WEBSOCKET_MESSAGE_BYTES: 16777216;

export interface AfnWssWebSocketLike {
  readonly bufferedAmount?: number;
  binaryType?: string;
  send(value: Uint8Array): void;
  close(code?: number, reason?: string): void;
  addEventListener?(
    type: string,
    listener: (...args: unknown[]) => void,
  ): void;
  removeEventListener?(
    type: string,
    listener: (...args: unknown[]) => void,
  ): void;
  on?(type: string, listener: (...args: unknown[]) => void): void;
  off?(type: string, listener: (...args: unknown[]) => void): void;
  removeListener?(type: string, listener: (...args: unknown[]) => void): void;
}

export interface AfnWssWebSocketCarrier {
  readonly bufferedAmount: number;
  send(value: Uint8Array): void;
  subscribe(input: {
    onMessage(value: Uint8Array): Promise<void>;
    onClose(event: Record<string, unknown>): void;
  }): () => void;
  close(code?: number, reason?: string): void;
}

export interface AfnWssWebSocketCarrierOptions {
  socket: AfnWssWebSocketLike;
  maxMessageBytes?: number;
}

export declare function createAfnWssWebSocketCarrier(
  socket: AfnWssWebSocketLike,
  options?: Omit<AfnWssWebSocketCarrierOptions, "socket">,
): AfnWssWebSocketCarrier;
export declare function createAfnWssWebSocketCarrier(
  options: AfnWssWebSocketCarrierOptions,
): AfnWssWebSocketCarrier;

export interface AfnWssDirectEndpoint {
  mode: "direct";
  url: string;
}

export interface AfnWssWebSocketConstructor {
  new (url: string, protocol: string): AfnWssWebSocketLike;
}

export declare function dialAfnWssWebSocketCarrier(input: {
  endpoint: string | AfnWssDirectEndpoint;
  WebSocket?: AfnWssWebSocketConstructor | null;
  webSocketConstructor?: AfnWssWebSocketConstructor | null;
  timeoutMs?: number;
  maxMessageBytes?: number;
}): Promise<AfnWssWebSocketCarrier>;
