import type { PinnedPlanV4 } from "./pinned-plan-v4.mjs";
import type { WorkflowIr } from "./workflow-ir.mjs";

export declare const CONSTRAINED_SCHEDULER_PROFILE_SCHEMA_VERSION:
  "fastflow.constrained-scheduler-profile/v1";

export interface ConstrainedSchedulerProfile {
  schemaVersion: "fastflow.constrained-scheduler-profile/v1";
  catalog: {
    maxFiles: number;
    maxFileBytes: number;
    maxBundleBytes: number;
  };
  artifacts: {
    maxIrBytes: number;
    maxPlanBytes: number;
    maxInputBytes: number;
    maxWorkflows: number;
    maxCalls: number;
    maxMounts: number;
    maxProgramSteps: number;
    maxJsonDepth: number;
  };
  reducer: {
    maxOperations: number;
    maxStackDepth: number;
  };
  store: {
    maxCheckpointBytes: number;
    maxEventBytes: number;
    maxMailboxBytes: number;
    maxEventsPerExecution: number;
  };
}

export declare const CONSTRAINED_SCHEDULER_DEFAULT_PROFILE:
  Readonly<ConstrainedSchedulerProfile>;

type Tightened<T> = { [K in keyof T]?: number };

export declare function createConstrainedSchedulerProfile(overrides?: {
  catalog?: Tightened<ConstrainedSchedulerProfile["catalog"]>;
  artifacts?: Tightened<ConstrainedSchedulerProfile["artifacts"]>;
  reducer?: Tightened<ConstrainedSchedulerProfile["reducer"]>;
  store?: Tightened<ConstrainedSchedulerProfile["store"]>;
}): Readonly<ConstrainedSchedulerProfile>;

export declare function validateConstrainedWorkflowIr(
  value: unknown,
  options?: { profile?: ConstrainedSchedulerProfile },
): WorkflowIr;

export declare function validateConstrainedPinnedPlanV4(
  value: unknown,
  options?: { profile?: ConstrainedSchedulerProfile },
): PinnedPlanV4;

export declare function constrainedReducerLimits(
  profile?: ConstrainedSchedulerProfile,
): Readonly<{ maxOperations: number; maxStackDepth: number }>;
