export declare const NODE_SESSION_LOCATOR_SCHEMA_VERSION:
  "fastflow.node-session-locator/v1";
export declare const NODE_SESSION_LOCATOR_DEFAULT_TTL_MS: number;
export declare const NODE_SESSION_LOCATOR_MAX_TTL_MS: number;

export interface NodeSessionLocatorEndpoint {
  mode: "direct" | "rendezvous";
  url: string;
}

export interface NodeSessionLocatorCapabilities {
  planVersions: Array<"fastflow.pinned-plan/v4">;
  workflowIrVersions: Array<"fastflow.workflow-ir/v1">;
  routingModes: Array<"capability-pool" | "exact-host">;
  maxMessageBytes: number;
  maxInFlight: number;
}

export interface NodeSessionLocator {
  schemaVersion: "fastflow.node-session-locator/v1";
  payload: {
    nodeIdentity: string;
    nodeRoles: Array<"compiler" | "scheduler" | "executor" | "gateway" | "dashboard">;
    protocolVersion: "fastflow.afn.v3";
    trustScope: string;
    issuedAt: string;
    expiresAt: string;
    endpoints: NodeSessionLocatorEndpoint[];
    capabilities: NodeSessionLocatorCapabilities;
  };
  signature: {
    kind: "node-locator-signature";
    signerId: string;
    algorithm: "Ed25519";
    signature: string;
  };
}

export interface NodeLocatorTrustPolicy {
  trustedSignerIds: string[];
  verifyEvidence(input: {
    evidence: NodeSessionLocator["signature"];
    payload: string;
  }): boolean | Promise<boolean>;
}

export declare function createNodeSessionLocator(input: {
  nodeIdentity: string;
  nodeRoles: Array<"compiler" | "scheduler" | "executor" | "gateway" | "dashboard">;
  trustScope: string;
  endpoints: NodeSessionLocatorEndpoint[];
  capabilities: NodeSessionLocatorCapabilities;
  issuedAt?: string;
  expiresAt?: string | null;
  ttlMs?: number;
  signPayload(input: {
    payload: string;
    nodeIdentity: string;
    nodeRoles: Array<"compiler" | "scheduler" | "executor" | "gateway" | "dashboard">;
    trustScope: string;
  }): NodeSessionLocator["signature"] | Promise<NodeSessionLocator["signature"]>;
}): Promise<Readonly<NodeSessionLocator>>;

export declare function validateNodeSessionLocator(
  value: unknown,
): Readonly<NodeSessionLocator>;

export declare function verifyNodeSessionLocator(input: {
  locator: unknown;
  expectedNodeIdentity: string;
  expectedTrustScope: string;
  trustPolicy: NodeLocatorTrustPolicy;
  now?: number | string | Date;
  clockSkewMs?: number;
}): Promise<Readonly<NodeSessionLocator>>;

export declare function createWebCryptoNodeLocatorSigner(input: {
  signerId: string;
  privateKey: string | Uint8Array | CryptoKey;
  crypto?: Crypto;
}): (input: {
  payload: string;
  nodeIdentity: string;
  nodeRoles: Array<"compiler" | "scheduler" | "executor" | "gateway" | "dashboard">;
  trustScope: string;
}) => Promise<NodeSessionLocator["signature"]>;

export declare function createWebCryptoNodeLocatorTrustPolicy(input: {
  trustRoots: string | Array<{
    signerId: string;
    algorithm: "Ed25519";
    publicKey: string | Uint8Array;
  }>;
  crypto?: Crypto;
}): Readonly<NodeLocatorTrustPolicy>;
