export { createAfnWssSessionPort } from "./lib/afn-wss-session-port.mjs";
