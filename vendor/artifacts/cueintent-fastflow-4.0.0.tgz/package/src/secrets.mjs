export * from "./lib/daemon/build-id.mjs";
export * from "./lib/daemon/protocol.mjs";
export * from "./lib/daemon/secret-client.mjs";
export * from "./lib/daemon/secret-server.mjs";
export * from "./lib/secret-adapters/adapter-registry.mjs";
export * from "./lib/secret-adapters/bitwarden-cli.mjs";
export * from "./lib/secret-adapters/bitwarden-session.mjs";
export * from "./lib/secret-store.mjs";

// Keep the lifecycle exports available through the Fastflow secrets facade.
export {
  activateSecretStoreSession,
  assertSecretStoreReady,
  clearSecretStoreSession,
  ensureLoginSecretRef,
  getSecretStoreStatusSummary,
} from "./lib/secret-manager-runtime.mjs";

export { DEFAULT_SECRET_STORE } from "./lib/secret-store.mjs";
