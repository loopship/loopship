export * from "./lib/daemon/build-id.mjs";
export * from "./lib/daemon/protocol.mjs";
export * from "./lib/daemon/secret-client.mjs";
export * from "./lib/daemon/secret-server.mjs";
export * from "./lib/secret-adapters/adapter-registry.mjs";
export * from "./lib/secret-adapters/bitwarden-cli.mjs";
export * from "./lib/secret-adapters/bitwarden-session.mjs";
export * from "./lib/secret-store.mjs";

// Preserve the public secret-store lifecycle facade for consumers that load
// `@cueintent/fastflow/secrets` directly.  The implementation now lives in
// the vendored manager; the local module above intentionally keeps only the
// Fastflow-specific binding helpers.
export {
  activateSecretStoreSession,
  assertSecretStoreReady,
  clearSecretStoreSession,
  ensureLoginSecretRef,
  getSecretStoreStatusSummary,
} from "../vendor/secret-manager/src/lib/secret-store.mjs";

export { DEFAULT_SECRET_STORE } from "./lib/secret-store.mjs";
