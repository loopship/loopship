export * from "./lib/revocation-registry.mjs";
