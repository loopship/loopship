import type { AfnAssignment, SchedulerAfnAssignment } from "./afn-assignment.mjs";
import type { PinnedPlanV4, PlanRouting } from "./pinned-plan-v4.mjs";
import type { ExecutorOffer } from "./executor-offer.mjs";
import type { ResourceHandle, ResourceLease } from "./resource-contracts.mjs";
import type { SandboxReceipt } from "./sandbox-profile.mjs";

export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

export type CompletionPolicy =
  | "all_success"
  | "all_settled"
  | "first_success"
  | "first_settled";

export interface NativeRef {
  kind: string;
  ref: string;
}

export interface ResourceHandleRef {
  type: string;
  handleId: string;
}

export interface InvocationGrant extends NativeRef {
  scope?: JsonValue;
}

export interface ExactCallContract {
  callId: string;
  contractDigest: string;
}

export interface PinnedPlanNodeInput {
  nodeId: string;
  dependencies: string[];
  call: ExactCallContract;
  input: JsonValue;
  inputBindings?: Array<{
    target: string;
    sourceNodeId: string;
    source: string;
  }>;
  bindingRefs?: NativeRef[];
  grants?: InvocationGrant[];
  deadline?: string | null;
}

export type AnyPinnedPlan = PinnedPlanV4;

export interface AfnInvocation {
  schemaVersion: "fastflow.afn-invocation/v2";
  executionId: string;
  nodeId: string;
  invocationId: string;
  attempt: number;
  call: ExactCallContract;
  input: JsonValue;
  effectKey: string;
  deadline: string | null;
  bindingRefs: NativeRef[];
  resourceHandles: ResourceHandleRef[];
  grants: InvocationGrant[];
  resume?: JsonValue;
}

export interface DecisionError {
  code: string;
  message: string;
  retryable?: boolean;
  details?: JsonValue;
}

export type ExecutionDecision =
  | {
      schemaVersion: "fastflow.execution-decision/v2";
      invocationId: string;
      kind: "completed";
      output: JsonValue;
    }
  | {
      schemaVersion: "fastflow.execution-decision/v2";
      invocationId: string;
      kind: "failed";
      error: DecisionError & { retryable: boolean };
    }
  | {
      schemaVersion: "fastflow.execution-decision/v2";
      invocationId: string;
      kind: "awaiting";
      wait:
        | { type: "signal"; key: string; until?: string }
        | { type: "timer"; key: string; until: string };
      checkpoint: JsonValue;
    }
  | {
      schemaVersion: "fastflow.execution-decision/v2";
      invocationId: string;
      kind: "continue";
      checkpoint: JsonValue;
    }
  | {
      schemaVersion: "fastflow.execution-decision/v2";
      invocationId: string;
      kind: "retry";
      retryAfterMs: number;
      error?: DecisionError;
    }
  | {
      schemaVersion: "fastflow.execution-decision/v2";
      invocationId: string;
      kind: "cancelled";
      reason: string;
    };

export interface ExecutionEventBase<TType extends string, TData> {
  schemaVersion: "fastflow.execution-event/v4";
  executionId: string;
  sequence: number;
  eventId: string;
  type: TType;
  occurredAt: string;
  data: TData;
}

export interface ExecutionEventError {
  code: string;
  message: string;
}

export interface ExecutionFailure extends ExecutionEventError {
  result: JsonValue;
}

export interface PersistedSchedulerSignal {
  signalId: string;
  key: string;
  payload: JsonValue;
}

export type ExecutionEvent =
  | ExecutionEventBase<
      "execution.submitted",
      { idempotencyKey: string; plan: PinnedPlanV4 }
    >
  | ExecutionEventBase<
      "execution.cancel_requested",
      { reason: string; operationId?: string }
    >
  | ExecutionEventBase<"execution.awaiting", Record<string, never>>
  | ExecutionEventBase<
      "execution.join_selected",
      {
        policy: "first_success" | "first_settled";
        winnerNodeId: string;
        cancelNodeIds: string[];
      }
    >
  | ExecutionEventBase<"execution.completed", { output: JsonValue }>
  | ExecutionEventBase<"execution.failed", { error: ExecutionFailure }>
  | ExecutionEventBase<"execution.cancelled", { reason: string }>
  | ExecutionEventBase<
      "signal.received",
      { nodeId: string; signal: PersistedSchedulerSignal }
    >
  | ExecutionEventBase<
      "signal.rejected",
      { signalId: string; key: string; error: ExecutionEventError }
    >
  | ExecutionEventBase<
      "timer.fired",
      { nodeId: string; timerId: string; key: string }
    >
  | ExecutionEventBase<
      "node.dispatch_intended",
      { nodeId: string; invocation: AfnInvocation; assignment: AfnAssignment }
    >
  | ExecutionEventBase<"node.dispatch_started", { nodeId: string; invocationId: string }>
  | ExecutionEventBase<"node.dispatch_waiting", { nodeId: string; invocationId: string }>
  | ExecutionEventBase<
      "node.executor_waiting",
      { nodeId: string; invocationId: string }
    >
  | ExecutionEventBase<
      "node.executor_disconnected",
      {
        nodeId: string;
        invocationId: string;
        assignmentDigest: string;
        executorNodeId: string;
        sessionEpoch: number;
      }
    >
  | ExecutionEventBase<
      "node.dispatch_reassigned",
      {
        nodeId: string;
        invocation: AfnInvocation;
        assignment: AfnAssignment;
        previousAssignmentDigest: string;
        generation: number;
      }
    >
  | ExecutionEventBase<
      "node.dispatch_deferred",
      { nodeId: string; invocationId: string; retryAt: string; error: ExecutionEventError }
    >
  | ExecutionEventBase<
      "node.cancellation_intended",
      { nodeId: string; invocationId: string; reason: string }
    >
  | ExecutionEventBase<"node.decision_recorded", { nodeId: string; decision: ExecutionDecision }>
  | ExecutionEventBase<"node.blocked", { nodeId: string; error: ExecutionEventError }>
  | ExecutionEventBase<"node.cancelled", { nodeId: string; reason: string }>
  | ExecutionEventBase<
      "node.late_decision",
      { nodeId: string; invocationId: string; decision: ExecutionDecision }
    >
  | ExecutionEventBase<
      "workflow.reduced",
      { checkpoint: Record<string, JsonValue>; command: Record<string, JsonValue> & { type: string } }
    >
  | ExecutionEventBase<"workflow.signal_received", { signal: PersistedSchedulerSignal }>
  | ExecutionEventBase<"workflow.timer_fired", { timerId: string; key: string }>;

export type ExecutionEventDraft = {
  [K in ExecutionEvent["type"]]: {
    type: K;
    data: Extract<ExecutionEvent, { type: K }> ["data"];
    occurredAt?: string;
    schemaVersion?: "fastflow.execution-event/v4";
  };
}[ExecutionEvent["type"]];

export interface SchedulerSignal {
  schemaVersion: "fastflow.scheduler-signal/v2";
  signalId: string;
  key: string;
  payload: JsonValue;
}

export interface NativeSchedulerProfile {
  schemaVersion: "fastflow.scheduler-profile/v4";
  profileId: "fastflow.scheduler.portable/v1";
  mode: "local-durable" | "durable-authority" | "active-runtime" | "embedded" | "test";
  conformance: {
    submission: "idempotent";
    dispatch: "at-least-once";
    events: "ordered-resumable";
    cancellationOwner: "scheduler";
  };
  durability: {
    plan: "persistent" | "ephemeral";
    events: "authoritative" | "process-local";
    timers: "recoverable" | "process-local";
    wake: "recoverable" | "active-only" | "process-local";
  };
  limits: { maxPlanNodes: number; maxEventBytes: number };
}

export interface DispatchRoute {
  routeId: string;
  callId: string;
  contractDigest: string;
  implementationDigest: string;
  descriptor?: JsonValue;
  replayPolicy?: "idempotent" | "replay-safe" | "assigned-executor-only" | "at-most-once";
  sandbox?: "none" | "wasm-capability" | "provider-isolated";
  providerBoundary?: {
    provider: string;
    profileDigest: string;
    enforcementReceipt: SandboxReceipt;
    profile: import("./sandbox-profile.mjs").SandboxProfile;
  };
  wasmBoundary?: {
    profileDigest: string;
    enforcementReceipt: SandboxReceipt;
    profile: import("./sandbox-profile.mjs").SandboxProfile;
  };
}

export interface AfnBindingPort {
  listRoutes(): DispatchRoute[];
  bind(input: {
    executionId: string;
    nodeId: string;
    effectKey: string;
    call: ExactCallContract;
    input: JsonValue;
    bindingContext: JsonValue;
  }): Promise<{
    bindingRefs?: NativeRef[];
    resourceHandles?: ResourceHandleRef[];
    grants?: InvocationGrant[];
    qualifiers?: Record<string, JsonValue>;
    replayPolicy?: "idempotent" | "replay-safe" | "assigned-executor-only" | "at-most-once";
  }>;
}

export interface AfnDispatchPort extends AfnBindingPort {
  readonly durableMailbox?: boolean;
  readonly atomicExecutorAssignment?: boolean;
  preflight?(invocation: AfnInvocation): AfnInvocation | Promise<AfnInvocation>;
  supportsCall?(call: ExactCallContract): boolean;
  assignExecutor?(
    invocation: AfnInvocation,
    routing: PlanRouting,
    options?: { excludeOfferIds?: string[] },
  ): Promise<{
    executorNodeId: string;
    sessionId: string;
    sessionEpoch: number;
    offerDigest: string;
    implementationDigest: string;
    offer: ExecutorOffer;
  } | null>;
  releaseExecutorAssignment?(input: {
    invocationId: string;
    executorNodeId?: string;
    sessionEpoch?: number;
  }): boolean | Promise<boolean>;
  dispatch(
    invocation: AfnInvocation,
    assignment?: SchedulerAfnAssignment | null,
  ): Promise<ExecutionDecision>;
  cancel(request: AfnCancellationRequest): Promise<{ accepted: boolean }>;
}

export interface AfnCancellationRequest {
  executionId: string;
  nodeId: string;
  invocationId: string;
  attempt: number;
  effectKey: string;
  call: ExactCallContract;
  bindingRefs: NativeRef[];
  resourceHandles: ResourceHandleRef[];
  reason: string;
}

export interface ExecutionStore {
  readonly atomicAfnMailbox?: boolean;
  readonly atomicAfnAssignment?: boolean;
  append(executionId: string, event: ExecutionEventDraft): Promise<ExecutionEvent>;
  appendWithWake?(
    executionId: string,
    event: ExecutionEventDraft,
    wake?: { timer?: { timerId: string; nodeId: string; dueAt: number } | null },
  ): Promise<ExecutionEvent>;
  appendIfCurrent(
    executionId: string,
    event: ExecutionEventDraft,
    options: {
      expectedSequence: number;
      timer?: { timerId: string; nodeId: string; dueAt: number } | null;
      completeTimerIds?: string[];
      completeAllTimers?: boolean;
      afnAssignment?: AfnAssignment | null;
      afnReassignment?: {
        assignment: AfnAssignment;
        previousAssignmentDigest: string;
        generation: number;
      } | null;
      executorDispatch?: { executorNodeId: string; invocation: AfnInvocation; nowMs: number } | null;
      assertActive?: () => void;
    },
  ): Promise<{ appended: boolean; event: ExecutionEvent | null }>;
  ensureSubmitted(
    executionId: string,
    event: Extract<ExecutionEventDraft, { type: "execution.submitted" }>,
  ): Promise<{ created: boolean; event: ExecutionEvent }>;
  ensureChildSubmitted?(
    parentExecutionId: string,
    executionId: string,
    event: Extract<ExecutionEventDraft, { type: "execution.submitted" }>,
  ): Promise<{ created: boolean; event: ExecutionEvent }>;
  listChildExecutions?(parentExecutionId: string): Promise<string[]>;
  recordSignal(
    executionId: string,
    signal: { signalId: string; key: string; payload?: JsonValue },
    event: Extract<ExecutionEventDraft, { type: "signal.received" | "timer.fired" }>,
    options?: { expectedSequence?: number | null; completeTimerIds?: string[]; assertActive?: () => void },
  ): Promise<{ created: boolean; event: ExecutionEvent | null; stale?: boolean }>;
  read(executionId: string, options?: { afterSequence?: number }): Promise<ExecutionEvent[]>;
  subscribe(executionId: string, listener: (event: ExecutionEvent) => void): () => void;
  listExecutionIds(): Promise<string[]>;
  listActiveExecutionIds?(): Promise<string[]>;
  isCatalogBundleInUse?(bundleDigest: string): Promise<boolean>;
}

export interface NativeSchedulerBackend {
  readonly profile: NativeSchedulerProfile;
  submit(request: {
    executionId: string;
    idempotencyKey: string;
    plan: AnyPinnedPlan;
    parentExecutionId?: string | null;
  }): Promise<ExecutionHandle>;
  inspect(request: { executionId: string }): Promise<ExecutionHandle>;
  signal(request: { executionId: string; signal: { signalId: string; key: string; payload?: JsonValue } }): Promise<ExecutionHandle>;
  cancel(request: { executionId: string; reason?: string; operationId?: string | null }): Promise<ExecutionHandle>;
  readEvents(request: { executionId: string; afterSequence?: number; limit?: number }): Promise<{
    events: ExecutionEvent[];
    nextSequence: number;
    hasMore: boolean;
  }>;
  subscribe(request: { executionId: string; afterSequence?: number }): AsyncIterable<ExecutionEvent>;
  recordDecision(request: { executionId: string; invocationId: string; decision: ExecutionDecision }): Promise<ExecutionHandle>;
  recover(request: { executionId: string }): Promise<ExecutionHandle>;
  wakeExecutorWaiters(): Promise<ReadonlyArray<ExecutionHandle>>;
  handleExecutorUnavailable(input: {
    executorNodeId: string;
    sessionEpoch: number;
    offerDigest?: string;
  }): Promise<ReadonlyArray<ExecutionHandle>>;
}

export interface ResourceLeasePort {
  acquireForAssignment?(input: Record<string, unknown>): ResourceLease | Promise<ResourceLease>;
  resolveHandle?(reference: { type: string; handleId: string }): ResourceHandle | Promise<ResourceHandle> | null;
  acquire?(input: {
    handle: ResourceHandle;
    executorNodeId: string;
    operations: string[];
    executionId: string;
    invocation: AfnInvocation;
  }): ResourceLease | Promise<ResourceLease>;
  releaseForAssignment?(input: Record<string, unknown>): unknown | Promise<unknown>;
  release?(input: { leaseId: string; fencingGeneration: number }): unknown | Promise<unknown>;
}

export declare const NATIVE_SCHEDULER_PROFILE_ID: "fastflow.scheduler.portable/v1";
export declare const NATIVE_SCHEDULER_PROFILE_SCHEMA_VERSION: "fastflow.scheduler-profile/v4";
export declare const PINNED_PLAN_SCHEMA_VERSION: "fastflow.pinned-plan/v4";
export declare const AFN_INVOCATION_SCHEMA_VERSION: "fastflow.afn-invocation/v2";
export declare const EXECUTION_DECISION_SCHEMA_VERSION: "fastflow.execution-decision/v2";
export declare const EXECUTION_EVENT_SCHEMA_VERSION: "fastflow.execution-event/v4";
export declare const SCHEDULER_SIGNAL_SCHEMA_VERSION: "fastflow.scheduler-signal/v2";
export declare const SCHEDULER_RUNNABLE_SCHEMA_VERSION: "fastflow.scheduler-runnable/v1";
export declare const MAX_RETRY_AFTER_MS: 31536000000;

export declare function canonicalJson(value: JsonValue): string;
export declare function digestNativeContract(value: JsonValue): string;
export declare function digestCallContract(value: JsonValue): string;
export declare function assertPortableExecutionId(value: unknown, label?: string): string;
export declare function assertPlainJson(value: unknown, label?: string): void;
export declare function assertNoResolvedSecrets(value: unknown, label?: string): void;

export declare function createNativeSchedulerProfile(overrides?: {
  mode?: NativeSchedulerProfile["mode"];
  conformance?: Partial<NativeSchedulerProfile["conformance"]>;
  durability?: Partial<NativeSchedulerProfile["durability"]>;
  limits?: Partial<NativeSchedulerProfile["limits"]>;
}): NativeSchedulerProfile;
export declare function createEmbeddedSchedulerProfile(overrides?: Parameters<typeof createNativeSchedulerProfile>[0]): NativeSchedulerProfile;
export declare function validateNativeSchedulerProfile(value: unknown): NativeSchedulerProfile;
export declare function isDurableSchedulerProfile(value: unknown): boolean;
export declare function pinPlan(input: Parameters<typeof import("./pinned-plan-v4.mjs").pinPlanV4>[0]): Readonly<PinnedPlanV4>;
export declare function validatePinnedPlan(value: unknown): PinnedPlanV4;
export declare function createAfnInvocation(input: Omit<AfnInvocation, "schemaVersion" | "deadline"> & { deadline?: string | null }): AfnInvocation;
export declare function validateAfnInvocation(value: unknown): AfnInvocation;
export declare function completedDecision(input: { invocationId: string; output?: JsonValue }): ExecutionDecision;
export declare function failedDecision(input: { invocationId: string; error: DecisionError & { retryable: boolean } }): ExecutionDecision;
export declare function awaitingDecision(input: { invocationId: string; wait: { type: "signal"; key: string; until?: string } | { type: "timer"; key: string; until: string }; checkpoint?: JsonValue }): ExecutionDecision;
export declare function continueDecision(input: { invocationId: string; checkpoint: JsonValue }): ExecutionDecision;
export declare function retryDecision(input: { invocationId: string; retryAfterMs: number; error?: DecisionError | null }): ExecutionDecision;
export declare function cancelledDecision(input: { invocationId: string; reason: string }): ExecutionDecision;
export declare function validateExecutionDecision(value: unknown): ExecutionDecision;
export declare function validateExecutionEvent(value: unknown): ExecutionEvent;
export declare function createSchedulerSignal(input: { signalId: string; key: string; payload?: JsonValue }): SchedulerSignal;
export declare function validateSchedulerSignal(value: unknown): SchedulerSignal;
export declare function createExecutionHandle(input: Omit<ExecutionHandle, "schemaVersion">): ExecutionHandle;
export declare function validateExecutionHandle(value: unknown): ExecutionHandle;
export declare function createAfnDispatchPort(input: {
  routes: Array<DispatchRoute & { handler(
    invocation: AfnInvocation,
    assignment?: SchedulerAfnAssignment | null,
  ): Promise<ExecutionDecision> | ExecutionDecision }>;
  bind?: AfnBindingPort["bind"];
  cancel?: AfnDispatchPort["cancel"];
  executorNodeId?: string;
  sessionId?: string;
  sessionEpoch?: number;
  offerId?: string;
  offerExpiresAt?: string | null;
  durableMailbox?: boolean;
}): AfnDispatchPort;
export declare function createAfnBindingPort(dispatchPort: AfnBindingPort): AfnBindingPort;
export declare function decisionsEquivalent(left: ExecutionDecision, right: ExecutionDecision): boolean;

export declare function createMemoryExecutionStore(): ExecutionStore;
export declare function createNativeSchedulerBackend(input: {
  store: ExecutionStore;
  dispatchPort: AfnDispatchPort;
  clock?: () => Date | string;
  faultInjector?: (point: string, context: Record<string, unknown>) => void | Promise<void>;
  dispatchRetryMs?: number;
  profile?: NativeSchedulerProfile;
  wakeAuthority?: DurableWakeAuthority;
  wakeAuthorityOwnerId?: string | null;
  wakeAuthorityLeaseMs?: number;
  leaseOwnerId?: string;
  leaseMs?: number;
  authorizePlan?: ((plan: PinnedPlanV4) => PinnedPlanV4 | { plan: PinnedPlanV4 } | Promise<PinnedPlanV4 | { plan: PinnedPlanV4 }>) | null;
  resourceLeasePort?: ResourceLeasePort | null;
}): NativeSchedulerBackend;

export interface DurableWakeAuthority {
  claimRunnableExecutions(input?: { nowMs?: number; claimMs?: number }): Promise<Array<{ executionId: string; generation: number }>>;
  completeRunnableExecution(executionId: string, generation: number): Promise<void>;
  enqueueTimer(executionId: string, timer: { timerId: string; nodeId: string; dueAt: number }): Promise<void>;
  claimDueTimers(input?: { nowMs?: number; claimMs?: number }): Promise<Array<{ executionId: string; timerId: string; nodeId: string; dueAt: number }>>;
  completeTimer(executionId: string, timerId: string): Promise<void>;
  enqueueSignal(executionId: string, signal: { signalId: string; key: string; payload?: JsonValue }): Promise<void>;
  listReadySignalExecutionIds(input?: { nowMs?: number }): Promise<string[]>;
  claimSignals(executionId: string, input?: { nowMs?: number; claimMs?: number }): Promise<Array<{ signalId: string; key: string; payload: JsonValue }>>;
  completeSignal(executionId: string, signalId: string): Promise<void>;
  releaseSignal(executionId: string, signalId: string): Promise<void>;
  failSignal(executionId: string, signalId: string, error: unknown): Promise<void>;
  acquireLease(executionId: string, input: { ownerId: string; nowMs?: number; leaseMs?: number }): Promise<boolean>;
  reclaimExpiredLeases(input?: { nowMs?: number }): Promise<string[]>;
  releaseLease(executionId: string, input: { ownerId: string }): Promise<void>;
  heartbeatWakeAuthority(ownerId: string, input?: { nowMs?: number; leaseMs?: number }): Promise<void>;
  renewOwnedExecutionLeases?(ownerId: string, input?: { nowMs?: number; leaseMs?: number }): Promise<number>;
  unregisterWakeAuthority(ownerId: string): Promise<void>;
  hasActiveWakeAuthority(input?: { nowMs?: number }): Promise<boolean>;
  refreshWakeAuthorityRegistration?(ownerId: string, input?: { nowMs?: number; leaseMs?: number }): Promise<boolean>;
  claimSchedulerAuthority?(ownerId: string, input?: { pid?: number; nowMs?: number }): Promise<{ claimed: boolean; ownerId: string; pid: number }>;
  releaseSchedulerAuthority?(ownerId: string): Promise<void>;
  readNextSchedulerWakeAt?(input?: { nowMs?: number }): Promise<number | null>;
}

export declare function createSqliteExecutionStore(input: { dbPath: string }): ExecutionStore & DurableWakeAuthority & {
  readonly kind: "local-durable";
  readonly dbPath: string;
  close(): void;
};
export declare function assertLocalDurableFilesystem(localDurablePath: string): void;

export interface LocalDurableSqliteStatement {
  get(...parameters: unknown[]): Record<string, unknown> | undefined;
  all(...parameters: unknown[]): Array<Record<string, unknown>>;
  run(...parameters: unknown[]): unknown;
}
export interface LocalDurableSqliteDatabase {
  exec(sql: string): unknown;
  prepare(sql: string): LocalDurableSqliteStatement;
  protectFiles(): void;
  close(): void;
}
export declare function openLocalDurableSqliteDatabase(dbPath: string, DatabaseConstructor: new (path: string) => unknown, options?: { busyTimeoutMs?: number }): {
  readonly absolutePath: string;
  readonly db: LocalDurableSqliteDatabase;
};

export interface SchedulerRuntimeDescriptor {
  schemaVersion: "fastflow.scheduler-runtime-descriptor/v4";
  instanceId: string;
  pid: number;
  createdAt: string;
  controlBaseUrl: string;
  controlCapability: string;
  dashboardCapability: string;
  catalogCapability: string;
  enrollmentCapability: string;
  sourceIdentity: Record<string, JsonValue>;
}
export declare function createSchedulerDaemon(input: Record<string, unknown>): {
  readonly ownerId: string;
  start(): Promise<void>;
  stop(): Promise<void>;
  tick(input?: { recoverAll?: boolean }): Promise<JsonValue>;
  activate(): Promise<void>;
  notify(): void;
};
export declare function createSchedulerControlClient(input?: { descriptorPath?: string; timeoutMs?: number }): SchedulerControlClient;
export declare function readSchedulerRuntimeDescriptor(input?: { descriptorPath?: string }): SchedulerRuntimeDescriptor;
export declare function resolveSchedulerRuntimeDescriptorPath(input?: { descriptorPath?: string }): string;

export interface ExecutionHandle {
  schemaVersion: "fastflow.execution-handle/v4";
  executionId: string;
  planId: string;
  planDigest: string;
  status: "pending" | "running" | "awaiting" | "completed" | "failed" | "cancelled";
  cursor: number;
  output?: JsonValue;
  error?: JsonValue;
  nodes?: JsonValue[];
}

export interface SchedulerControlCatalogProjection {
  schemaVersion: "fastflow.catalog-summary/v1";
  registryId: string;
  releaseVersion: string;
  bundleDigest: string;
  payloadDigest: string;
  rootCatalogPath: string;
  files: Array<{ path: string; mediaType: string; byteLength: number; digest: string }>;
  workflows: Array<{ callId: string; version: string; workflowDigest: string; irDigest: string }>;
  registries: Array<{ registryId: string; bundleDigest: string }>;
  signers: Array<{ kind: string; signerId: string; algorithm: string }>;
}
export interface SchedulerControlCatalogList {
  schemaVersion: "fastflow.catalog-list/v1";
  catalogs: Array<{ registryId: string; releaseVersion: string; bundleDigest: string; payloadDigest: string }>;
  truncated: boolean;
}
export interface SchedulerControlExecutorList {
  schemaVersion: "fastflow.executor-list/v1";
  executors: Array<{ executorNodeId: string; sessionId: string; sessionEpoch: number; offers: ExecutorOffer[] }>;
  truncated: boolean;
}
export interface SchedulerControlAssignmentList {
  schemaVersion: "fastflow.assignment-list/v1";
  assignments: AfnAssignment[];
  truncated: boolean;
}
export interface SchedulerControlNodeProjection {
  schemaVersion: "fastflow.node-capabilities/v1";
  identity: string;
  roles: string[];
  authority: "single-owner";
  storage: string;
  wake: string;
  activeOnly: boolean;
  compilerLevel: "yaml-and-ir" | "verified-ir";
  connectivity: { directWss: boolean; relayRendezvous: boolean };
  limits?: Record<string, number>;
}
export interface SchedulerControlClient {
  submit(request: { executionId: string; idempotencyKey: string; plan: PinnedPlanV4 }): Promise<ExecutionHandle>;
  inspect(request: { executionId: string }): Promise<ExecutionHandle>;
  signal(request: { executionId: string; signal: { signalId: string; key: string; payload?: JsonValue } }): Promise<ExecutionHandle>;
  cancel(request: { executionId: string; operationId: string; reason: string }): Promise<ExecutionHandle>;
  readEvents(request: { executionId: string; afterSequence?: number; limit?: number }): Promise<{ events: Array<{ sequence: string; event: ExecutionEvent }>; nextSequence: string; hasMore: boolean }>;
  subscribe(request: { executionId: string; afterSequence?: number }): AsyncIterable<ExecutionEvent>;
  registerCatalogBundle(request: { operationId: string; expectedDigest: string; bytes: string | Uint8Array }): Promise<SchedulerControlCatalogProjection>;
  listCatalogBundles(): Promise<SchedulerControlCatalogList>;
  inspectCatalogBundle(request: { bundleDigest: string }): Promise<SchedulerControlCatalogProjection>;
  unregisterCatalogBundle(request: { operationId: string; bundleDigest: string }): Promise<{ removed: boolean }>;
  listExecutors(): Promise<SchedulerControlExecutorList>;
  inspectExecutionAssignments(request: { executionId: string }): Promise<SchedulerControlAssignmentList>;
  inspectNode(): Promise<SchedulerControlNodeProjection>;
  recover(request: { executionId: string }): Promise<ExecutionHandle>;
  createPairingInvite(request: { operationId: string; request: JsonValue }): Promise<JsonValue>;
  approvePairing(request: { operationId: string; request: JsonValue }): Promise<JsonValue>;
  renewCredential(request: { operationId: string; request: JsonValue }): Promise<JsonValue>;
  revokeEnrollment(request: { operationId: string; request: JsonValue }): Promise<JsonValue>;
}

export declare function createLocalDurableSchedulerAuthority(input?: Record<string, unknown>): {
  readonly descriptor: SchedulerRuntimeDescriptor | null;
  readonly dbPath: string;
  readonly failed: Promise<Error>;
  start(): Promise<SchedulerRuntimeDescriptor>;
  stop(): Promise<void>;
};
