import type { SandboxProfile, WasmCapabilityAbi } from "./sandbox-profile.mjs";

export declare const WASM_EXECUTOR_SANDBOX_SCHEMA_VERSION: "fastflow.wasm-executor-sandbox/v1";
export declare const WASM_BUILTIN_BACKEND_VERSION: string;
export declare const WASM_BUILTIN_BACKEND_DIGEST: string;

export interface WasmSandboxViolation {
  code: string;
  message: string;
  backend: string;
  startedAt: number;
  endedAt: number;
  exitCode: number | null;
  wallTimeMs: number;
}

export interface WasmSandboxReceipt {
  schemaVersion: "fastflow.sandbox-receipt/v1";
  profileDigest: string;
  executionId: string;
  invocationId: string;
  assignmentId: string;
  attempt: number;
  backend: { kind: string; version: string; runtimeDigest: string | null };
  enforcementMode: "enforced" | "unavailable";
  violations: Array<{ code: string; message: string; at: string }>;
  resourceUsage: { cpuMs: number; memoryBytes: number; wallTimeMs: number; outputBytes: number };
  exit: { code: number; signal: string | null };
  receiptDigest: string;
}

export interface WasmSandboxResult {
  value: number | null;
  receipt: WasmSandboxReceipt;
  violation: WasmSandboxViolation | null;
}

export interface WasmAdapterHandlerInput {
  moduleBase64: string;
  profile: SandboxProfile;
  abi: WasmCapabilityAbi;
  grants?: string[];
  functionName: string;
  args?: Array<number>;
  wallTimeMs?: number;
  maxOutputBytes?: number;
}

export type WasmAdapterHandler = (
  invocation: import("./native-scheduler.mjs").AfnInvocation,
  assignment?: import("./afn-assignment.mjs").SchedulerAfnAssignment | null,
) => Promise<import("./native-scheduler.mjs").ExecutionDecision>;

export declare function createWasmAdapterHandler(
  input: WasmAdapterHandlerInput,
): WasmAdapterHandler;

export declare function runWasmSandboxed(input: {
  moduleBase64: string;
  profile: SandboxProfile;
  abi: WasmCapabilityAbi;
  grants?: string[];
  functionName: string;
  args?: Array<number>;
  wallTimeMs?: number;
  maxOutputBytes?: number;
  executionId?: string | null;
  invocationId?: string | null;
  assignmentId?: string | null;
  attempt?: number;
  clock?: () => number;
}): Promise<WasmSandboxResult>;
