export declare const SANDBOX_PROFILE_SCHEMA_VERSION: "fastflow.sandbox-profile/v1";
export declare const SANDBOX_RECEIPT_SCHEMA_VERSION: "fastflow.sandbox-receipt/v1";
export declare const WASM_CAPABILITY_ABI_SCHEMA_VERSION: "fastflow.wasm-capability-abi/v1";
export declare const WASM_ABI_VERSION: "1.0.0";
export declare const SANDBOX_BACKEND_KINDS: readonly ["seatbelt","bubblewrap","windows","wasm-builtin","wasm-wasmtime","wasm-wamr","provider"];
export declare const SANDBOX_NETWORK_MODES: readonly ["none","allowlisted-egress","provider-managed"];
export type SandboxProfile = {
  schemaVersion: "fastflow.sandbox-profile/v1";
  profileId: string;
  backend: { kind: string; runtimeDigest: string|null; version: string };
  readAllowlist: string[];
  write: { workspace: string; tmp: { path: string; maxBytes: number; maxFiles: number }};
  network: { mode: string; allowlist: string[] };
  process: { allowFork: boolean; allowExec: boolean; maxProcesses: number };
  resources: { cpuMs: number; memoryBytes: number; wallTimeMs: number; outputBytes: number };
  devices: { allow: string[] };
  systemAutomation: { allowAppleEvents: boolean; allowDeviceControl: boolean; allowCDP: boolean };
  secrets: Array<{kind:"secret_ref"|"secret_locator"; ref:string}>;
  grants: string[];
};
export interface SandboxReceiptViolation {
  code: string;
  message: string;
  at: string;
}
export interface SandboxReceipt {
  schemaVersion: "fastflow.sandbox-receipt/v1";
  profileDigest: string;
  executionId: string;
  invocationId: string;
  assignmentId: string;
  attempt: number;
  backend: { kind: string; version: string; runtimeDigest: string|null };
  enforcementMode: "enforced" | "unavailable";
  violations: SandboxReceiptViolation[];
  resourceUsage: { cpuMs: number; memoryBytes: number; wallTimeMs: number; outputBytes: number };
  exit: { code: number; signal: string|null };
  receiptDigest: string;
}
export type SandboxReceiptInput = Omit<SandboxReceipt, "receiptDigest" | "schemaVersion">;
export declare function createSandboxReceipt(input: SandboxReceiptInput): Readonly<SandboxReceipt>;
export declare function validateSandboxReceipt(value: unknown): Readonly<SandboxReceipt>;
export declare function digestSandboxReceipt(value: unknown): string;
export declare function createSandboxProfile(input: Omit<SandboxProfile,"schemaVersion">): Readonly<SandboxProfile>;
export declare function validateSandboxProfile(value: unknown): Readonly<SandboxProfile>;
export declare function digestSandboxProfile(value: unknown): string;

export type WasmAbiImportKind = "function" | "memory" | "table" | "global";
export interface WasmAbiImport {
  module: string;
  name: string;
  kind: WasmAbiImportKind;
}
export interface WasmCapabilityAbi {
  schemaVersion: "fastflow.wasm-capability-abi/v1";
  abiVersion: string;
  capabilities: string[];
  imports: WasmAbiImport[];
}
export declare function createWasmCapabilityAbi(input: Omit<WasmCapabilityAbi, "schemaVersion">): Readonly<WasmCapabilityAbi>;
export declare function validateWasmCapabilityAbi(value: unknown): Readonly<WasmCapabilityAbi>;
