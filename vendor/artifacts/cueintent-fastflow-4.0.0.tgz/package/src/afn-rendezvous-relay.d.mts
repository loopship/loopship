export declare const AFN_RENDEZVOUS_RELAY_SCHEMA_VERSION:
  "fastflow.afn-rendezvous-relay/v1";

export interface AfnRendezvousRelayEndpoint {
  readonly schemaVersion: "fastflow.afn-rendezvous-relay/v1";
  readonly rendezvousId: string;
  readonly side: "scheduler" | "executor";
  readonly sessionId: string;
  readonly peerConnected: boolean;
  send(
    bytes: Uint8Array | ArrayBuffer | ArrayBufferView,
    options?: { sensitive?: boolean },
  ): Uint8Array;
  close(reason?: string): boolean;
}

export interface AfnRendezvousRelay {
  readonly schemaVersion: "fastflow.afn-rendezvous-relay/v1";
  createRendezvous(input: {
    rendezvousId: string;
    expiresAt?: string | null;
  }): Promise<Readonly<{
    schemaVersion: "fastflow.afn-rendezvous-relay/v1";
    rendezvousId: string;
    expiresAt: string;
  }>>;
  connect(input: {
    rendezvousId: string;
    side: "scheduler" | "executor";
    sessionId: string;
    onFrame?: (bytes: Uint8Array) => void | Promise<void>;
    onPeerClosed?: (event: Record<string, unknown>) => void;
  }): Promise<AfnRendezvousRelayEndpoint>;
  expire(): number;
  listRendezvous(): ReadonlyArray<Readonly<{
    schemaVersion: "fastflow.afn-rendezvous-relay/v1";
    rendezvousId: string;
    expiresAt: string;
    sides: string[];
  }>>;
  close(): void;
}

export declare function createAfnRendezvousRelay(input?: {
  clock?: () => number | Date;
  ttlMs?: number;
  maxMessageBytes?: number;
}): AfnRendezvousRelay;
