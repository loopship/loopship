export {
  capturePageSemanticCandidates,
  captureStepSemanticArtifacts,
} from "../lib/semantic-snapshot.mjs";
