type CallCatalogScopeDocument = Record<string, unknown>;

export declare function generateWorkflowCallCatalog(options: {
  registry: string;
  store: string;
  workflowsRoot?: string | null;
}): Promise<CallCatalogScopeDocument>;

export declare function refreshWorkflowCallCatalogForPromotion(options: {
  workflowDir: string;
  store: string;
}): Promise<Record<string, unknown> | null>;

export declare function writeShardedCallCatalog(options: {
  catalog: CallCatalogScopeDocument;
  outputRoot: string;
  catalogTags?:
    | Record<string, string | string[]>
    | Map<string, string | string[]>
    | null;
  onlyGroups?: string[] | null;
  writeRootIndex?: boolean;
}): Promise<void>;

export declare function writeWorkflowCallCatalog(options: {
  registry: string;
  store: string;
  workflowsRoot: string;
  outputRoot?: string;
  catalogTags?:
    | Record<string, string | string[]>
    | Map<string, string | string[]>
    | null;
  onlyGroups?: string[] | null;
  writeRootIndex?: boolean;
}): Promise<Record<string, unknown>>;
