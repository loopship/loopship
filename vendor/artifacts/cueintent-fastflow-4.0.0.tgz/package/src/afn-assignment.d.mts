export declare const AFN_ASSIGNMENT_SCHEMA_VERSION:
  "fastflow.scheduler-afn-assignment/v1";

export interface SchedulerAfnAssignment {
  schemaVersion: "fastflow.scheduler-afn-assignment/v1";
  executionId: string;
  workflowNodeId: string;
  invocationId: string;
  attempt: number;
  callId: string;
  contractDigest: `sha256:${string}`;
  executorNodeId: string;
  implementationDigest: `sha256:${string}`;
  routingMode: "exact-host" | "capability-pool";
  selectorDigest: `sha256:${string}`;
  offerDigest: `sha256:${string}`;
  sessionId: string;
  sessionEpoch: number;
  resourceLeases: import("./resource-contracts.mjs").ResourceLease[];
  replayPolicy:
    | "idempotent"
    | "replay-safe"
    | "assigned-executor-only"
    | "at-most-once";
  assignedAt: string;
  assignmentDigest: `sha256:${string}`;
}

export type AfnAssignment = SchedulerAfnAssignment;

export declare function createAfnAssignment(
  input: Omit<SchedulerAfnAssignment, "schemaVersion" | "assignmentDigest">,
): Readonly<SchedulerAfnAssignment>;
export declare function createSchedulerAfnAssignment(
  input: Omit<SchedulerAfnAssignment, "schemaVersion" | "assignmentDigest">,
): Readonly<SchedulerAfnAssignment>;
export declare function validateAfnAssignment(value: unknown): SchedulerAfnAssignment;
export declare function validateSchedulerAssignment(value: unknown): SchedulerAfnAssignment;
