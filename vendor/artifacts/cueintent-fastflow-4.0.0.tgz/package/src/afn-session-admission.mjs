export {
  AFN_SESSION_ADMISSION_SCHEMA_VERSION,
  createAfnSessionAdmission,
} from "./lib/afn-session-admission.mjs";
