import type {
  CatalogBundle,
  CatalogBundleRegistry,
  CatalogBundleTrustPolicy,
} from "./catalog-bundle.mjs";
import type { PinnedPlanV4 } from "./pinned-plan-v4.mjs";
import type { AfnDispatchPort, ResourceLeasePort } from "./native-scheduler.mjs";

export interface DurableObjectStorageLike {
  get(key: string): Promise<unknown>;
  put(key: string | Record<string, unknown>, value?: unknown): Promise<void>;
  delete(key: string): Promise<void>;
  list(options?: { prefix?: string }): Promise<Map<string, unknown>>;
  transaction<T>(callback: (transaction: DurableObjectStorageLike) => Promise<T>): Promise<T>;
  setAlarm?(scheduledTime: number): Promise<void>;
  getAlarm?(): Promise<number | null>;
  deleteAlarm?(): Promise<void>;
}

export interface CloudflareWebSocketLike {
  send(value: Uint8Array): void;
  close(code?: number, reason?: string): void;
  serializeAttachment(value: unknown): void;
  deserializeAttachment(): unknown;
}

export interface CloudflareDurableObjectContextLike {
  storage: DurableObjectStorageLike;
  getWebSockets(tag?: string): CloudflareWebSocketLike[];
  acceptWebSocket(socket: CloudflareWebSocketLike, tags?: string[]): void;
  blockConcurrencyWhile(callback: () => Promise<void>): Promise<void>;
}

export interface CloudflareAuthority {
  readonly identity: string;
  readonly store: Record<string, unknown>;
  readonly catalogRegistry: CatalogBundleRegistry;
  readonly router: Record<string, unknown>;
  readonly backend: Record<string, unknown>;
  ready(): Promise<CloudflareAuthority>;
  registerCatalogBundle(
    request: Parameters<CatalogBundleRegistry["registerCatalogBundle"]>[0],
  ): Promise<CatalogBundle>;
  unregisterCatalogBundle(bundleDigest: string): Promise<boolean>;
  listCatalogBundles(): ReturnType<CatalogBundleRegistry["listCatalogBundles"]>;
  readCatalogBundle(bundleDigest: string): Promise<CatalogBundle | null>;
  submit(request: {
    executionId: string;
    idempotencyKey: string;
    plan: PinnedPlanV4 | Record<string, unknown>;
  }): Promise<Record<string, unknown>>;
  inspect(request: { executionId: string }): Promise<Record<string, unknown>>;
  signal(request: {
    executionId: string;
    signal: { signalId: string; key: string; payload: unknown };
  }): Promise<Record<string, unknown>>;
  cancel(request: {
    executionId: string;
    operationId?: string | null;
    reason?: string;
  }): Promise<Record<string, unknown>>;
  readEvents(request: {
    executionId: string;
    afterSequence?: number;
    limit?: number;
  }): Promise<{ events: Record<string, unknown>[]; nextSequence: number; hasMore: boolean }>;
  recover(request: { executionId: string }): Promise<Record<string, unknown>>;
  connectExecutor(request: Record<string, unknown>): Promise<Record<string, unknown>>;
  publishOffer(request: Record<string, unknown>): Promise<Record<string, unknown>>;
  withdrawExecutor(request: Record<string, unknown>): Promise<boolean>;
  listExecutors(): Record<string, unknown>[];
  listAssignments(executionId: string): Promise<Record<string, unknown>[]>;
  alarm(): Promise<Record<string, unknown>>;
  close(): Promise<void>;
}

export declare function createCloudflareDurableObjectAuthority(input: {
  storage: DurableObjectStorageLike;
  identity: string;
  clock?: () => number | string | Date;
  randomId?: () => string;
  maxInFlight?: number;
  maxMessageBytes?: number;
  leaseMs?: number;
  executorPort?: AfnDispatchPort | null;
  resourceLeasePort?: Record<string, unknown> | null;
  authorizeOffer?: (input: Record<string, unknown>) => Promise<boolean> | boolean;
  authorizeAssignment?: (input: Record<string, unknown>) => Promise<boolean> | boolean;
  validateSession?: (input: Record<string, unknown>) => Promise<boolean> | boolean;
  onFatalError?: ((error: unknown) => void) | null;
}): CloudflareAuthority;

export declare function createDurableObjectExecutionStore(input: {
  storage: DurableObjectStorageLike;
  authorityOwnerId: string;
  clock?: () => number | string | Date;
  randomId?: () => string;
}): Record<string, unknown>;

export declare function createDurableObjectCatalogBundleRegistry(input: {
  storage: DurableObjectStorageLike;
  isBundleInUse?: (bundleDigest: string) => boolean | Promise<boolean>;
}): CatalogBundleRegistry;

export interface CloudflareCatalogTrustRoot {
  signerId: string;
  algorithm: "Ed25519";
  publicKey: string;
}

export declare function createCloudflareCatalogTrustPolicy(input?: {
  mode?: "production" | "local-development";
  trustRoots?: string | CloudflareCatalogTrustRoot[] | null;
  crypto?: Crypto;
}): CatalogBundleTrustPolicy;
export declare function cloudflareCatalogTrustPolicyFromEnv(
  env: Record<string, unknown>,
): CatalogBundleTrustPolicy;

export declare const CLOUDFLARE_SCHEDULER_CONTROL_MAX_BYTES: number;
export declare const CLOUDFLARE_SCHEDULER_CONNECT_PATHS: readonly string[];
export declare const CLOUDFLARE_AFN_SESSION_PATH: "/afn/v3/session";
export declare const CLOUDFLARE_CATALOG_BUNDLES_PATH: "/internal/catalogs/v1/bundles";
export declare const CLOUDFLARE_DASHBOARD_SNAPSHOT_PATH: "/internal/dashboard/v1/snapshot";
export declare const CLOUDFLARE_INTERNAL_AUTHORITY_HEADER: "x-fastflow-public-origin";
export declare const CLOUDFLARE_PUBLIC_CATALOG_BUNDLES_PATH: "/catalogs/v1/bundles";
export declare const CLOUDFLARE_PUBLIC_DASHBOARD_SNAPSHOT_PATH: "/dashboard/v1/snapshot";
export declare const CLOUDFLARE_PUBLIC_NODE_LOCATOR_PATH: "/node/v1/locator";

export interface CloudflareSchedulerDurableObject {
  readonly authority: CloudflareAuthority;
  readonly rehydrated: unknown[];
  ready(): Promise<this>;
  fetch(request: Request): Promise<Response>;
  alarm(): Promise<void>;
  webSocketMessage(socket: CloudflareWebSocketLike, message: ArrayBuffer | Uint8Array): Promise<void>;
  webSocketClose(socket: CloudflareWebSocketLike): Promise<void>;
  webSocketError(socket: CloudflareWebSocketLike): Promise<void>;
}

export declare function createCloudflareSchedulerDurableObjectClass(input?: {
  clock?: () => number | string | Date;
  randomId?: () => string;
  webSocketPairFactory?: () => Record<string, CloudflareWebSocketLike>;
  upgradeResponseFactory?: (client: CloudflareWebSocketLike, protocol: string) => Response;
  authorizeSession?: (input: Record<string, unknown>) =>
    Promise<Record<string, unknown> | null> | Record<string, unknown> | null;
  authorizeOffer?: (input: Record<string, unknown>) =>
    Promise<boolean> | boolean;
  authorizeAssignment?: (input: Record<string, unknown>) =>
    Promise<boolean> | boolean;
  validateSession?: (input: Record<string, unknown>) =>
    Promise<boolean> | boolean;
  sessionProtection?: (input: {
    admission: Record<string, unknown>;
    sessionId: string;
    sessionEpoch: number;
  }) => Promise<{
    edhocSession: Record<string, unknown>;
    transcriptDigest: string;
  } | null> | { edhocSession: Record<string, unknown>; transcriptDigest: string } | null;
  /** Creates the scheduler-owned EDHOC responder for the v3 control exchange. */
  edhocResponder?: (input: {
    admission: Record<string, unknown>;
    sessionId: string;
    sessionEpoch: number;
    restoredState?: unknown;
  }) => Promise<{
    completed: boolean;
    exportState(): unknown;
    receive(input: { messageNumber: 1 | 2 | 3; message: string }): Promise<{ messageNumber: 1 | 2 | 3; message: string } | null>;
    send(port: unknown, input: { meta: unknown }): Promise<unknown>;
    configurePort(port: unknown): Promise<{ keyId: string }>;
  }>;
  /** Resolve the scheduler EDHOC responder from the Durable Object env. */
  edhocResponderFactory?: (input: {
    env: Record<string, unknown>;
    ctx: CloudflareDurableObjectContextLike;
    clock: () => number | string | Date;
    randomId: () => string;
  }) => ((input: {
    admission: Record<string, unknown>;
    sessionId: string;
    sessionEpoch: number;
    restoredState?: unknown;
  }) => Promise<{
    completed: boolean;
    exportState(): unknown;
    receive(input: { messageNumber: 1 | 2 | 3; message: string }): Promise<{ messageNumber: 1 | 2 | 3; message: string } | null>;
    send(port: unknown, input: { meta: unknown }): Promise<unknown>;
    configurePort(port: unknown): Promise<{ keyId: string }>;
  }>) | null | Promise<((input: {
    admission: Record<string, unknown>;
    sessionId: string;
    sessionEpoch: number;
    restoredState?: unknown;
  }) => Promise<{
    completed: boolean;
    exportState(): unknown;
    receive(input: { messageNumber: 1 | 2 | 3; message: string }): Promise<{ messageNumber: 1 | 2 | 3; message: string } | null>;
    send(port: unknown, input: { meta: unknown }): Promise<unknown>;
    configurePort(port: unknown): Promise<{ keyId: string }>;
  }>) | null>;
  /** Owner-controlled encrypted EDHOC hibernation state boundary. */
  edhocStateProtection?: {
    wrap(input: {
      sessionId: string;
      sessionEpoch: number;
      keyId: string | null;
      state: unknown;
    }): Promise<string | Uint8Array> | string | Uint8Array;
    unwrap(input: {
      sessionId: string;
      sessionEpoch: number;
      keyId: string | null;
      wrappedState: string | Uint8Array;
    }): Promise<unknown> | unknown;
  };
  /** Resolve the owner-controlled hibernation state port from the DO env. */
  edhocStateProtectionFactory?: (input: {
    env: Record<string, unknown>;
    ctx: CloudflareDurableObjectContextLike;
    clock: () => number | string | Date;
    randomId: () => string;
  }) => {
    wrap(input: {
      sessionId: string;
      sessionEpoch: number;
      keyId: string | null;
      state: unknown;
    }): Promise<string | Uint8Array> | string | Uint8Array;
    unwrap(input: {
      sessionId: string;
      sessionEpoch: number;
      keyId: string | null;
      wrappedState: string | Uint8Array;
    }): Promise<unknown> | unknown;
  } | null | Promise<{
    wrap(input: {
      sessionId: string;
      sessionEpoch: number;
      keyId: string | null;
      state: unknown;
    }): Promise<string | Uint8Array> | string | Uint8Array;
    unwrap(input: {
      sessionId: string;
      sessionEpoch: number;
      keyId: string | null;
      wrappedState: string | Uint8Array;
    }): Promise<unknown> | unknown;
  } | null>;
  executorPort?: AfnDispatchPort | null;
  resourceLeasePort?: (ResourceLeasePort & { resolveHandle: NonNullable<ResourceLeasePort["resolveHandle"]> }) | null;
  enrollmentAdmin?: Record<string, unknown> | ((input: Record<string, unknown>) => Record<string, unknown>);
}): new (
  context: CloudflareDurableObjectContextLike,
  env: Record<string, unknown>,
) => CloudflareSchedulerDurableObject;

export declare function createCloudflareFastflowWorker(input?: {
  bindingName?: string;
}): {
  fetch(request: Request, env: Record<string, unknown>): Promise<Response>;
};
