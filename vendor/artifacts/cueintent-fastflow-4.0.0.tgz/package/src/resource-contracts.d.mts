export declare const RESOURCE_HANDLE_SCHEMA_VERSION: "fastflow.resource-handle/v1";
export declare const RESOURCE_LEASE_SCHEMA_VERSION: "fastflow.resource-lease/v1";

export type ResourceReplayPolicy =
  | "idempotent"
  | "replay-safe"
  | "assigned-executor-only"
  | "at-most-once";

export interface ResourceHandle {
  schemaVersion: "fastflow.resource-handle/v1";
  resourceType: string;
  resourceId: string;
  ownerExecutorNodeId: string;
  affinityScope: {
    kind: "execution" | "workflow" | "tenant" | "executor";
    scopeId: string;
  };
  permittedOperations: string[];
  recoveryPolicy: "preserve" | "reacquire" | "discard";
  replayPolicy: ResourceReplayPolicy;
  handleDigest: `sha256:${string}`;
}

export interface ResourceLease {
  schemaVersion: "fastflow.resource-lease/v1";
  handle: ResourceHandle;
  leaseId: string;
  authorityId: string;
  state: "active" | "released" | "expired" | "fenced";
  validFrom: string;
  validUntil: string;
  fencingGeneration: number;
  leaseDigest: `sha256:${string}`;
}

export interface ResourceLeaseManager {
  readonly schemaVersion: "fastflow.resource-lease/v1";
  acquire(input: {
    handle: ResourceHandle;
    executorNodeId: string;
    operations: string[];
    leaseId?: string | null;
    ttlMs?: number;
  }): Readonly<ResourceLease>;
  release(input: { leaseId: string; fencingGeneration: number }): Readonly<ResourceLease>;
  fence(input: { leaseId: string; fencingGeneration: number }): Readonly<ResourceLease>;
  revoke(input: { leaseId: string; fencingGeneration: number }): Readonly<ResourceLease>;
  assertCurrent(input: { leaseId: string; fencingGeneration: number; executorNodeId: string; operation: string }): ResourceLease;
  renew(input: { leaseId: string; fencingGeneration: number; ttlMs?: number }): Readonly<ResourceLease>;
  expire(now?: number | string | Date): number;
  get(input: { leaseId: string }): ResourceLease | null;
  list(): ResourceLease[];
}

export interface DurableResourceLeaseManager {
  readonly schemaVersion: "fastflow.resource-lease/v1";
  acquire(input: {
    handle: ResourceHandle;
    executorNodeId: string;
    operations: string[];
    leaseId?: string | null;
    ttlMs?: number;
  }): Promise<Readonly<ResourceLease>>;
  release(input: { leaseId: string; fencingGeneration: number }): Promise<Readonly<ResourceLease>>;
  fence(input: { leaseId: string; fencingGeneration: number }): Promise<Readonly<ResourceLease>>;
  revoke(input: { leaseId: string; fencingGeneration: number }): Promise<Readonly<ResourceLease>>;
  assertCurrent(input: { leaseId: string; fencingGeneration: number; executorNodeId: string; operation: string }): Promise<ResourceLease>;
  renew(input: { leaseId: string; fencingGeneration: number; ttlMs?: number }): Promise<Readonly<ResourceLease>>;
  expire(now?: number | string | Date): Promise<number>;
  get(input: { leaseId: string }): Promise<ResourceLease | null>;
  list(): Promise<ResourceLease[]>;
}

export declare function createResourceHandle(
  input: Omit<ResourceHandle, "schemaVersion" | "handleDigest">,
): Readonly<ResourceHandle>;
export declare function validateResourceHandle(value: unknown): ResourceHandle;
export declare function digestResourceHandle(value: unknown): `sha256:${string}`;
export declare function resourceHandleRef(value: ResourceHandle): {
  type: string;
  handleId: string;
};
export declare function createResourceLease(input: {
  handle: ResourceHandle;
  leaseId: string;
  authorityId: string;
  state?: ResourceLease["state"];
  validFrom: string;
  validUntil: string;
  fencingGeneration: number;
}): Readonly<ResourceLease>;
export declare function validateResourceLease(value: unknown): ResourceLease;
export declare function digestResourceLease(value: unknown): `sha256:${string}`;
export declare function createResourceLeaseManager(input: {
  authorityId: string;
  now?: () => number | string | Date;
  leaseIdFactory?: () => string;
}): ResourceLeaseManager;
export declare function createDurableResourceLeaseManager(input: {
  storage: {
    get(key: string): unknown | Promise<unknown>;
    put(key: string, value: unknown): unknown | Promise<unknown>;
    transaction<T>(task: (storage?: unknown) => T | Promise<T>): T | Promise<T>;
  };
  authorityId: string;
  now?: () => number | string | Date;
  leaseIdFactory?: () => string;
}): DurableResourceLeaseManager;
