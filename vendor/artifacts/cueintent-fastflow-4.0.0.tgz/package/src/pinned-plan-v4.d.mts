import type {
  CompletionPolicy,
  InvocationGrant,
  JsonValue,
  NativeRef,
  PinnedPlanNodeInput,
} from "./native-scheduler.mjs";
import type { RegistryMountTable } from "./workflow-ir.mjs";

export declare const PINNED_PLAN_V4_SCHEMA_VERSION: "fastflow.pinned-plan/v4";

export type AfnReplayPolicy =
  | "idempotent"
  | "replay-safe"
  | "assigned-executor-only"
  | "at-most-once";

export interface PinnedPlanExactCall {
  callId: string;
  contractDigest: string;
}

export interface PlanRoutingRequirements {
  qualifiers: Record<string, JsonValue>;
  resourceHandles: Array<{ type: string; handleId: string }>;
  replayPolicy: AfnReplayPolicy;
  implementationDigest?: string;
}

export type PlanRouting =
  | ({ mode: "exact-host"; executorNodeId: string } & PlanRoutingRequirements)
  | ({ mode: "capability-pool" } & PlanRoutingRequirements);

export interface PinnedPlanV4Node {
  nodeId: string;
  dependencies: string[];
  call: PinnedPlanExactCall;
  input: JsonValue;
  inputBindings: Array<{ target: string; sourceNodeId: string; source: string }>;
  bindingRefs: NativeRef[];
  grants: InvocationGrant[];
  deadline: string | null;
  routing: PlanRouting;
}

export type PinnedPlanV4NodeInput = PinnedPlanNodeInput & { routing: PlanRouting };

export interface PinnedPlanV4 {
  schemaVersion: "fastflow.pinned-plan/v4";
  planId: string;
  planDigest: string;
  schedulerProfile: "fastflow.scheduler.portable/v1";
  source: { kind: "afn" | "workflow" | "skill"; ref: string; digest: string };
  closure: {
    sources: Array<{ kind: "afn" | "workflow" | "skill"; ref: string; digest: string }>;
    calls: PinnedPlanExactCall[];
    registryMounts: RegistryMountTable;
    workflowIrDigest: string | null;
  };
  completionPolicy: CompletionPolicy;
  maxConcurrency: number;
  workflow: null | {
    ir: import("./workflow-ir.mjs").WorkflowIr;
    inputs: Record<string, JsonValue>;
    routingOverrides: Record<string, PlanRouting>;
  };
  nodes: PinnedPlanV4Node[];
}

export declare function pinPlanV4(input: {
  planId: string;
  planDigest?: string;
  source: PinnedPlanV4["source"];
  closure: PinnedPlanV4["closure"];
  completionPolicy?: CompletionPolicy;
  maxConcurrency?: number;
  workflow?: PinnedPlanV4["workflow"];
  nodes?: PinnedPlanV4NodeInput[];
}): Readonly<PinnedPlanV4>;
export declare function validatePinnedPlanV4(value: unknown): PinnedPlanV4;
export declare function validatePlanRouting(value: unknown): PlanRouting;
