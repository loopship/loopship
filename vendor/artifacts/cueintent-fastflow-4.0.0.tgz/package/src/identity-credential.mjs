export * from "./lib/identity-credential.mjs";
