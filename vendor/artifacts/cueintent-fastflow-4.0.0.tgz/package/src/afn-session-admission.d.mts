export declare const AFN_SESSION_ADMISSION_SCHEMA_VERSION: "fastflow.afn-session-admission/v2";

export type AfnSessionAdmissionRisk = "low" | "medium" | "high";

export interface AfnSessionAdmissionPrincipal {
  schemaVersion: "fastflow.afn-session-admission/v2";
  state: "authorized";
  mode: "authenticated" | "managed" | "paired";
  nodeId: string;
  keyId: string;
  principalId: string;
  issuer: string;
  sessionId: string;
  credentialDigest: `sha256:${string}`;
  credentialExpiresAt: number;
  enrollmentId: string;
  capabilities: string[];
  implementationIssuers: string[];
  risk: AfnSessionAdmissionRisk;
  revocationSources: string[];
  expiresAt: number;
}

export interface AfnSessionAdmission {
  readonly schemaVersion: "fastflow.afn-session-admission/v2";
  createInvite(input: {
    inviteId: string;
    principalId: string | null;
    nonce: string;
    confirmationCode: string;
    expiresAt: number;
    enrollmentId: string;
    enrollmentExpiresAt: number;
    capabilities: string[];
    implementationIssuers: string[];
    risk?: AfnSessionAdmissionRisk;
    revocationSources?: string[];
  }): Readonly<Record<string, unknown>>;
  revokeInvite(inviteId: string): boolean;
  admitHello(input: { hello: Record<string, unknown>; credential: Record<string, unknown>; proof: unknown }): AfnSessionAdmissionPrincipal;
  pair(input: { hello: Record<string, unknown>; credential: Record<string, unknown>; proof: unknown; inviteId: string; nonce: string; confirmationCode: string; reapproval?: unknown; rotation?: Record<string, unknown> }): AfnSessionAdmissionPrincipal;
  renewCredential(input: { principal: AfnSessionAdmissionPrincipal; hello: Record<string, unknown>; credential: Record<string, unknown>; proof: unknown }): AfnSessionAdmissionPrincipal;
  assertPrincipalActive(principal: AfnSessionAdmissionPrincipal): true;
  authorizeOffer(input: { principal: AfnSessionAdmissionPrincipal; capability: Record<string, unknown> }): boolean;
  authorizeAssignment(input: { principal: AfnSessionAdmissionPrincipal; capability: Record<string, unknown>; invocationGrant?: string }): boolean;
  revokePrincipal(principalId: string): boolean;
  revokeImplementationPublisher(publisherId: string): void;
  revokeImplementation(implementationDigest: `sha256:${string}`): void;
  revokeKey(keyId: string): void;
  revokeIssuer(issuer: string): void;
  revokeArtifact(artifactDigest: `sha256:${string}`): void;
  revokeCredential(credentialDigest: `sha256:${string}`): void;
  revokeEnrollment(enrollmentId: string): void;
  inspect(): Readonly<Record<string, unknown>>;
}

export declare function createAfnSessionAdmission(input: {
  ownerNodeId: string;
  clock?: () => number | Date;
  verifyCredential?: (input: Record<string, unknown>) => boolean;
  verifyProofOfPossession?: (input: Record<string, unknown>) => boolean;
  verifyImplementationProvenance?: (input: Record<string, unknown>) => boolean;
  authorizeInvocationGrant?: (input: Record<string, unknown>) => boolean;
  verifyEnrollmentReapproval?: (input: Record<string, unknown>) => boolean;
  verifyDualProofRotation?: (input: Record<string, unknown>) => boolean;
  revocationPort?: { snapshot(): unknown } | null;
  trust?: Record<string, unknown>;
}): AfnSessionAdmission;

export interface DurableAfnEnrollmentStorage {
  get(key: string): Promise<unknown>;
  put(key: string, value: unknown): Promise<void>;
  transaction<T>(callback: (tx: DurableAfnEnrollmentStorage) => Promise<T>): Promise<T>;
}

type EnrollmentCommand = { operationId: string; request: Record<string, unknown> };

export declare function createDurableAfnEnrollment(input: {
  ownerNodeId: string;
  storage: DurableAfnEnrollmentStorage;
  /** The storage transaction may retry. The deployed verifier must be side-effect free. */
  verifyIdentity(input: { phase: "pairing" | "renewal" | "hello"; [key: string]: unknown }): Promise<boolean> | boolean;
  clock?: () => number | Date;
  randomId?: () => string;
}): {
  createPairingInvite(command: EnrollmentCommand): Promise<Record<string, unknown>>;
  approvePairing(command: EnrollmentCommand): Promise<AfnSessionAdmissionPrincipal>;
  renewCredential(command: EnrollmentCommand): Promise<AfnSessionAdmissionPrincipal>;
  revokeEnrollment(command: EnrollmentCommand): Promise<{ enrollmentId: string; removed: boolean; state: "revoked" }>;
  admitHello(input: { hello: Record<string, unknown>; credential: Record<string, unknown>; proof: unknown;
    context?: Record<string, unknown> }): Promise<AfnSessionAdmissionPrincipal>;
  currentPrincipal(principal: unknown): Promise<AfnSessionAdmissionPrincipal>;
};
