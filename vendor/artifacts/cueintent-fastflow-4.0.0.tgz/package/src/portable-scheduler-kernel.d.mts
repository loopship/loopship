import type {
  AfnInvocation,
  ExecutionDecision,
  ExecutionEvent,
  JsonValue,
  AnyPinnedPlan,
} from "./native-scheduler.mjs";
import type { AfnAssignment } from "./afn-assignment.mjs";
import type { PlanRouting } from "./pinned-plan-v4.mjs";

export declare const PORTABLE_SCHEDULER_KERNEL_VERSION:
  "fastflow.scheduler-kernel/v1";

export interface PortableSchedulerNodeState {
  nodeId: string;
  dependencies: string[];
  call: AnyPinnedPlan["nodes"][number]["call"];
  input: JsonValue;
  inputBindings: AnyPinnedPlan["nodes"][number]["inputBindings"];
  bindingRefs: AnyPinnedPlan["nodes"][number]["bindingRefs"];
  resourceHandles: Array<{ type: string; handleId: string }>;
  grants: AnyPinnedPlan["nodes"][number]["grants"];
  routing?: PlanRouting;
  deadline: string | null;
  status: "pending" | "host_waiting" | "dispatching" | "dispatch_pending" | "dispatch_waiting" | "awaiting" | "retrying" | "passed" | "failed" | "blocked" | "cancelled";
  attempt: number;
  invocation: AfnInvocation | null;
  decision: ExecutionDecision | null;
  retryAt: string | null;
  cancellationReason: string | null;
  resume: JsonValue | null;
  result?: JsonValue;
  error?: JsonValue;
  terminalSequence: number | null;
  assignment: AfnAssignment | null;
  assignmentGeneration: number;
  assignmentUnavailable: boolean;
}

export interface PortableSchedulerState {
  executionId: string;
  idempotencyKey: string;
  plan: AnyPinnedPlan;
  status: "running" | "awaiting" | "completed" | "failed" | "cancelled";
  cursor: number;
  cancelRequested: boolean;
  cancelReason: string | null;
  cancelOperationId: string | null;
  joinSelection: {
    policy: "first_success" | "first_settled";
    winnerNodeId: string;
    cancelNodeIds: string[];
  } | null;
  output?: JsonValue;
  error?: JsonValue;
  lastEventType: ExecutionEvent["type"];
  decisions: Map<string, ExecutionDecision>;
  signals: Map<string, JsonValue>;
  expiredSignalKeys: Set<string>;
  waitKeys: Set<string>;
  nodes: PortableSchedulerNodeState[];
  workflow: null | {
    status: "running" | "waiting" | "completed" | "failed";
    checkpoint: Record<string, JsonValue> | null;
    wait: null | {
      type: "timer" | "signal";
      key: string;
      timerId?: string;
      until?: string;
    };
    trigger: JsonValue | null;
    output: JsonValue | null;
    error: JsonValue | null;
  };
}

export type PortableSchedulerCommand =
  | { type: "assign-and-dispatch-node"; executionId: string; nodeId: string }
  | { type: "dispatch-node"; executionId: string; nodeId: string }
  | { type: "reassign-node"; executionId: string; nodeId: string; previousExecutorNodeId: string; previousAssignmentDigest: string }
  | { type: "block-node"; executionId: string; nodeId: string; error: { code: string; message: string } }
  | { type: "fire-timer"; executionId: string; nodeId: string; timerId: string; key: string }
  | { type: "advance-workflow"; executionId: string }
  | { type: "fire-workflow-timer"; executionId: string; timerId: string; key: string }
  | { type: "cancel-execution"; executionId: string; reason: string }
  | { type: "finish-join-cancellation"; executionId: string; selection: NonNullable<PortableSchedulerState["joinSelection"]> }
  | { type: "select-join"; executionId: string; policy: "first_success" | "first_settled"; winnerNodeId: string; cancelNodeIds: string[] }
  | { type: "finish-execution"; executionId: string; outcome: { status: "completed" } | { status: "failed"; code: string } };

export declare function reduceSchedulerKernel(input: {
  previousState?: PortableSchedulerState | null;
  events?: ExecutionEvent[];
  observedAt: string;
}): { state: PortableSchedulerState | null; commands: PortableSchedulerCommand[] };
export declare function deriveSchedulerCommands(
  state: PortableSchedulerState | null,
  input: { observedAt: string },
): PortableSchedulerCommand[];
export declare function utf8ByteLength(value: string): number;
