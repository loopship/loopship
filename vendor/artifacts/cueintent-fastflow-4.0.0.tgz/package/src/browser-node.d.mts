import type { CatalogBundle, CatalogBundleRegistry } from "./catalog-bundle.mjs";
import type { FastflowNode, FastflowNodeRole } from "./fastflow-node.mjs";
import type { PinnedPlanV4 } from "./pinned-plan-v4.mjs";

export interface IndexedDbKeyValueStorage {
  readonly kind: "indexeddb";
  readonly databaseName: string;
  get(key: string): Promise<unknown>;
  put(key: string | Record<string, unknown>, value?: unknown): Promise<void>;
  delete(key: string | string[]): Promise<void>;
  list(options?: { prefix?: string }): Promise<Map<string, unknown>>;
  transaction<T>(callback: (transaction: IndexedDbKeyValueStorage) => Promise<T>): Promise<T>;
  setAlarm(dueAt: number): Promise<void>;
  getAlarm(): Promise<number | null>;
  deleteAlarm(): Promise<void>;
  close(): void;
}

export interface ActiveRuntimeWake {
  readonly descriptor: Readonly<{
    kind: "active-runtime";
    activeOnly: true;
    backgroundLiveness: false;
    durableRecovery: true;
  }>;
  readonly active: boolean;
  readonly scheduledAt: number | null;
  start(): Promise<void>;
  resume(): Promise<void>;
  suspend(): Promise<void>;
  schedule(dueAt: number | null): void;
  flush(): Promise<void>;
  close(): void;
}

export interface BrowserActiveFastflowNode extends FastflowNode {
  readonly storage: IndexedDbKeyValueStorage;
  readonly catalogRegistry: CatalogBundleRegistry;
  readonly authority: Record<string, unknown> | null;
  readonly activeOnly: true;
  suspend(): Promise<void>;
  resume(): Promise<Record<string, unknown>>;
  registerCatalogBundle(
    request: Parameters<CatalogBundleRegistry["registerCatalogBundle"]>[0],
  ): Promise<CatalogBundle>;
  unregisterCatalogBundle(bundleDigest: string): Promise<boolean>;
  listCatalogBundles(): ReturnType<CatalogBundleRegistry["listCatalogBundles"]>;
  submit(request: {
    executionId: string;
    idempotencyKey: string;
    plan: PinnedPlanV4 | Record<string, unknown>;
  }): Promise<Record<string, unknown>>;
  inspect(request: { executionId: string }): Promise<Record<string, unknown>>;
  signal(request: Record<string, unknown>): Promise<Record<string, unknown>>;
  cancel(request: Record<string, unknown>): Promise<Record<string, unknown>>;
  readEvents(request: Record<string, unknown>): Promise<{
    events: Record<string, unknown>[];
    nextSequence: number;
    hasMore: boolean;
  }>;
  listAssignments(executionId: string): Promise<Record<string, unknown>[]>;
  readDashboardSnapshot(options?: Record<string, unknown>): Promise<Record<string, unknown>>;
  close(): Promise<void>;
}

export declare function openIndexedDbKeyValueStorage(input: {
  databaseName: string;
  indexedDB?: IDBFactory;
  keyRange?: typeof IDBKeyRange;
  onAlarmChanged?: ((dueAt: number | null) => void | Promise<void>) | null;
}): Promise<IndexedDbKeyValueStorage>;
export declare function deleteIndexedDbKeyValueStorageDatabase(input: {
  databaseName: string;
  indexedDB?: IDBFactory;
}): Promise<void>;
export declare function createActiveRuntimeWake(input: {
  readAlarm(): number | null | Promise<number | null>;
  onAlarm(input: { scheduledAt: number; observedAt: number }): unknown | Promise<unknown>;
  clock?: () => number | string | Date;
  timers?: Pick<typeof globalThis, "setTimeout" | "clearTimeout">;
  lifecycleTarget?: EventTarget | null;
  retryMs?: number;
  onError?: ((error: unknown) => void) | null;
}): ActiveRuntimeWake;
export declare function createBrowserActiveFastflowNode(input: {
  identity: string;
  databaseName?: string;
  catalogs?: {
    mounts: import("./workflow-ir.mjs").RegistryMountTable |
      Array<{ registryId: string; bundleDigest: string }>;
    registrations?: Array<Parameters<CatalogBundleRegistry["registerCatalogBundle"]>[0]>;
  };
  trust: Parameters<typeof import("./fastflow-node.mjs").configureFastflowNode>[0]["trust"];
  roles?: FastflowNodeRole[];
  indexedDB?: IDBFactory;
  keyRange?: typeof IDBKeyRange;
  lifecycleTarget?: EventTarget | null;
  clock?: () => number | string | Date;
  randomId?: () => string;
  maxInFlight?: number;
  maxMessageBytes?: number;
  leaseMs?: number;
  onFatalError?: ((error: unknown) => void) | null;
}): Promise<BrowserActiveFastflowNode>;

export declare function createTransactionalCatalogBundleRegistry(input: {
  storage: IndexedDbKeyValueStorage;
  kind?: string;
  isBundleInUse?: (bundleDigest: string) => boolean | Promise<boolean>;
}): CatalogBundleRegistry;
export declare function createTransactionalExecutionStore(input: Record<string, unknown>): Record<string, unknown>;
export declare function createTransactionalSchedulerAuthority(input: Record<string, unknown>): Record<string, unknown>;
