export type {
  CallCatalogListRequest,
  CallCatalogManifestDocument,
  CallCatalogScopeDocument,
  CallDescriptor,
  CallDescriptorSource,
  CallExec,
  CallInputs,
  WorkflowReleaseEntry,
} from "./index.d.ts";

import type {
  CallCatalogListRequest,
  CallCatalogManifestDocument,
  CallCatalogScopeDocument,
  CallDescriptor,
  CallDescriptorSource,
  CallInputs,
  WorkflowReleaseEntry,
} from "./index.d.ts";

export declare const CALL_CATALOG_SCOPE_SCHEMA_VERSION:
  "fastflow/call-catalog-scope/v2";
export declare const CALL_CATALOG_MANIFEST_SCHEMA_VERSION:
  "fastflow/call-catalog-manifest/v3";
export declare const CALL_CATALOG_INDEX_DEFAULT_PATH_TEMPLATE:
  "{registry}/{kind}/{target}/{scope}/index.yaml";
export declare const CALL_CATALOG_SCOPE_SCHEMA_FILE: string;
export declare const CALL_CATALOG_MANIFEST_SCHEMA_FILE: string;

export declare function loadCallCatalogRoot(
  rootPath: string,
): Promise<CallCatalogScopeDocument[]>;
export declare function listCallCatalog(
  request?: CallCatalogListRequest,
): Promise<CallCatalogScopeDocument>;
export declare function validateCallCatalogRoot(
  rootPath: string,
): Promise<Record<string, unknown>>;
export declare function validateCallDescriptor(
  value: unknown,
  options?: { label?: string },
): CallDescriptor;
export declare function writeCallDescriptorCatalog(options: {
  catalog: CallCatalogScopeDocument | { calls: CallDescriptor[] };
  outputRoot: string;
  catalogTags?:
    | Record<string, string | string[]>
    | Map<string, string | string[]>
    | null;
  onlyGroups?: string[] | null;
  writeRootIndex?: boolean;
}): Promise<{ outputRoot: string; calls: number }>;
export declare function writeGeneratedWorkflowCatalog(options: {
  outputRoot: string;
  workflows: Array<{
    call?: string;
    workflowCall?: string;
    workflow_call_id?: string;
    rawWorkflow?: Record<string, unknown>;
    workflow?: Record<string, unknown>;
    record?: { rawWorkflow?: Record<string, unknown> };
    release?: number;
    store?: string;
    summary?: string;
    digest?: string;
    inputs?: CallInputs;
    requires?: string[];
    tags?: string[];
  }>;
  catalogTags?:
    | Record<string, string | string[]>
    | Map<string, string | string[]>
    | null;
  writeRootIndex?: boolean;
  store?: string;
  validate?: boolean;
  validationOptions?: Record<string, unknown>;
  runtime?: unknown;
}): Promise<{ outputRoot: string; workflows: number; files: string[] }>;
export declare function buildCallCatalogManifest(options?: {
  prefixes?: Record<string, unknown> | null;
  prefixEntries?: Array<{ prefix: string; tags?: string[] | string | null }> | null;
  release_auth?: Record<string, unknown> | null;
  pathTemplate?: string;
}): CallCatalogManifestDocument;
export declare function buildCallCatalogScope(options?: {
  calls?: CallDescriptor[] | null;
  workflows?: Record<string, Record<string, WorkflowReleaseEntry>> | null;
  command?: Record<string, unknown> | null;
  stable_attestation?: { signature: string } | null;
}): CallCatalogScopeDocument;
export declare function buildWorkflowReleaseEntry(options: {
  call: string;
  rawWorkflow?: Record<string, unknown>;
  record?: { rawWorkflow?: Record<string, unknown> };
  release?: number;
  summary?: string | null;
  digest?: string | null;
  inputs?: CallInputs | null;
  requires?: string[] | null;
}): WorkflowReleaseEntry;
export declare function buildCallDescriptor(
  descriptor: CallDescriptorSource,
): CallDescriptor;
export declare function deriveCallId(
  descriptor: Pick<
    CallDescriptorSource,
    "registry" | "kind" | "target" | "scope" | "name"
  >,
): string;
export declare function parseCallId(call: string): {
  call: string;
  registry: string;
  kind: string;
  target: string;
  scope: string;
  name: string;
};
export declare function parseCallPrefix(
  prefix: string,
  label?: string,
): {
  prefix: string;
  registry: string;
  kind: string;
  target: string;
  scope: string;
};
export declare function renderCatalogPathForCallPrefix(
  prefix: string,
  options?: { pathTemplate?: string },
): string;
export declare function normalizeCallCatalogScopeDocument(
  value: unknown,
  options?: { label?: string },
): CallCatalogScopeDocument;
export declare function normalizeCallCatalogManifestDocument(
  value: unknown,
  options?: { label?: string },
): CallCatalogManifestDocument;
export declare function normalizeCallDescriptor(
  value: unknown,
  options?: { label?: string },
): CallDescriptor;
