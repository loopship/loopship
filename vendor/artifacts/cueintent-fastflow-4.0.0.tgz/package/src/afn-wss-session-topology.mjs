export {
  AFN_WSS_SESSION_TOPOLOGY_SCHEMA_VERSION,
  createAfnWssSessionTopology,
} from "./lib/afn-wss-session-topology.mjs";
