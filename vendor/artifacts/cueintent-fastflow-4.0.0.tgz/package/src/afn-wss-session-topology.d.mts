import type { FastflowSessionV3Frame } from "./afn-session-v3.mjs";
import type {
  AfnWssSessionFrameContext,
  AfnWssSessionPort,
} from "./afn-wss-session.mjs";
import type {
  NodeLocatorTrustPolicy,
  NodeSessionLocator,
  NodeSessionLocatorEndpoint,
} from "./node-session-locator.mjs";

export declare const AFN_WSS_SESSION_TOPOLOGY_SCHEMA_VERSION:
  "fastflow.afn-wss-session-topology/v1";

export type AfnWssSessionTopologyRole = "scheduler" | "executor";
export type AfnWssSessionTopologyMode = "direct" | "rendezvous";
export type AfnWssSessionTopologyState = "connected" | "authenticated" | "closed";

export interface AfnWssSessionTopologyAuthenticatedPrincipal {
  state: "authorized";
  nodeId: string;
  sessionId: string;
  expiresAt: string | number;
}

export interface AfnWssSessionTopologyCarrier {
  readonly bufferedAmount?: number;
  send(bytes: Uint8Array): void;
  subscribe(input: {
    onMessage(bytes: Uint8Array | ArrayBuffer | ArrayBufferView): void | Promise<void>;
    onClose(event?: Record<string, unknown>): void | Promise<void>;
  }): () => void;
  close(code?: number, reason?: string): void;
}

export interface AfnWssSessionTopologyFrameInput {
  type: FastflowSessionV3Frame["type"];
  payload: Record<string, unknown>;
}

export interface AfnWssSessionTopologyCloseOptions {
  code?: string;
  reason?: string;
  retryable?: boolean;
  meta?: Record<string, unknown>;
}

export interface AfnWssSessionTopologySession {
  readonly schemaVersion: "fastflow.afn-wss-session-topology/v1";
  readonly mode: AfnWssSessionTopologyMode;
  readonly localRole: AfnWssSessionTopologyRole;
  readonly remoteRole: AfnWssSessionTopologyRole;
  readonly localNodeId: string;
  readonly remoteNodeId: string;
  readonly sessionId: string;
  readonly sessionEpoch: number;
  readonly endpoint: Readonly<NodeSessionLocatorEndpoint>;
  readonly state: AfnWssSessionTopologyState;
  readonly authenticated: boolean;
  readonly port: AfnWssSessionPort;
  send(frame: AfnWssSessionTopologyFrameInput): Promise<Readonly<FastflowSessionV3Frame>>;
  close(
    options?: AfnWssSessionTopologyCloseOptions,
  ): Promise<Readonly<FastflowSessionV3Frame> | null>;
}

export interface AfnWssSessionTopologyPeerClosedEvent {
  mode: AfnWssSessionTopologyMode;
  localNodeId: string;
  remoteNodeId: string;
  sessionId: string;
  sessionEpoch: number;
  retryable?: boolean;
  reason?: string;
  errorCode?: string;
  [key: string]: unknown;
}

export interface AfnWssSessionTopologyVerifyLocatorInput {
  locator: Readonly<NodeSessionLocator>;
  expectedNodeIdentity: string;
  expectedTrustScope: string;
  now: number | string | Date;
}

export type AfnWssSessionTopologyLocatorVerifier = (
  input: AfnWssSessionTopologyVerifyLocatorInput,
) => Readonly<NodeSessionLocator> | PromiseLike<Readonly<NodeSessionLocator>>;

export interface AfnWssSessionTopologyConnectorInput {
  endpoint: NodeSessionLocatorEndpoint;
  localNodeId: string;
  remoteNodeId: string;
  localRole: AfnWssSessionTopologyRole;
  remoteRole: AfnWssSessionTopologyRole;
  sessionId: string;
  sessionEpoch: number;
}

export interface AfnWssSessionTopologyRendezvousConnectorInput
  extends AfnWssSessionTopologyConnectorInput {
  rendezvousId: string;
  side: AfnWssSessionTopologyRole;
}

export type AfnWssSessionTopologyDirectConnector = (
  input: AfnWssSessionTopologyConnectorInput,
) => AfnWssSessionTopologyCarrier | PromiseLike<AfnWssSessionTopologyCarrier>;

export type AfnWssSessionTopologyRendezvousConnector = (
  input: AfnWssSessionTopologyRendezvousConnectorInput,
) => AfnWssSessionTopologyCarrier | PromiseLike<AfnWssSessionTopologyCarrier>;

export interface AfnWssSessionTopologyConnectInput {
  locator: unknown;
  mode?: AfnWssSessionTopologyMode | null;
  rendezvousId?: string | null;
  remoteRole?: AfnWssSessionTopologyRole | null;
  sessionId: string;
  sessionEpoch: number;
  authenticatedPrincipal: AfnWssSessionTopologyAuthenticatedPrincipal;
}

export interface AfnWssSessionTopologyAcceptInput {
  locator: unknown;
  carrier: AfnWssSessionTopologyCarrier;
  remoteRole?: AfnWssSessionTopologyRole | null;
  sessionId: string;
  sessionEpoch: number;
  authenticatedPrincipal: AfnWssSessionTopologyAuthenticatedPrincipal;
}

export interface AfnWssSessionTopologyOptions {
  localNodeId: string;
  localRole: AfnWssSessionTopologyRole;
  trustScope: string;
  trustPolicy?: NodeLocatorTrustPolicy | null;
  verifyLocator?: AfnWssSessionTopologyLocatorVerifier | null;
  connectDirect?: AfnWssSessionTopologyDirectConnector | null;
  connectRendezvous?: AfnWssSessionTopologyRendezvousConnector | null;
  now?: () => number | string | Date;
  clock?: () => string;
  onFrame?: (
    frame: FastflowSessionV3Frame,
    session: AfnWssSessionTopologySession,
    context: AfnWssSessionFrameContext,
  ) => void | Promise<void>;
  onPeerClosed?: (
    event: AfnWssSessionTopologyPeerClosedEvent,
    session: AfnWssSessionTopologySession,
  ) => void;
  validateAuthenticatedPrincipal?: (principal: unknown) => boolean;
  maxMessageBytes?: number;
  maxBufferedBytes?: number;
}

export interface AfnWssSessionTopology {
  readonly schemaVersion: "fastflow.afn-wss-session-topology/v1";
  connect(
    input: AfnWssSessionTopologyConnectInput,
  ): Promise<AfnWssSessionTopologySession>;
  accept(
    input: AfnWssSessionTopologyAcceptInput,
  ): Promise<AfnWssSessionTopologySession>;
}

export declare function createAfnWssSessionTopology(
  input?: AfnWssSessionTopologyOptions,
): AfnWssSessionTopology;
