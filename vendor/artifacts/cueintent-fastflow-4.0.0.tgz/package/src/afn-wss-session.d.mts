export interface AfnWssSessionPort {
  readonly protocolVersion: "fastflow.afn.v3";
  readonly state: "connected" | "authenticated" | "closed";
  readonly authenticated: boolean;
  readonly nextSequence: number;
  readonly lastReceivedSequence: number;
  readonly protectionConfigured: boolean;
  readonly keyId: string | null;
  markAuthenticated(principal: { state: "authorized"; nodeId: string; sessionId: string; expiresAt: string | number }): void;
  configureSessionProtection(input: { edhocSession: unknown; transcriptDigest: string }): Promise<{ keyId: string }>;
  getSessionState(): { nextSequence: number; lastReceivedSequence: number; protectionConfigured: boolean; keyId: string | null };
  restoreSessionState(input?: { nextSequence?: number | null; lastReceivedSequence?: number | null; protectionConfigured?: boolean; keyId?: string | null }): Promise<{ nextSequence: number; lastReceivedSequence: number; protectionConfigured: boolean; keyId: string | null }>;
  send(input: { type: string; payload: Record<string, unknown> }): Promise<Readonly<Record<string, unknown>>>;
  receive(bytes: Uint8Array | ArrayBuffer | ArrayBufferView): Promise<Readonly<Record<string, unknown>>>;
  fence(reason?: string): Promise<void>;
  close(input?: { code?: string; reason?: string; retryable?: boolean; meta?: Record<string, unknown> }): Promise<Readonly<Record<string, unknown>> | null>;
}

export interface AfnWssSessionCallbackContext {
  /** Re-enter the current port-owned callback task without awaiting its own queue. */
  fence(reason?: string): Promise<void>;
  /** Close from the current callback task without awaiting that task's own queue. */
  close(input?: { code?: string; reason?: string; retryable?: boolean; meta?: Record<string, unknown> }): Promise<Readonly<Record<string, unknown>> | null>;
}

export interface AfnWssSessionFrameContext extends AfnWssSessionCallbackContext {
  assertActive(): void;
  /** The effect receives a fence assertion for use before each durable step. */
  commit<T>(effect: (assertActive: () => void) => T | PromiseLike<T>): T | Promise<T>;
}

export interface AfnWssSessionStateContext extends AfnWssSessionCallbackContext {}

export declare function createAfnWssSessionPort(input: {
  socket: { send(value: Uint8Array): void; close?(code?: number, reason?: string): void; bufferedAmount?: number };
  localNodeId: string;
  remoteNodeId: string;
  sessionId: string;
  sessionEpoch: number;
  role: "scheduler" | "executor";
  clock?: () => string;
  onFrame?: (frame: unknown, context: AfnWssSessionFrameContext) => void | Promise<void>;
  onStateChanged?: (state: { nextSequence: number; lastReceivedSequence: number; protectionConfigured: boolean; keyId: string | null }, context: AfnWssSessionStateContext) => void | Promise<void>;
  maxMessageBytes?: number;
  maxBufferedBytes?: number;
  validateAuthenticatedPrincipal?: (principal: unknown) => boolean;
}): AfnWssSessionPort;
