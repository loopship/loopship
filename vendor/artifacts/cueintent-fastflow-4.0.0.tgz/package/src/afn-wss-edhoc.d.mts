export interface AfnWssEdhocMessage {
  messageNumber: 1 | 2 | 3;
  message: string;
}

export interface AfnWssEdhocFrame {
  type: "EDHOC";
  payload: { meta: unknown } & AfnWssEdhocMessage;
}

export interface AfnWssEdhocExchange {
  readonly role: "executor" | "scheduler";
  readonly completed: boolean;
  readonly transcriptDigest: string | null;
  exportState(): unknown;
  start(): Promise<AfnWssEdhocMessage>;
  receive(input: AfnWssEdhocMessage): Promise<AfnWssEdhocMessage | null>;
  send(
    port: { send(input: AfnWssEdhocFrame): Promise<AfnWssEdhocFrame> },
    input: { meta: unknown },
  ): Promise<AfnWssEdhocFrame>;
  configurePort(port: { configureSessionProtection(input: { edhocSession: unknown; transcriptDigest: string }): Promise<{ keyId: string }> }): Promise<{ keyId: string }>;
}

export declare function createAfnWssEdhocExchange(input: {
  role: "executor" | "scheduler";
  identity: unknown;
  peerIdentity: unknown;
  signPrivateKey: CryptoKey;
  peerVerifyKey: CryptoKey;
}): Promise<AfnWssEdhocExchange>;

export declare function restoreAfnWssEdhocExchange(input: {
  state: unknown;
}): AfnWssEdhocExchange;
