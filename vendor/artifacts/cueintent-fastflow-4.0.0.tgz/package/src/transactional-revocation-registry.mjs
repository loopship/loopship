export * from "./lib/transactional-revocation-registry.mjs";
