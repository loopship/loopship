import type {
  AfnDispatchPort,
  DispatchRoute,
  JsonValue,
} from "./native-scheduler.mjs";
import type { ExecutorOffer } from "./executor-offer.mjs";

export type CloudflareComputerBackend =
  | "container"
  | "isolate-shell"
  | "isolate-javascript";

export interface CloudflareComputerBoundaryContext {
  operation: string;
  executionId: string;
  invocationId: string;
  attempt: number;
  assignmentDigest: string;
  profileDigest: string;
}

export interface CloudflareComputerBoundaryInput extends CloudflareComputerBoundaryContext {
  request: {
    source: string;
    options: { backend: CloudflareComputerBackend };
  };
}

export interface CloudflareComputerBoundaryOutcome {
  result: unknown;
  receipt: import("./sandbox-profile.mjs").SandboxReceipt;
}

export interface CloudflareComputerWorkspace {
  runtime: {
    execute(input: CloudflareComputerBoundaryInput):
      CloudflareComputerBoundaryOutcome | Promise<CloudflareComputerBoundaryOutcome>;
  };
}

export interface CloudflareComputerRoute extends DispatchRoute {
  source: string;
  qualifiers?: Record<string, JsonValue>;
  resourceHandles?: Array<{ type: string; handleId: string }>;
}

export interface CloudflareComputerExecutor {
  readonly provider: "cloudflare-computer-preview";
  readonly backend: CloudflareComputerBackend;
  readonly dispatchPort: AfnDispatchPort;
  readonly offer: Readonly<ExecutorOffer>;
  close(): Promise<void>;
}

export declare const CLOUDFLARE_COMPUTER_PROVIDER: "cloudflare-computer-preview";
export declare const CLOUDFLARE_COMPUTER_BACKENDS: readonly CloudflareComputerBackend[];

export declare function createCloudflareComputerExecutor(input: {
  workspace: CloudflareComputerWorkspace;
  routes: CloudflareComputerRoute[];
  backend?: CloudflareComputerBackend;
  sandboxBoundary: {
    provider: string;
    profileDigest: string;
    enforcementReceipt: import("./sandbox-profile.mjs").SandboxReceipt;
    profile: import("./sandbox-profile.mjs").SandboxProfile;
  };
  executorNodeId?: string;
  sessionId?: string;
  sessionEpoch?: number;
  offerId?: string;
  offerExpiresAt?: string | null;
  durableMailbox?: boolean;
}): CloudflareComputerExecutor;
