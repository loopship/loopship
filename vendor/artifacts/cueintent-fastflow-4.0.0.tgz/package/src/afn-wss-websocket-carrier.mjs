export {
  AFN_WSS_WEBSOCKET_SUBPROTOCOL,
  DEFAULT_AFN_WSS_WEBSOCKET_MAX_MESSAGE_BYTES,
  MAX_AFN_WSS_WEBSOCKET_MESSAGE_BYTES,
  createAfnWssWebSocketCarrier,
  dialAfnWssWebSocketCarrier,
} from "./lib/afn-wss-websocket-carrier.mjs";
