export declare const AFN_OFFER_SCHEMA_VERSION: "fastflow.afn-offer/v1";
export declare const AFN_EXECUTOR_DIRECTORY_SCHEMA_VERSION: "fastflow.executor-directory/v1";

export interface ExecutorResourceHandleRef {
  type: string;
  handleId: string;
}

export interface ExecutorOfferCapability {
  callId: string;
  contractDigest: `sha256:${string}`;
  implementationDigest: `sha256:${string}`;
  qualifiers: Record<string, unknown>;
  resourceHandles: ExecutorResourceHandleRef[];
}

export interface ExecutorOffer {
  schemaVersion: "fastflow.afn-offer/v1";
  offerId: string;
  executorNodeId: string;
  sessionId: string;
  sessionEpoch: number;
  expiresAt: string;
  capabilities: ExecutorOfferCapability[];
  capacity: {
    partitionId: string;
    authorityId: string;
    generation: number;
    maxInFlight: number;
    available: number;
  };
  offerDigest: `sha256:${string}`;
}

export interface ExecutorPrincipal {
  id: string;
  [key: string]: unknown;
}

export interface ExecutorAuthorization {
  enrolled: boolean;
  authorized: boolean;
  grantKinds: string[];
  implementationIssuers?: string[];
  implementationProvenance?: Array<{
    callId: string;
    contractDigest: `sha256:${string}`;
    implementationDigest: `sha256:${string}`;
    implementationIssuer: string;
    artifactDigest: `sha256:${string}`;
  }>;
  expiresAt?: string;
}

export interface ExecutorOfferSnapshot {
  offer: ExecutorOffer;
  executorNodeId: string;
  sessionId: string;
  sessionEpoch: number;
  principalId: string;
  authorization: ExecutorAuthorization;
  reservationId?: string;
}

export interface ExecutorOfferDirectory {
  readonly schemaVersion: "fastflow.executor-directory/v1";
  connect(input: {
    offer: ExecutorOffer;
    principal: ExecutorPrincipal;
    authorization: ExecutorAuthorization;
  }): Promise<ExecutorOfferSnapshot>;
  publish(input: Parameters<ExecutorOfferDirectory["connect"]>[0]): Promise<ExecutorOfferSnapshot>;
  withdraw(input: {
    executorNodeId: string;
    sessionId: string;
    sessionEpoch: number;
    offerId: string;
  }): boolean;
  withdrawSession(input: {
    executorNodeId: string;
    sessionId: string;
    sessionEpoch: number;
  }): boolean;
  expire(now?: number | string | Date): number;
  listOffers(): ExecutorOfferSnapshot[];
  select(input: {
    call: Pick<ExecutorOfferCapability, "callId" | "contractDigest">;
    routing: {
      mode: "exact-host" | "capability-pool";
      executorNodeId?: string;
      implementationDigest?: `sha256:${string}`;
      qualifiers: Record<string, unknown>;
      resourceHandles: ExecutorResourceHandleRef[];
      replayPolicy: "idempotent" | "replay-safe" | "assigned-executor-only" | "at-most-once";
    };
    grants?: string[];
    excludeOfferIds?: string[];
    reserve?: boolean;
    reservationId?: string | null;
  }): Promise<ExecutorOfferSnapshot | null>;
  releaseReservation(input: { reservationId: string }): boolean;
  restoreReservation(input: {
    reservationId: string;
    offerId: string;
    executorNodeId: string;
    sessionId: string;
    sessionEpoch: number;
    offerDigest?: `sha256:${string}` | null;
  }): boolean;
  updateCapacity(input: {
    executorNodeId: string;
    sessionId: string;
    sessionEpoch: number;
    offerId: string;
    available: number;
  }): ExecutorOfferSnapshot;
  getReservation(input: { reservationId: string }): {
    reservationId: string;
    offerId: string;
    executorNodeId: string;
    sessionId: string;
    sessionEpoch: number;
  } | null;
}

export declare function createExecutorOffer(
  input: Omit<ExecutorOffer, "schemaVersion" | "offerDigest">,
): Readonly<ExecutorOffer>;
export declare function validateExecutorOffer(
  value: unknown,
  options?: { contracts?: Map<string, unknown> | Record<string, unknown> | ((input: {
    callId: string;
    contractDigest: string;
  }) => unknown) },
): ExecutorOffer;
export declare function digestExecutorOffer(value: unknown): `sha256:${string}`;
export declare function matchExecutorOffer(input: {
  offer: ExecutorOffer;
  call: Pick<ExecutorOfferCapability, "callId" | "contractDigest">;
  routing: ExecutorOfferDirectory extends never ? never : Parameters<ExecutorOfferDirectory["select"]>[0]["routing"];
  contract?: unknown;
  grants?: string[];
  authorization?: ExecutorAuthorization | null;
}): boolean;
export declare function createExecutorOfferDirectory(input?: {
  now?: () => number | string | Date;
  authorizeOffer?: (input: {
    offer: ExecutorOffer;
    principal: ExecutorPrincipal;
    authorization: ExecutorAuthorization;
  }) => boolean | Promise<boolean>;
  authorizeAssignment?: (input: {
    offer: ExecutorOffer;
    principal: ExecutorPrincipal;
    authorization: ExecutorAuthorization;
    call: Pick<ExecutorOfferCapability, "callId" | "contractDigest">;
    routing: Parameters<ExecutorOfferDirectory["select"]>[0]["routing"];
    grants: string[];
    capability: ExecutorOfferCapability;
  }) => boolean | Promise<boolean>;
  validateSession?: (input: {
    principal: ExecutorPrincipal;
    authorization: ExecutorAuthorization;
    offer: ExecutorOffer | null;
  }) => boolean;
  resolveContract?: (input: {
    callId: string;
    contractDigest: string;
  }) => unknown | Promise<unknown>;
  randomId?: () => string | Promise<string>;
  requireImplementationProvenance?: boolean | ((input: {
    offer: ExecutorOffer;
    principal: ExecutorPrincipal;
    authorization: ExecutorAuthorization;
  }) => boolean);
}): ExecutorOfferDirectory;
