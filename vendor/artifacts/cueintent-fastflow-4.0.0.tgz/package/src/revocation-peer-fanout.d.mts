import type { RevocationState } from "./revocation-registry.mjs";

export declare const REVOCATION_PEER_FANOUT_SCHEMA_VERSION: "fastflow.revocation-peer-fanout/v1";
export declare const REVOCATION_PEER_CURSOR_KEY_PREFIX: "ff:revocation-peer-cursor:";

export interface RevocationPeer {
  authorityId: string;
  apply(state: RevocationState): Promise<{ changed: boolean }>;
}

export interface RevocationPeerCursor {
  authorityId: string;
  generation: number;
  stateDigest: string | null;
}

export interface RevocationPeerFanout {
  readonly schemaVersion: "fastflow.revocation-peer-fanout/v1";
  readonly authorityId: string;
  listPeers(): RevocationPeerCursor[];
  propagate(state: RevocationState): Promise<{ peers: RevocationPeerCursor[] }>;
}

export declare function createRevocationPeerFanout(input: {
  storage: {
    get(key: string): Promise<unknown>;
    put(key: string, value: unknown): Promise<void>;
    transaction<T>(callback: (storage: RevocationPeerStorageView) => Promise<T>): Promise<T>;
  };
  authorityId: string;
  peers?: RevocationPeer[];
  clock?: () => number | Date;
  publish?(state: RevocationState): void | Promise<void>;
}): Promise<RevocationPeerFanout>;

interface RevocationPeerStorageView {
  get(key: string): Promise<unknown>;
  put(key: string, value: unknown): Promise<void>;
}
