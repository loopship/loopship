export declare const FASTFLOW_NODE_SCHEMA_VERSION: "fastflow.node/v1";
export declare const FASTFLOW_NODE_ROLES: readonly [
  "compiler",
  "coordinator",
  "worker",
];

export type FastflowPortableRole = typeof FASTFLOW_NODE_ROLES[number];
/** Legacy inputs are normalized to coordinator/worker in the public descriptor. */
export type FastflowNodeRole = FastflowPortableRole | "scheduler" | "executor";
export interface FastflowNodeConnectivityEndpoint {
  listen?: string;
  dial?: string;
  rendezvousId?: string;
}
export interface FastflowNodeConnectivity {
  directWss?: FastflowNodeConnectivityEndpoint;
  relayRendezvous?: FastflowNodeConnectivityEndpoint;
}
export interface FastflowExecutorIntegration {
  executorId: string;
  initialize(input: unknown): void | Promise<void>;
  advertise(input: unknown): import("./executor-offer.mjs").ExecutorOffer | null | Promise<import("./executor-offer.mjs").ExecutorOffer | null>;
  dispatch(input: unknown): unknown | Promise<unknown>;
  close(input: unknown): void | Promise<void>;
}

export interface FastflowSchedulerOfferAdmission {
  offer: import("./executor-offer.mjs").ExecutorOffer;
  principal: import("./executor-offer.mjs").ExecutorPrincipal;
  authorization: import("./executor-offer.mjs").ExecutorAuthorization;
}

export interface FastflowSchedulerAssignmentAdmission extends FastflowSchedulerOfferAdmission {
  call: Pick<import("./executor-offer.mjs").ExecutorOfferCapability, "callId" | "contractDigest"> & {
    implementationDigest?: `sha256:${string}`;
  };
  routing: {
    mode: "exact-host" | "capability-pool";
    executorNodeId?: string;
    implementationDigest?: `sha256:${string}`;
    qualifiers: Record<string, unknown>;
    resourceHandles: import("./executor-offer.mjs").ExecutorResourceHandleRef[];
    replayPolicy: "idempotent" | "replay-safe" | "assigned-executor-only" | "at-most-once";
  };
  grants: string[];
  capability: import("./executor-offer.mjs").ExecutorOfferCapability;
}

export type FastflowSchedulerOfferAuthorizer =
  (input: FastflowSchedulerOfferAdmission) => boolean | Promise<boolean>;
export type FastflowSchedulerAssignmentAuthorizer =
  (input: FastflowSchedulerAssignmentAdmission) => boolean | Promise<boolean>;
export type FastflowSchedulerSessionValidator =
  (input: FastflowSchedulerOfferAdmission) => boolean | Promise<boolean>;

export interface FastflowSchedulerAuthorityOptions {
  executorPort?: import("./native-scheduler.mjs").AfnDispatchPort | null;
  resourceLeasePort?: import("./native-scheduler.mjs").ResourceLeasePort | null;
  authorizeOffer?: FastflowSchedulerOfferAuthorizer;
  authorizeAssignment?: FastflowSchedulerAssignmentAuthorizer | null;
  validateSession?: FastflowSchedulerSessionValidator;
  enrollmentAdmin?: Record<string, unknown> | null;
}

export interface FastflowNodePlatform {
  executionStore?: { kind: string; atomic: boolean; [key: string]: unknown } | null;
  authority?: { kind: string; [key: string]: unknown } | null;
  wake?: { kind: string; [key: string]: unknown } | null;
  clock?: { now(): string } | null;
  random?: { id(): string } | null;
  crypto?: {
    digest(value: Uint8Array | string): string | Promise<string>;
    verify(input: unknown): boolean | Promise<boolean>;
  } | null;
  catalogStore?: { kind: string; [key: string]: unknown } | null;
  capabilityEvidence?: {
    persistentSafety: "durable" | "ephemeral" | "none";
    recovery: "exact" | "none";
    activeOnly: boolean;
    backgroundLiveness: boolean;
    reachability:
      | "public-inbound"
      | "local-inbound"
      | "relay-required"
      | "outbound-only"
      | "none";
    resourceLimits?: Partial<FastflowNodeResourceLimits>;
  };
  start?(input: {
    descriptor: FastflowNodeDescriptor;
    catalogResolver: import("./catalog-bundle.mjs").CatalogBundleMountResolver | null;
    executors: ReadonlyArray<FastflowExecutorIntegration>;
  }): void | Promise<void>;
  stop?(input: Parameters<NonNullable<FastflowNodePlatform["start"]>>[0]): void | Promise<void>;
}

export interface FastflowNodeTrust {
  mode: "production" | "local-development";
  owner?: string;
  ownerPolicy?: Record<string, unknown>;
  enrolledPrincipals?: ReadonlyArray<Record<string, unknown>>;
  implementationIssuers?: ReadonlyArray<Record<string, unknown>>;
  revocationSources?: ReadonlyArray<Record<string, unknown>>;
  catalogs?: import("./catalog-bundle.mjs").CatalogBundleTrustPolicy;
  trustedCatalogSignerIds?: string[];
  verifyCatalogEvidence?: import("./catalog-bundle.mjs").CatalogBundleTrustPolicy["verifyEvidence"];
}

export interface FastflowNodeDescriptor {
  schemaVersion: "fastflow.node/v1";
  identity: string;
  roles: FastflowPortableRole[];
  authority: string;
  durability: string;
  wake: string;
  persistentSafety: "durable" | "ephemeral" | "none";
  recovery: "exact" | "none";
  activeOnly: boolean;
  backgroundLiveness: boolean;
  reachability:
    | "public-inbound"
    | "local-inbound"
    | "relay-required"
    | "outbound-only"
    | "none";
  compilerLevel: "yaml-and-ir" | "verified-ir";
  connectivity: { directWss: boolean; relayRendezvous: boolean };
  executorCount: number;
  resourceLimits: FastflowNodeResourceLimits;
  trustMode: "production" | "local-development";
}

export interface FastflowNodeResourceLimits {
  maxBundleBytes: number | null;
  maxIrBytes: number | null;
  maxPlanBytes: number | null;
  maxEventBytes: number | null;
  maxMessageBytes: number | null;
  maxInFlight: number | null;
}

export interface FastflowNode {
  readonly descriptor: Readonly<FastflowNodeDescriptor>;
  readonly catalogs: {
    mounts: ReadonlyArray<{ registryId: string; bundleDigest: string }>;
    mountTable: import("./workflow-ir.mjs").RegistryMountTable | null;
    registry: import("./catalog-bundle.mjs").CatalogBundleRegistry | null;
    registrations: ReadonlyArray<Parameters<
      import("./catalog-bundle.mjs").CatalogBundleRegistry["registerCatalogBundle"]
    >[0]>;
  };
  readonly platform: FastflowNodePlatform;
  readonly connectivity: FastflowNodeConnectivity;
  readonly executors: ReadonlyArray<FastflowExecutorIntegration>;
  readonly executorOffers: ReadonlyArray<{
    executorId: string;
    offer: import("./executor-offer.mjs").ExecutorOffer;
  }>;
  readonly trust: FastflowNodeTrust;
  readonly catalogResolver: import("./catalog-bundle.mjs").CatalogBundleMountResolver | null;
  readonly started: boolean;
  start(): Promise<Readonly<FastflowNodeDescriptor>>;
  stop(): Promise<void>;
}

export declare function configureFastflowNode(input: {
  identity: string;
  roles: FastflowNodeRole[];
  catalogs: {
    mounts: import("./workflow-ir.mjs").RegistryMountTable |
      Array<{ registryId: string; bundleDigest: string }>;
    registry?: import("./catalog-bundle.mjs").CatalogBundleRegistry;
    registrations?: Array<Parameters<
      import("./catalog-bundle.mjs").CatalogBundleRegistry["registerCatalogBundle"]
    >[0]>;
  };
  platform: FastflowNodePlatform;
  connectivity?: FastflowNodeConnectivity;
  executors?: FastflowExecutorIntegration[];
  trust: FastflowNodeTrust;
}): FastflowNode;
export declare function validateFastflowNodeDescriptor(value: unknown): FastflowNodeDescriptor;
export interface BunSqliteFastflowNode extends FastflowNode {
  readonly catalogRegistry: import("./catalog-bundle.mjs").CatalogBundleRegistry;
  readonly schedulerDescriptor: import("./native-scheduler.mjs").SchedulerRuntimeDescriptor | null;
  readonly dashboardDescriptor: Readonly<{
    url: string;
    snapshotUrl: string;
    capability: string;
  }> | null;
  close(): Promise<void>;
}
export declare function createBunSqliteFastflowNode(input: {
  identity: string;
  schedulerDbPath: string;
  catalogDbPath: string;
  descriptorPath?: string;
  catalogs?: {
    mounts: import("./workflow-ir.mjs").RegistryMountTable |
      Array<{ registryId: string; bundleDigest: string }>;
    registrations?: Array<Parameters<
      import("./catalog-bundle.mjs").CatalogBundleRegistry["registerCatalogBundle"]
    >[0]>;
  };
  trust: Parameters<typeof configureFastflowNode>[0]["trust"];
  roles?: FastflowNodeRole[];
  authority?: FastflowSchedulerAuthorityOptions & Record<string, unknown>;
}): BunSqliteFastflowNode;
