import type { JsonValue } from "./native-scheduler.mjs";
import type { PinnedPlanV4Node, PlanRouting } from "./pinned-plan-v4.mjs";
import type { WorkflowIr, WorkflowIrExactCall } from "./workflow-ir.mjs";

export declare const PORTABLE_WORKFLOW_PROGRAM_SCHEMA_VERSION:
  "fastflow.workflow-program/v1";
export declare const PORTABLE_WORKFLOW_CHECKPOINT_SCHEMA_VERSION:
  "fastflow.workflow-checkpoint/v1";

export type PortableExpression = Record<string, JsonValue> & { type: string };
export type PortableTemplate = JsonValue;

export interface PortableWorkflowCheckpoint extends Record<string, JsonValue> {
  schemaVersion: "fastflow.workflow-checkpoint/v1";
  irDigest: string;
  status: "running" | "completed" | "failed";
  stack: JsonValue[];
  scopes: Record<string, JsonValue>;
  pending: JsonValue;
  transfer: JsonValue;
  output: JsonValue;
  error: JsonValue;
}

export type PortableWorkflowCommand =
  | { type: "idle" }
  | { type: "dispatch-afn"; node: PinnedPlanV4Node; sensitive?: true }
  | {
      type: "wait";
      wait: {
        type: "timer" | "signal";
        key: string;
        timerId?: string;
        until?: string;
      };
    }
  | { type: "complete"; output: JsonValue }
  | { type: "fail"; error: JsonValue };

export interface PortableWorkflowReduction {
  checkpoint: PortableWorkflowCheckpoint;
  command: PortableWorkflowCommand;
}

export declare function compilePortableWorkflowProgram(input: {
  workflow: Record<string, JsonValue>;
  callId: string;
  version: string;
  digest: string;
  exactCalls: Map<string, WorkflowIrExactCall> | WorkflowIrExactCall[];
}): Readonly<Record<string, JsonValue> & {
  schemaVersion: "fastflow.workflow-program/v1";
}>;

export declare function reducePortableWorkflow(input: {
  ir: WorkflowIr;
  inputs?: Record<string, JsonValue>;
  checkpoint?: PortableWorkflowCheckpoint | null;
  nodes?: Array<{
    nodeId: string;
    status: string;
    result?: JsonValue;
    error?: JsonValue;
  }>;
  trigger?: JsonValue;
  observedAt: string;
  routingOverrides?: Record<string, PlanRouting>;
  limits?: {
    maxOperations?: number;
    maxStackDepth?: number;
  };
}): Readonly<PortableWorkflowReduction>;

export declare function compilePortableExpression(
  source: string,
  label?: string,
): Readonly<PortableExpression>;
export declare function evaluatePortableExpression(
  expression: PortableExpression,
  context: Record<string, JsonValue>,
  label?: string,
): JsonValue;
export declare function compilePortableTemplate(
  value: JsonValue,
  label?: string,
): PortableTemplate;
export declare function materializePortableTemplate(
  value: PortableTemplate,
  context: Record<string, JsonValue>,
  label?: string,
): JsonValue;
export declare function coercePortableBoolean(value: JsonValue): boolean;
