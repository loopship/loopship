export {
  RESOURCE_HANDLE_SCHEMA_VERSION,
  RESOURCE_LEASE_SCHEMA_VERSION,
  RESOURCE_LEASE_STORE_KEY_PREFIX,
  createResourceHandle,
  createDurableResourceLeaseManager,
  createResourceLease,
  createResourceLeaseManager,
  digestResourceHandle,
  digestResourceLease,
  resourceHandleRef,
  validateResourceHandle,
  validateResourceLease,
} from "./lib/resource-contracts.mjs";
