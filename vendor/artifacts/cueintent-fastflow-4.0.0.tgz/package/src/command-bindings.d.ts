export type FastflowCommandBindingSupervision = "workflow" | "step" | "audit" | boolean;

export interface FastflowCommandBindingContext {
  cwd?: string;
  [key: string]: unknown;
}

export interface FastflowCommandBindingFlag {
  type?: "string" | "boolean";
  valueName?: string;
  description?: string;
}

export interface FastflowCommandBindingInputResolverContext {
  flags: Record<string, unknown>;
  positionals: string[];
  context: FastflowCommandBindingContext;
}

export type FastflowCommandBindingTransform =
  | string
  | ((
      value: unknown,
      details: {
        field: string;
        binding: FastflowCommandBinding;
        flags: Record<string, unknown>;
        positionals: string[];
        context: FastflowCommandBindingContext;
      },
    ) => unknown);

export interface FastflowCommandBindingInput {
  flag?: string;
  positional?: number;
  default?:
    | unknown
    | ((details: FastflowCommandBindingInputResolverContext) => unknown);
  defaultFrom?: "cwd";
  required?: boolean;
  transform?: FastflowCommandBindingTransform;
}

export interface FastflowCommandBinding {
  path: string[];
  kind: "workflow.run";
  workflowRef:
    | string
    | ((details: FastflowCommandBindingInputResolverContext) => string);
  supervision?: FastflowCommandBindingSupervision;
  progressMode?: "compact" | "verbose" | string;
  flags?: Record<string, FastflowCommandBindingFlag>;
  inputs?: Record<string, FastflowCommandBindingInput | unknown>;
  usage?: {
    args?: string;
  };
}

export interface FastflowWorkflowRunCmdprotoParams {
  workflowRef: string;
  inputs?: Record<string, unknown>;
  supervise?: boolean;
  superviseStep?: boolean;
  supervisionMode?: "audit";
  progressMode?: "compact" | "verbose" | string;
}

export interface FastflowCommandBindingResult {
  matched: true;
  kind: "cmdproto";
  commandPath: "workflows run";
  targetKind: "workflow.run";
  binding: FastflowCommandBinding;
  aliasPath: string[];
  flags: Record<string, unknown>;
  positionals: string[];
  params: FastflowWorkflowRunCmdprotoParams;
}

export interface FastflowCommandBindingHelpResult {
  matched: true;
  kind: "help";
  binding: FastflowCommandBinding;
  aliasPath: string[];
  text: string;
}

export declare class FastflowCommandBindingError extends Error {
  code: string;
  constructor(code: string, message: string);
}

export declare function resolveFastflowCommandBinding(
  argv: string[],
  bindings: FastflowCommandBinding[],
  context?: FastflowCommandBindingContext,
): FastflowCommandBindingResult | FastflowCommandBindingHelpResult | null;

export declare function renderFastflowCommandBindingUsage(
  binding: FastflowCommandBinding,
): string;
