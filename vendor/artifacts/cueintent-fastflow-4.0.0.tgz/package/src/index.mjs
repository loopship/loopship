export {
  runFastflowCmdprotoCli,
  createFastflowRuntime,
  FASTFLOW_METHODS,
} from "./cmdproto/app.mjs";

export {
  executeFastflowCmdprotoCommand,
  executeFastflowCallCatalogRequest,
  executeFastflowScaffoldRequest,
  executeFastflowSnapshotCaptureRequest,
  executeFastflowWorkflowRecoverRequest,
  executeFastflowWorkflowResumeRequest,
  executeFastflowWorkflowRunRequest,
} from "./lib/core-v1.mjs";

export {
  FastflowCommandBindingError,
  renderFastflowCommandBindingUsage,
  resolveFastflowCommandBinding,
} from "./lib/command-bindings.mjs";

export {
  loadWorkflowRecord,
  resolveWorkflowReference,
  resolveWorkflowTupleReference,
  validateWorkflowRecord,
  getGlobalWorkflowsDir,
} from "./lib/workflows.mjs";

export {
  INTERACTION_ARTIFACT_MEDIA_TYPE,
  INTERACTION_ARTIFACT_SCHEMA_VERSION,
  readWorkflowInteractionArtifact,
} from "./lib/interaction-artifact.mjs";

export {
  BUN_RUNTIME_REQUIRED_ERROR_CODE,
  assertCanonicalBunApplicationRuntime,
  resolveCanonicalBunExecutable,
} from "./lib/application-runtime.mjs";

export {
  buildCallCatalogManifest,
  buildCallCatalogScope,
  buildWorkflowReleaseEntry,
  loadCallCatalogRoot,
  listCallCatalog,
  validateCallCatalogRoot,
  validateCallDescriptor,
  writeCallDescriptorCatalog,
  writeGeneratedWorkflowCatalog,
} from "./lib/call-catalog.mjs";

export {
  CALL_CATALOG_INDEX_DEFAULT_PATH_TEMPLATE,
  CALL_CATALOG_MANIFEST_SCHEMA_FILE,
  CALL_CATALOG_MANIFEST_SCHEMA_VERSION,
  CALL_CATALOG_SCOPE_SCHEMA_FILE,
  CALL_CATALOG_SCOPE_SCHEMA_VERSION,
  buildCallDescriptor,
  deriveCallId,
  normalizeCallCatalogScopeDocument,
  normalizeCallCatalogManifestDocument,
  normalizeCallDescriptor,
  parseCallId,
  parseCallPrefix,
  renderCatalogPathForCallPrefix,
} from "./lib/call-catalog-shape.mjs";

export * from "./native-scheduler.mjs";
export * from "./catalog-bundle.mjs";
export * from "./workflow-ir.mjs";
export * from "./portable-scheduler-kernel.mjs";
export * from "./portable-workflow.mjs";
export * from "./fastflow-node.mjs";
export * from "./node-session-locator.mjs";
export * from "./browser-node.mjs";
export * from "./constrained-node.mjs";
export * from "./pinned-plan-v4.mjs";
export * from "./afn-capability-routing.mjs";
export * from "./afn-assignment.mjs";
export * from "./executor-offer.mjs";
export * from "./executor-trust.mjs";
export * from "./revocation-registry.mjs";
export * from "./transactional-revocation-registry.mjs";
export * from "./revocation-peer-fanout.mjs";
export * from "./resource-contracts.mjs";
export * from "./afn-session-v3.mjs";
export * from "./afn-wss-session.mjs";
export * from "./afn-wss-edhoc.mjs";
export * from "./afn-wss-session-topology.mjs";
export * from "./afn-wss-websocket-carrier.mjs";
export * from "./afn-session-admission.mjs";
export * from "./afn-rendezvous-relay.mjs";
export * from "./cloudflare-computer-executor.mjs";
export * from "./cloudflare-edhoc-state-protection.mjs";

export {
  cancelNativeWorkflow,
  createAfnBindingContext,
  digestNativeWorkflowImplementation,
  executeNativeAfn,
  executeNativeWorkflow,
  inspectNativeWorkflow,
  recoverNativeWorkflow,
  resolveNativeSchedulerDbPath,
  resumeNativeWorkflow,
  submitNativeAfn,
  submitNativeWorkflow,
} from "./lib/native-workflow-runtime.mjs";
export {
  bindNativeWorkflow,
  validateNativeWorkflowBinding,
} from "./lib/native-workflow-binding.mjs";
export {
  resolveSecretBinding,
  resolveSecretBoundString,
} from "./lib/secret-bindings.mjs";
export {
  captureSecureLoginSecret,
  captureSecureSecretItem,
  clearSecretStoreEnrollment,
  enrollSecretStoreUnattended,
  ensureNamedSecretRef,
} from "./lib/secret-store.mjs";

export const FASTFLOW_EXPORT_TIERS = Object.freeze({
  stable: Object.freeze([
    "FASTFLOW_METHODS",
    "runFastflowCmdprotoCli",
    "executeFastflowCmdprotoCommand",
    "executeFastflowWorkflowRunRequest",
    "executeFastflowWorkflowRecoverRequest",
    "executeFastflowWorkflowResumeRequest",
    "executeFastflowCallCatalogRequest",
    "executeFastflowSnapshotCaptureRequest",
    "executeFastflowScaffoldRequest",
    "FastflowCommandBindingError",
    "resolveFastflowCommandBinding",
    "renderFastflowCommandBindingUsage",
  ]),
  advanced: Object.freeze([
    "loadWorkflowRecord",
    "resolveWorkflowReference",
    "resolveWorkflowTupleReference",
    "validateWorkflowRecord",
    "getGlobalWorkflowsDir",
    "listCallCatalog",
    "validateCallDescriptor",
    "writeCallDescriptorCatalog",
    "writeGeneratedWorkflowCatalog",
    "buildCallCatalogManifest",
    "buildCallCatalogScope",
    "buildWorkflowReleaseEntry",
    "parseCallId",
    "parseCallPrefix",
    "renderCatalogPathForCallPrefix",
    "createAfnDispatchPort",
    "createAfnInvocation",
    "pinPlan",
    "pinPlanV4",
    "registerCatalogBundle",
    "compileWorkflowIr",
    "compileWorkflowIrFromCatalog",
    "reducePortableWorkflow",
    "configureFastflowNode",
    "validateFastflowNodeDescriptor",
    "createNodeSessionLocator",
    "verifyNodeSessionLocator",
    "createBrowserActiveFastflowNode",
    "createConstrainedSchedulerProfile",
    "validateConstrainedPinnedPlanV4",
    "createAfnAssignment",
    "createExecutorOffer",
    "createExecutorOfferDirectory",
    "createExecutorArtifact",
    "validateExecutorArtifact",
    "createExecutorProvenance",
    "validateExecutorProvenance",
    "createExecutorTrustPolicy",
    "authorizeExecutorImplementation",
    "createRevocationState",
    "validateRevocationState",
    "digestRevocationState",
    "createRevocationRegistry",
    "createTransactionalRevocationRegistry",
    "createResourceHandle",
    "createResourceLease",
    "createResourceLeaseManager",
    "createFastflowSessionFrame",
    "encodeFastflowSessionFrame",
    "decodeFastflowSessionFrame",
    "createAfnWssSessionPort",
    "createAfnWssSessionTopology",
    "createAfnWssWebSocketCarrier",
    "dialAfnWssWebSocketCarrier",
    "createAfnSessionAdmission",
    "createAfnRendezvousRelay",
    "assertLocalDurableFilesystem",
    "createNativeSchedulerBackend",
    "NATIVE_SCHEDULER_PROFILE_ID",
    "assertCanonicalBunApplicationRuntime",
    "resolveCanonicalBunExecutable",
    "executeNativeWorkflow",
    "executeNativeAfn",
    "submitNativeAfn",
    "submitNativeWorkflow",
    "createAfnBindingContext",
    "digestNativeWorkflowImplementation",
    "resumeNativeWorkflow",
    "inspectNativeWorkflow",
    "recoverNativeWorkflow",
    "cancelNativeWorkflow",
    "resolveNativeSchedulerDbPath",
    "resolveSecretBinding",
    "resolveSecretBoundString",
    "enrollSecretStoreUnattended",
    "clearSecretStoreEnrollment",
    "ensureNamedSecretRef",
    "captureSecureSecretItem",
    "captureSecureLoginSecret",
  ]),
  internalSubpaths: Object.freeze([
    "@cueintent/fastflow/inference",
    "@cueintent/fastflow/browser-interaction",
    "@cueintent/fastflow/internal/catalog",
  ]),
  platformSubpaths: Object.freeze([
    "@cueintent/fastflow/browser-node",
    "@cueintent/fastflow/cloudflare-node",
    "@cueintent/fastflow/cloudflare-computer-executor",
    "@cueintent/fastflow/cloudflare-provider-executors",
  ]),
});
export * from "./sandbox-profile.mjs";
export * from "./identity-credential.mjs";
export * from "./session-envelope.mjs";
export * from "./resource-partition.mjs";
