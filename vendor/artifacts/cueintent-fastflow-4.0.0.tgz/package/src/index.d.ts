export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonValue[] | { [key: string]: JsonValue };

export * from "./portable-workflow.mjs";
export * from "./node-session-locator.mjs";
export * from "./constrained-node.mjs";
export * from "./executor-offer.mjs";
export * from "./executor-trust.mjs";
export * from "./revocation-registry.mjs";
export * from "./transactional-revocation-registry.mjs";
export * from "./revocation-peer-fanout.mjs";
export * from "./resource-contracts.mjs";
export * from "./afn-session-v3.mjs";
export * from "./afn-wss-session.mjs";
export * from "./afn-wss-session-topology.mjs";
export * from "./afn-wss-websocket-carrier.mjs";
export * from "./afn-session-admission.mjs";

export interface CallInputs {
  required: string[];
  optional: string[];
  schema?: Record<string, unknown>;
}

export interface CallExec {
  argv: string[];
  argv_digest?: string;
  artifact_digest?: string;
  artifact_path?: string;
  artifact_argv_index?: number;
  version?: string;
}

export interface CallDescriptor {
  call: string;
  summary: string;
  inputs: CallInputs;
  tags?: string[];
  requires?: string[];
  preferWhen?: string[];
  avoidWhen?: string[];
  exec?: CallExec;
  examples?: unknown[];
  rankHint?: number;
  metadata?: CallDescriptorMetadata;
}

export interface CallDescriptorSource {
  call?: string;
  registry?: string | null;
  kind?: string | null;
  target?: string | null;
  scope?: string | null;
  name?: string | null;
  summary: string;
  inputs?: CallInputs;
  tags?: string[] | null;
  requires?: string[] | null;
  preferWhen?: string[] | null;
  avoidWhen?: string[] | null;
  exec?: CallExec | null;
  examples?: unknown[] | null;
  rankHint?: number | null;
  metadata?: CallDescriptorMetadata | null;
}

export interface CallDescriptorMetadata {
  allowed_phases?: Array<"action" | "validation" | "verification">;
  result_contract?: "fastflow.check/v1";
  effects?: string[];
  [key: string]: unknown;
}

export interface CallCatalogScopeDocument {
  schemaVersion: "fastflow/call-catalog-scope/v2";
  calls?: CallDescriptor[];
  workflows?: Record<string, Record<string, unknown>>;
  stable_attestation?: {
    signature: string;
  };
}

export interface CallCatalogManifestDocument {
  schemaVersion: "fastflow/call-catalog-manifest/v3";
  pathTemplate: string;
  release_auth?: Record<string, unknown>;
  prefixes: Record<string, unknown>;
}

export interface WorkflowReleaseEntry {
  release: number;
  digest: string;
  summary: string;
  inputs: CallInputs;
  requires: string[];
}

export interface CallCatalogListRequest {
  workspaceRoot?: string | null;
  registry?: string | null;
  kind?: string | null;
  target?: string | null;
  scope?: string | null;
  name?: string | null;
  prefix?: string | null;
  q?: string | null;
}

export interface WorkflowsRunRequest {
  workflowRef: string;
  inputs?: Record<string, unknown>;
  executionId?: string;
  idempotencyKey?: string;
  supervise?: boolean;
  superviseStep?: boolean;
  supervisionMode?: "audit";
}

export type WorkflowResumeResponseEnvelope =
  | { answer: JsonValue; decision?: never }
  | { decision: "ok"; answer?: never };

export interface WorkflowInteractionRef {
  ref: string;
  digest: `sha256:${string}`;
  mediaType: "application/json";
  bytes: number;
}

export interface WorkflowInteractionArtifactCheck extends WorkflowInteractionCheck {
  failures?: unknown[];
  [key: string]: unknown;
}

export declare const INTERACTION_ARTIFACT_SCHEMA_VERSION: "fastflow/interaction-artifact/v1";
export declare const INTERACTION_ARTIFACT_MEDIA_TYPE: "application/json";

export interface WorkflowInteractionArtifact {
  schemaVersion: "fastflow/interaction-artifact/v1";
  kind: "inline_answer" | "handoff_answer" | "supervisor_review";
  resolverRef: string;
  systemInstructions: string;
  instructions: string;
  context: {
    request: unknown;
    answerSchema: unknown;
    relayUrl?: string;
  };
  checks?: {
    validation: WorkflowInteractionArtifactCheck;
    verification: WorkflowInteractionArtifactCheck;
  };
}

export declare function readWorkflowInteractionArtifact(
  interactionRef: WorkflowInteractionRef,
  options?: { workspaceRoot?: string | null },
): Promise<WorkflowInteractionArtifact>;

export interface WorkflowsResumeRequest {
  sessionId: string;
  nonce: string;
  workspaceRoot?: string;
  response: WorkflowResumeResponseEnvelope;
}

export interface WorkflowsRecoverRequest {
  executionId: string;
  schedulerDbPath?: string | null;
  options?: Record<string, unknown>;
}

export type FastflowCommandBindingSupervision = "workflow" | "step" | "audit" | boolean;

export interface FastflowCommandBindingContext {
  cwd?: string;
  [key: string]: unknown;
}

export interface FastflowCommandBindingFlag {
  type?: "string" | "boolean";
  valueName?: string;
  description?: string;
}

export interface FastflowCommandBindingInputResolverContext {
  flags: Record<string, unknown>;
  positionals: string[];
  context: FastflowCommandBindingContext;
}

export type FastflowCommandBindingTransform =
  | string
  | ((
      value: unknown,
      details: {
        field: string;
        binding: FastflowCommandBinding;
        flags: Record<string, unknown>;
        positionals: string[];
        context: FastflowCommandBindingContext;
      },
    ) => unknown);

export interface FastflowCommandBindingInput {
  flag?: string;
  positional?: number;
  default?:
    | unknown
    | ((details: FastflowCommandBindingInputResolverContext) => unknown);
  defaultFrom?: "cwd";
  required?: boolean;
  transform?: FastflowCommandBindingTransform;
}

export interface FastflowCommandBinding {
  path: string[];
  kind: "workflow.run";
  workflowRef:
    | string
    | ((details: FastflowCommandBindingInputResolverContext) => string);
  supervision?: FastflowCommandBindingSupervision;
  progressMode?: "compact" | "verbose" | string;
  flags?: Record<string, FastflowCommandBindingFlag>;
  inputs?: Record<string, FastflowCommandBindingInput | unknown>;
  usage?: {
    args?: string;
  };
}

export interface FastflowWorkflowRunCmdprotoParams extends WorkflowsRunRequest {
  progressMode?: "compact" | "verbose" | string;
}

export interface FastflowCommandBindingResult {
  matched: true;
  kind: "cmdproto";
  commandPath: "workflows run";
  targetKind: "workflow.run";
  binding: FastflowCommandBinding;
  aliasPath: string[];
  flags: Record<string, unknown>;
  positionals: string[];
  params: FastflowWorkflowRunCmdprotoParams;
}

export interface FastflowCommandBindingHelpResult {
  matched: true;
  kind: "help";
  binding: FastflowCommandBinding;
  aliasPath: string[];
  text: string;
}

export declare class FastflowCommandBindingError extends Error {
  code: string;
  constructor(code: string, message: string);
}

export declare function resolveFastflowCommandBinding(
  argv: string[],
  bindings: FastflowCommandBinding[],
  context?: FastflowCommandBindingContext,
): FastflowCommandBindingResult | FastflowCommandBindingHelpResult | null;

export declare function renderFastflowCommandBindingUsage(
  binding: FastflowCommandBinding,
): string;

export interface WorkflowResumeNextCall<
  TResponse extends WorkflowResumeResponseEnvelope = WorkflowResumeResponseEnvelope,
> {
  command: string;
  args: {
    sessionId: string;
    nonce: string;
    workspaceRoot?: string;
    response: TResponse;
  };
}

export interface WorkflowInteractionCheck {
  status: "passed" | "failed" | "pending" | "missing" | "not_required" | "unknown";
}

export interface WorkflowInteractionBase {
  schemaVersion: "fastflow/interaction-response/v2";
  kind: "inline_answer" | "handoff_answer" | "supervisor_review";
  resolverRef: string;
  systemInstructions: string;
  interactionRef: WorkflowInteractionRef;
  relayUrl?: string;
  artifactRef?: unknown;
  supervision?: {
    enabled: true;
    mode: "workflow" | "step" | "audit";
  };
}

export type WorkflowInteractionResponse =
  | (WorkflowInteractionBase & {
      kind: "inline_answer";
      nextCall?: never;
      checks?: never;
      artifactRef?: never;
    })
  | (WorkflowInteractionBase & {
      kind: "handoff_answer";
      nextCall: WorkflowResumeNextCall<{ answer: JsonValue }>;
      checks?: never;
      artifactRef?: unknown;
    })
  | (WorkflowInteractionBase & {
      kind: "supervisor_review";
      nextCall: WorkflowResumeNextCall<{ decision: "ok" }>;
      checks: {
        validation: WorkflowInteractionCheck;
        verification: WorkflowInteractionCheck;
      };
    });

export interface WorkflowRunResultResponse {
  schemaVersion: "fastflow/workflow-run-artifact/v1";
  kind: "workflow_result";
  ok: boolean;
  status: "running" | "completed" | "failed";
  executionId?: string;
  accepted?: boolean;
  queued?: boolean;
  workflow?: unknown;
  artifactRef?: unknown;
  checks?: unknown;
  output?: unknown;
  error?: unknown;
  supervisor?: unknown;
  repair?: unknown;
  promotion?: unknown;
  runtimeIdentities?: unknown;
}

export type WorkflowsRunResponse =
  | WorkflowInteractionResponse
  | WorkflowRunResultResponse;

export type WorkflowsRunLibraryResponse = WorkflowRunResultResponse;

export interface WorkflowsCallsListResponse {
  schemaVersion: "fastflow/workflows-calls-list-response/v1";
  calls: CallDescriptor[];
  workflows: Record<string, unknown>;
  metadata: Record<string, unknown>;
}

export interface SnapshotCaptureResponse {
  schemaVersion: "fastflow/snapshots-capture-response/v1";
  snapshot: Record<string, unknown>;
}

export interface ScaffoldRequest {
  appName: string;
  dir: string;
  packageName?: string;
  binName?: string;
  fastflowSpec?: string;
  extension?: "none" | "document" | "task" | "both";
}

export interface ScaffoldResponse {
  schemaVersion: "fastflow/scaffold-response/v1";
  appName: string;
  packageName: string;
  binName: string;
  dir: string;
  fastflowDependency: string;
  extension: "none" | "document" | "task" | "both";
  files: string[];
  nextCommands: string[];
}

export declare const CALL_CATALOG_SCOPE_SCHEMA_VERSION:
  "fastflow/call-catalog-scope/v2";
export declare const CALL_CATALOG_MANIFEST_SCHEMA_VERSION:
  "fastflow/call-catalog-manifest/v3";
export declare const CALL_CATALOG_INDEX_DEFAULT_PATH_TEMPLATE:
  "{registry}/{kind}/{target}/{scope}/index.yaml";
export declare const CALL_CATALOG_SCOPE_SCHEMA_FILE: string;
export declare const CALL_CATALOG_MANIFEST_SCHEMA_FILE: string;
export declare const FASTFLOW_METHODS: Readonly<Record<string, string>>;
export declare const FASTFLOW_EXPORT_TIERS: Readonly<{
  stable: readonly string[];
  advanced: readonly string[];
  internalSubpaths: readonly string[];
  platformSubpaths: readonly string[];
}>;

export declare function runFastflowCmdprotoCli(
  argv?: string[],
  options?: Record<string, unknown>,
): Promise<unknown>;
export declare function createFastflowRuntime(
  options?: Record<string, unknown>,
): unknown;
export declare function executeFastflowCmdprotoCommand(
  commandPath: string,
  params: Record<string, unknown> | undefined,
  hostRuntime: unknown,
): Promise<unknown>;
export declare function executeFastflowWorkflowRunRequest(
  request: WorkflowsRunRequest | undefined,
  hostRuntime: unknown,
): Promise<WorkflowsRunResponse>;
export declare function executeFastflowWorkflowRecoverRequest(
  request: WorkflowsRecoverRequest,
  hostRuntime: unknown,
): Promise<WorkflowsRunResponse>;
export declare function executeFastflowWorkflowResumeRequest(
  request: WorkflowsResumeRequest,
  hostRuntime: unknown,
): Promise<WorkflowsRunResponse>;
export declare function executeFastflowCallCatalogRequest(
  request: CallCatalogListRequest | undefined,
  hostRuntime: unknown,
): Promise<WorkflowsCallsListResponse>;
export declare function executeFastflowSnapshotCaptureRequest(
  request: Record<string, unknown> | undefined,
  hostRuntime: unknown,
): Promise<SnapshotCaptureResponse>;
export declare function executeFastflowScaffoldRequest(
  request?: ScaffoldRequest,
): Promise<ScaffoldResponse>;

export declare function loadWorkflowRecord(
  filePath: string,
  store?: string,
  reference?: string | null,
): Promise<Record<string, unknown>>;
export declare function resolveWorkflowReference(
  reference: string,
  workspaceRoot?: string | null,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function resolveWorkflowTupleReference(
  reference: Record<string, unknown>,
  workspaceRoot?: string | null,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function validateWorkflowRecord(
  record: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<void>;
export declare const BUN_RUNTIME_REQUIRED_ERROR_CODE: "FASTFLOW_BUN_RUNTIME_REQUIRED";
export declare function assertCanonicalBunApplicationRuntime(component?: string): string;
export declare function resolveCanonicalBunExecutable(): string;
export declare function getGlobalWorkflowsDir(): string;
export declare function bindNativeWorkflow(
  rootRecord: Record<string, unknown>,
  options?: NativeWorkflowBindingOptions,
): Promise<Record<string, unknown>>;
export interface NativeWorkflowBindingOptions {
  workspaceRoot?: string | null;
  runtime?: unknown;
  allowUnvalidatedRecord?: boolean;
  resolveWorkflowRecord?: (
    reference: Record<string, unknown>,
    workspaceRoot: string | null,
    options: { channel?: string | null; runtime?: unknown },
  ) => Record<string, unknown> | Promise<Record<string, unknown>>;
  resolveCallDescriptor?: (input: {
    call: string;
    parsed: {
      call: string;
      registry: string;
      kind: string;
      target: string;
      scope: string;
      name: string;
    };
  }) => Record<string, unknown> | null | Promise<Record<string, unknown> | null>;
}
export declare function validateNativeWorkflowBinding(
  value: unknown,
): Record<string, unknown>;

export declare function loadCallCatalogRoot(
  rootPath: string,
): Promise<CallCatalogScopeDocument[]>;
export declare function listCallCatalog(
  request?: CallCatalogListRequest,
): Promise<CallCatalogScopeDocument>;
export declare function validateCallCatalogRoot(
  rootPath: string,
): Promise<Record<string, unknown>>;
export declare function validateCallDescriptor(
  value: unknown,
  options?: { label?: string },
): CallDescriptor;
export declare function writeCallDescriptorCatalog(options: {
  catalog: CallCatalogScopeDocument | { calls: CallDescriptor[] };
  outputRoot: string;
  catalogTags?:
    | Record<string, string | string[]>
    | Map<string, string | string[]>
    | null;
  onlyGroups?: string[] | null;
  writeRootIndex?: boolean;
}): Promise<{ outputRoot: string; calls: number }>;
export declare function writeGeneratedWorkflowCatalog(options: {
  outputRoot: string;
  workflows: Array<{
    call?: string;
    workflowCall?: string;
    workflow_call_id?: string;
    rawWorkflow?: Record<string, unknown>;
    workflow?: Record<string, unknown>;
    record?: { rawWorkflow?: Record<string, unknown> };
    release?: number;
    store?: string;
    summary?: string;
    digest?: string;
    inputs?: CallInputs;
    requires?: string[];
    tags?: string[];
  }>;
  catalogTags?:
    | Record<string, string | string[]>
    | Map<string, string | string[]>
    | null;
  writeRootIndex?: boolean;
  store?: string;
  validate?: boolean;
  validationOptions?: Record<string, unknown>;
  runtime?: unknown;
}): Promise<{ outputRoot: string; workflows: number; files: string[] }>;
export declare function buildCallCatalogManifest(options?: {
  prefixes?: Record<string, unknown> | null;
  prefixEntries?: Array<{ prefix: string; tags?: string[] | string | null }> | null;
  release_auth?: Record<string, unknown> | null;
  pathTemplate?: string;
}): CallCatalogManifestDocument;
export declare function buildCallCatalogScope(options?: {
  calls?: CallDescriptor[] | null;
  workflows?: Record<string, Record<string, WorkflowReleaseEntry>> | null;
  command?: Record<string, unknown> | null;
  stable_attestation?: { signature: string } | null;
}): CallCatalogScopeDocument;
export declare function buildWorkflowReleaseEntry(options: {
  call: string;
  rawWorkflow?: Record<string, unknown>;
  record?: { rawWorkflow?: Record<string, unknown> };
  release?: number;
  summary?: string | null;
  digest?: string | null;
  inputs?: CallInputs | null;
  requires?: string[] | null;
}): WorkflowReleaseEntry;
export declare function buildCallDescriptor(
  descriptor: CallDescriptorSource,
): CallDescriptor;
export declare function deriveCallId(
  descriptor: Pick<
    CallDescriptorSource,
    "registry" | "kind" | "target" | "scope" | "name"
  >,
): string;
export declare function parseCallId(call: string): {
  call: string;
  registry: string;
  kind: string;
  target: string;
  scope: string;
  name: string;
};
export declare function parseCallPrefix(
  prefix: string,
  label?: string,
): {
  prefix: string;
  registry: string;
  kind: string;
  target: string;
  scope: string;
};
export declare function renderCatalogPathForCallPrefix(
  prefix: string,
  options?: { pathTemplate?: string },
): string;
export declare function normalizeCallCatalogScopeDocument(
  value: unknown,
  options?: { label?: string },
): CallCatalogScopeDocument;
export declare function normalizeCallCatalogManifestDocument(
  value: unknown,
  options?: { label?: string },
): CallCatalogManifestDocument;
export declare function normalizeCallDescriptor(
  value: unknown,
  options?: { label?: string },
): CallDescriptor;

export * from "./native-scheduler.mjs";

export interface NativeWorkflowRequestOptions {
  schedulerDbPath?: string | null;
  options?: Record<string, unknown>;
}
export interface NativeAfnRequest {
  call: import("./native-scheduler.mjs").ExactCallContract;
  input?: import("./native-scheduler.mjs").JsonValue;
  bindingContext?: import("./native-scheduler.mjs").JsonValue;
  executionId?: string | null;
  idempotencyKey?: string | null;
  nodeId?: string;
  dispatchPort?: import("./native-scheduler.mjs").AfnDispatchPort | null;
  bindingPort?: import("./native-scheduler.mjs").AfnBindingPort | null;
  deadline?: string | null;
  options?: Record<string, unknown>;
}
export declare function submitNativeAfn(input: NativeAfnRequest): Promise<import("./native-scheduler.mjs").ExecutionHandle>;
export declare function executeNativeAfn(input: NativeAfnRequest): Promise<import("./native-scheduler.mjs").JsonValue>;
export declare function createAfnBindingContext(request?: Record<string, unknown>): import("./native-scheduler.mjs").JsonValue;
export declare function digestNativeWorkflowImplementation(input?: {
  packageRoot?: string;
  readFile?: (filePath: string, encoding?: string) => string | Uint8Array;
}): string;
export declare function executeNativeWorkflow(
  runtime: unknown,
  workflowRecord: Record<string, unknown>,
  providedInputs?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function submitNativeWorkflow(
  runtime: unknown,
  workflowRecord: Record<string, unknown>,
  providedInputs?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function resumeNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
  nonce: string;
  signalId?: string;
  decision?: unknown;
  runtime?: unknown;
}): Promise<Record<string, unknown>>;
export declare function inspectNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
}): Promise<Record<string, unknown>>;
export declare function recoverNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
}): Promise<Record<string, unknown>>;
export declare function cancelNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
  reason?: string;
  operationId?: string | null;
}): Promise<Record<string, unknown>>;
export declare function resolveNativeSchedulerDbPath(options?: {
  schedulerDbPath?: string | null;
}): string;
export declare function resolveSecretBinding(
  binding: Record<string, unknown>,
  context?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function resolveSecretBoundString(
  binding: Record<string, unknown>,
  context?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<string>;
export * from "./catalog-bundle.mjs";
export * from "./workflow-ir.mjs";
export * from "./portable-scheduler-kernel.mjs";
export * from "./fastflow-node.mjs";
export * from "./browser-node.mjs";
export * from "./pinned-plan-v4.mjs";
export * from "./afn-capability-routing.mjs";
export * from "./afn-assignment.mjs";
export * from "./cloudflare-computer-executor.mjs";
export * from "./afn-wss-edhoc.mjs";
export * from "./cloudflare-edhoc-state-protection.mjs";

export interface FastflowSecretRef {
  type: "secret_ref";
  store: string;
  object_id: string;
  field_path: string | null;
}

export interface FastflowSecretResolution {
  payload: unknown;
  metadata?: Record<string, unknown>;
}

export declare function enrollSecretStoreUnattended(options?: {
  store?: string;
  email?: string;
  apiKey?: unknown;
  masterPassword?: string;
  replace?: boolean;
}): Promise<Record<string, unknown> | null>;
export declare function clearSecretStoreEnrollment(options?: {
  store?: string;
}): Promise<void>;
export declare function ensureNamedSecretRef(options?: {
  store?: string;
  name: string;
  value: string;
  notes?: string | null;
  replace?: boolean;
}): Promise<FastflowSecretRef>;
export declare function captureSecureSecretItem(options?: {
  store?: string;
  objectId: string;
  fieldPath?: string;
}): Promise<FastflowSecretRef>;
export declare function captureSecureLoginSecret(options?: {
  store?: string;
  name: string;
  username: string;
  uris?: string[];
  password?: string;
}): Promise<FastflowSecretRef>;
