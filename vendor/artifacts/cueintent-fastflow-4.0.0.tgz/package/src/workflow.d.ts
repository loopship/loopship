export declare const WORKFLOW_VALIDATION_ENTRYPOINT: "validateWorkflowRecord";
export declare const STABLE_WORKFLOW_CHANNEL: "stable";
export declare const DEV_WORKFLOW_CHANNEL: "dev";
export declare const WORKFLOW_CHANNELS: readonly ["stable", "dev"];

export interface WorkflowCompilerConfig {
  appSlug?: string;
}

export interface WorkflowCompilerRuntimeContext {
  config?: WorkflowCompilerConfig;
  runtimeIdentity?: string;
  runtimeVersion?: string;
  runtimeProvenanceExplicit?: boolean;
  runtimeProvenanceRequired?: boolean;
  registry?: string;
  extensionRegistries?: readonly string[];
  claimedExtensionRegistries?: readonly string[];
  workflowExtensionSchemaPath?: string | null;
  catalogResolver?: unknown;
  registryMounts?: unknown;
  provenance?: {
    identity?: string;
    version?: string;
    validatorIdentity?: string;
    validatorVersion?: string;
    adapterRoot?: string;
    root?: string;
  };
}

export interface WorkflowCompilerOptions {
  runtime?: WorkflowCompilerRuntimeContext | null;
}

export declare function loadWorkflowRecord(
  filePath: string,
  store?: string,
  reference?: string | null,
  options?: WorkflowCompilerOptions,
): Promise<Record<string, unknown>>;
export declare function parseYamlFile(
  filePath: string,
): Record<string, unknown>;
export declare function resolveWorkflowReference(
  reference: string,
  workspaceRoot?: string | null,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function validateWorkflowRecord(
  record: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<void>;
export declare function validateWorkflowSelection(
  options?: {
    mode?: string;
    workflowPath?: string | null;
    workspaceRoot?: string;
    fix?: boolean;
    workflowsDir?: string;
    releaseArtifactContext?: Record<string, unknown> | null;
  },
): Promise<Record<string, unknown>>;
export declare function getGlobalWorkflowsDir(): string;

export declare function loadFastflowValidationPolicy(): Record<string, unknown>;
export declare function validateFastflowSwfSubset(
  workflow: unknown,
  record?: Record<string, unknown>,
  errors?: string[],
  options?: WorkflowCompilerOptions,
): void;
export declare function validateFastflowWorkflowSchema(
  workflow: unknown,
  errors?: string[],
  prefix?: string,
  options?: WorkflowCompilerOptions,
): void;
export declare function normalizeSwfWorkflow(
  workflow: unknown,
  record?: Record<string, unknown>,
  errors?: string[],
  options?: WorkflowCompilerOptions,
): Record<string, unknown> | null;

export declare function buildPausedPayload(
  options?: Record<string, unknown>,
): Record<string, unknown>;
export declare function primeWorkflowExecutionCaches(
  record: Record<string, unknown>,
): void;
export declare function serializeError(error: unknown): Record<string, unknown>;

export declare function writeYamlFile(
  filePath: string,
  value: unknown,
): Promise<void>;
export declare function hashString(value: string): string;
export declare function getProjectState(
  workspaceRoot?: string | null,
): Record<string, unknown>;

export interface NativeWorkflowRequestOptions {
  schedulerDbPath?: string | null;
  options?: Record<string, unknown>;
}
export interface NativeAfnRequest {
  call: import("./native-scheduler.mjs").ExactCallContract;
  input?: import("./native-scheduler.mjs").JsonValue;
  bindingContext?: import("./native-scheduler.mjs").JsonValue;
  executionId?: string | null;
  idempotencyKey?: string | null;
  nodeId?: string;
  dispatchPort?: import("./native-scheduler.mjs").AfnDispatchPort | null;
  deadline?: string | null;
  options?: Record<string, unknown>;
}
export declare function submitNativeAfn(input: NativeAfnRequest): Promise<import("./native-scheduler.mjs").ExecutionHandle>;
export declare function executeNativeAfn(input: NativeAfnRequest): Promise<import("./native-scheduler.mjs").JsonValue>;
export declare function createAfnBindingContext(request?: Record<string, unknown>): import("./native-scheduler.mjs").JsonValue;
export declare function digestNativeWorkflowImplementation(input?: {
  packageRoot?: string;
  readFile?: (filePath: string, encoding?: string) => string | Uint8Array;
}): string;
export declare function executeNativeWorkflow(
  runtime: unknown,
  workflowRecord: Record<string, unknown>,
  providedInputs?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function resumeNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
  nonce: string;
  signalId?: string;
  decision?: unknown;
  runtime?: unknown;
}): Promise<Record<string, unknown>>;
export declare function inspectNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
}): Promise<Record<string, unknown>>;
export declare function recoverNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
}): Promise<Record<string, unknown>>;
export declare function cancelNativeWorkflow(input: NativeWorkflowRequestOptions & {
  executionId: string;
  reason?: string;
}): Promise<Record<string, unknown>>;
export declare function resolveNativeSchedulerDbPath(options?: {
  schedulerDbPath?: string | null;
}): string;
export declare function resolveSecretBinding(
  binding: Record<string, unknown>,
  context?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<Record<string, unknown>>;
export declare function resolveSecretBoundString(
  binding: Record<string, unknown>,
  context?: Record<string, unknown>,
  options?: Record<string, unknown>,
): Promise<string>;
