import type { JsonValue } from "./native-scheduler.mjs";

export declare const REGISTRY_MOUNT_TABLE_SCHEMA_VERSION:
  "fastflow.registry-mount-table/v1";
export declare const WORKFLOW_IR_SCHEMA_VERSION: "fastflow.workflow-ir/v1";

export declare function isSchedulerOwnedCallId(callId: string): boolean;

export interface RegistryMountTable {
  schemaVersion: "fastflow.registry-mount-table/v1";
  mounts: Record<string, string>;
  mountDigest: string;
}

export interface WorkflowIrCallRequirements {
  qualifiers: Record<string, JsonValue>;
  qualifierSchema: Record<string, JsonValue>;
  resourceHandles: Array<{ type: string; handleId: string }>;
  resourceRequirements: Array<{
    type: string;
    operations: string[];
    exclusive: boolean;
  }>;
  grants: Array<{ kind: string; scope?: JsonValue }>;
  replayPolicy: string;
}

export interface WorkflowIrExactCall {
  callId: string;
  contractDigest: string;
  phases: string[];
  requirements: WorkflowIrCallRequirements;
}

export interface WorkflowIrWorkflow {
  callId: string;
  version: string;
  digest: string;
  definition: Record<string, JsonValue>;
  program: Record<string, JsonValue> & {
    schemaVersion: "fastflow.workflow-program/v1";
  };
}

export interface WorkflowIr {
  schemaVersion: "fastflow.workflow-ir/v1";
  root: { callId: string; version: string; digest: string };
  registries: string[];
  workflows: WorkflowIrWorkflow[];
  calls: WorkflowIrExactCall[];
  irDigest: string;
}

export interface WorkflowIrBindingRecord {
  callId: string;
  version: string;
  digest: string;
  record: {
    workflow: Record<string, JsonValue>;
    [key: string]: JsonValue;
  };
}

export interface WorkflowIrBindingCall {
  call: {
    callId: string;
    contractDigest: string;
  };
  descriptor: Record<string, JsonValue>;
  phases: string[];
}

export interface WorkflowIrBinding {
  schemaVersion: string;
  rootDigest: string;
  bindingDigest: string;
  records: WorkflowIrBindingRecord[];
  calls: WorkflowIrBindingCall[];
}

export declare function createRegistryMountTable(
  entries: Array<{ registryId: string; bundleDigest: string }>,
): Readonly<RegistryMountTable>;
export declare function validateRegistryMountTable(value: unknown): RegistryMountTable;
export declare function compileWorkflowIr(input: {
  binding: WorkflowIrBinding;
  mounts: RegistryMountTable;
  contracts?: Array<import("./catalog-bundle.mjs").CatalogAfnContract>;
}): Readonly<WorkflowIr>;
export declare function compileWorkflowIrFromCatalog(input: {
  binding: WorkflowIrBinding;
  mounts: RegistryMountTable;
  resolveAfnContract: (call: {
    callId: string;
    contractDigest: string;
  }) => Promise<import("./catalog-bundle.mjs").CatalogAfnContract | {
    contract: import("./catalog-bundle.mjs").CatalogAfnContract;
  }>;
}): Promise<Readonly<WorkflowIr>>;
export declare function validateWorkflowIr(value: unknown): WorkflowIr;
export declare function compileWorkflowIrToPinnedPlanV4(input: {
  ir: WorkflowIr;
  mounts: RegistryMountTable;
  planId: string;
  inputs?: Record<string, JsonValue>;
  completionPolicy?: import("./native-scheduler.mjs").CompletionPolicy;
  maxConcurrency?: number;
  routingOverrides?: Record<string, import("./pinned-plan-v4.mjs").PlanRouting>;
  executionMode?: "static-dag" | "reducer";
}): Readonly<import("./pinned-plan-v4.mjs").PinnedPlanV4>;
