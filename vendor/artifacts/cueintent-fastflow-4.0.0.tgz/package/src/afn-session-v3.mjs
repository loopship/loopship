export {
  AFN_SESSION_V3_PROTOCOL_VERSION,
  AFN_SESSION_V3_SCHEMA_VERSION,
  DEFAULT_AFN_SESSION_V3_MAX_MESSAGE_BYTES,
  FRAME_TYPES,
  MAX_AFN_SESSION_V3_MESSAGE_BYTES,
  MAX_AFN_SESSION_V3_EDHOC_MESSAGE_BYTES,
  createFastflowSessionFrame,
  decodeFastflowSessionFrame,
  digestFastflowSessionFrame,
  encodeFastflowSessionFrame,
  validateFastflowSessionFrame,
} from "./lib/afn-session-v3-codec.mjs";
