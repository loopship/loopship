# cmdproto

`cmdproto` is a proto-first command ABI toolkit for tool-shaped apps.

App authors describe commands in protobuf, attach CLI bindings and examples as
options, and get one descriptor-led surface for:

- human commands
- per-command help
- machine JSON execution
- a unary Connect control plane for selected commands with package-owned
  internal bootstrap and on-demand ensure-running support

## Why

AI apps need tools, and tool calls need contracts.

`cmdproto` keeps that contract in core protobuf so one schema can explain:

- what a tool is called
- how a human runs it
- what JSON payload an assistant should send
- what minimal example proves the call shape

The same command ABI can also back other adapters:

- unary Connect for explicit remote commands (implemented)
- MCP tools and resources over official SDK stdio or Streamable HTTP
- live event streaming over stdio, gRPC, or WebSocket

MCP and Connect share the generated manifest, protobuf validation, handlers and
application results used by human CLI and `execjson`. Generic JSON-RPC, gRPC and
streaming command adapters remain future work. Application commands, identity,
policy and persistence stay in consumers; cmdproto supplies protocol mechanics.

## V1 Shape

- Human CLI: `app greet Ada -s`
- Command help: `app greet --help`
- Structured help: `app greet --help --json`
- Machine CLI: `app cmdproto execjson greet '{"name":"Ada","shout":true}'`

Default structured help is intentionally lean and uses the manifest app name:

```json
{"payload_schema":{"name":{"type":"string","help":"Name to greet."},"shout":{"type":"boolean","help":"Uppercase the greeting."}},"examples":[{"cmd":"greeter cmdproto execjson greet '{\"name\":\"Ada\",\"shout\":true}'","description":"Render a loud greeting."}]}
```

`--help` carries the richer human-facing details: the fully-qualified RPC name,
CLI/JSON parameter mapping, input/output type names, and both human and machine
examples.

There is no separate `describe` command in V1. Structured help hangs off the
same per-command `--help` surface that humans use.

## Repo Layout

- `proto/` contains `cmdproto`'s own option schema.
- `runtimes/runtime.ts` is the minimal TypeScript runtime implementation.
- `connect/` contains unary Connect registration, caller transport, Fetch, Bun,
  and Node host adapters, plus the package-owned dual-mode bootstrap.
- `examples/greeter/proto/` is a separate app proto, built as its own schema
  artifact.

## As A Dependency

A consumer can install this repo directly as a git dependency and import the
runtime as `cmdproto`.

For a local sibling consumer during development, a saved dependency like
`"cmdproto": "file:../.."` is usually the simplest path.

For a fresh repo setup from git, a direct install like this works too:

```sh
npm install "cmdproto@git+https://github.com/omar391/cmdproto.git"
```

After install, run:

```sh
cmdproto init
```

That bootstrap step creates a deterministic starter layout in the consumer repo:

- `buf.gen.yaml`
- `buf.yaml` by default
- `proto/.../*.proto`
- `package.json` scripts:
  - `cmdproto:gen`
  - `cmdproto:schema`

If the consumer repo is TypeScript, run:

```sh
cmdproto init --runtime ts
```

That also creates:

- `src/cmdproto/app.mts`
- `tsconfig.json` when missing
- `package.json` script:
  - `cmdproto:run`

To add an opt-in Fetch-compatible Connect handler template, run:

```sh
cmdproto init --runtime ts --connect
```

This also creates `src/cmdproto/connect.mts`. It does not bind a listener or
choose authentication, TLS, ports, or process lifecycle for the consumer.

`cmdproto-buf-plugin` and the internal `cmdproto-runtime-manifest` helper are
shipped as package-contained WASM-backed commands. Normal consumer workflows
should use `cmdproto build`, which wraps the common Buf generate/lint/build plus
runtime-manifest flow. Consumer machines do not need Go installed for schema
build and lint.

## Developer Checkout Installation

`cmdproto install` adds a small launcher for the checkout you are standing in.
It is a development convenience, not a release installer: the generated
launcher normally runs the sources from that checkout, so editing the checkout
changes the command, and a command-scoped environment variable can select
another worktree at runtime. Released packages keep using their own package
manager (`npm install`, `cargo install`, `go install`, and so on).

Run it from the cmdproto checkout to install cmdproto itself:

```sh
cmdproto install
```

Run it from a consumer checkout to install that consumer's CLI:

```sh
cmdproto install --cwd /path/to/consumer
```

A consumer declares how it should be launched:

```json
{
  "cmdproto": {
    "install": {
      "command": "tabgate",
      "runScript": "cmdproto:run",
      "sourceEnv": "TABGATE_WORKTREE"
    }
  }
}
```

`cmdproto init --runtime ts` writes `command` and `runScript` for you, using
the initialized app name and the generated `cmdproto:run` script. `sourceEnv`
is optional; omit it to use the command-derived default described below.

| Option | Meaning |
| --- | --- |
| `--cwd <dir>` | Directory used to find the checkout; the nearest `package.json` wins |
| `--name <command>` | Installed command name, overriding `cmdproto.install.command` |
| `--run-script <script>` | Package script to run, overriding `cmdproto.install.runScript` |
| `--source-env <variable>` | Source-checkout override variable, overriding `cmdproto.install.sourceEnv` |
| `--force` | Replace another checkout's launcher, or shadow a same-named command |

Launchers are written to `~/.local/bin` (`%USERPROFILE%\.local\bin` on
Windows). When that directory is not already on `PATH`, the command adds one
managed block for the detected shell: `~/.zshrc`, `~/.bashrc`,
`~/.config/fish/conf.d/cmdproto-path.fish`, or `~/.profile`. On Windows it
updates the user-level `Path`. The change applies to new shells, and the
result reports whether a new shell is required.

Consumer launchers run the configured script with `bun`, `npm`, `pnpm`, or
`yarn`, chosen from `packageManager` and defaulting to `npm`. The launcher
validates the checkout, the script, and the package manager before starting,
forwards arguments in order, and preserves the child's exit code and streams.
A missing checkout or script exits `66`; a missing package manager exits `127`.

At runtime, a launcher may use another worktree without being reinstalled. The
default override variable is the installed command in uppercase with every
non-alphanumeric character changed to `_`, followed by `_SRC` (`tabgate`
becomes `TABGATE_SRC`). For example:

```sh
git worktree add worktrees/fix-auth -b fix-auth
TABGATE_SRC="$PWD/worktrees/fix-auth" tabgate users list
```

Set `cmdproto.install.sourceEnv` or pass `--source-env` to choose another
variable name. An unset variable uses the checkout recorded at installation;
an invalid override fails with exit `66` and names the variable. The recorded
checkout remains the ownership identity used by install and uninstall.

Installation is careful with things it does not own. A file that cmdproto did
not write is never overwritten or removed, with or without `--force`; the same
is true for a symlink or a half-written Windows launcher pair. Replacing a
launcher owned by a different checkout, or shadowing a same-named command
already on `PATH`, requires `--force`. Reinstalling the same configuration
changes nothing and reports `unchanged`. On Windows, a same-bin executable
whose extension precedes `.CMD` in `PATHEXT` cannot be shadowed by the managed
launcher and is refused even with `--force`.

```sh
cmdproto uninstall
cmdproto uninstall --cwd /path/to/consumer --name tabgate
```

`uninstall` removes only launchers owned by the current checkout, so removing
one launcher reveals any same-named command that was previously shadowed. It
deliberately leaves the shared `PATH` configuration in place, because that
entry belongs to every launcher in the directory rather than to one command.

Both commands print one JSON object on success and, on failure, one JSON error
object on stderr with a stable code and an exit class: `2` for usage or
configuration problems, `3` for a safety refusal, and `4` for an environment
or filesystem failure.


## Authoring A New App

```proto
edition = "2024";

package greeter.v1;

import "cmdproto/v1/options.proto";

service GreeterService {
  rpc SayHello(SayHelloRequest) returns (SayHelloResponse) {
    option (cmdproto.v1.command) = {
      path: "greet"
      summary: "Render a greeting."
      alias: "hello"
      example: {
        command: "greet Ada -s"
        description: "Render a loud greeting."
        request_json: "{\"name\":\"Ada\",\"shout\":true}"
      }
    };
  }
}

message SayHelloRequest {
  string name = 1 [
    (cmdproto.v1.param) = {
      positional: { index: 1 }
      help: "Name to greet."
    }
  ];

  bool shout = 2 [
    (cmdproto.v1.param) = {
      flag: {
        long: "shout"
        short: "s"
      }
      help: "Uppercase the greeting."
    }
  ];
}

message SayHelloResponse {
  string message = 1;
}
```

Minimal TypeScript bootstrap:

```ts
import { runMain, type HandlerMap } from "cmdproto";

const handlers: HandlerMap = {
  "greeter.v1.GreeterService.SayHello"(params) {
    const message = `Hello, ${String(params.name ?? "")}!`;
    return {
      message: params.shout ? message.toUpperCase() : message
    };
  }
};

await runMain({ handlers });
```

## Lifecycle

1. Write your app proto and import `cmdproto/v1/options.proto`.
2. Lint and build a descriptor set, for example:

```sh
npm run cmdproto:schema
```

3. `buf lint` runs both Buf's built-in lint rules and the local `cmdproto`
   check plugin. That catches duplicate command paths, alias collisions,
   duplicate flags, reserved meta flags like `--help` and `--json`, invalid
   positional layouts, prefix-shadowing, and missing or malformed command
   examples during schema authoring.
4. Buf compiles your `.proto` files into `schema.binpb`, which is a protobuf
   `FileDescriptorSet`, and the shared compiler emits a normalized
   `runtime.binpb` manifest beside it.
5. `cmdproto` loads both artifacts at runtime. The manifest drives command
   routing, help output, and human CLI parsing; the descriptor set is only used
   for protobuf JSON validation and type reflection.
6. Register handlers and use the app through human commands, `--help`, or
   `cmdproto execjson <path> <json|@file|@->`.

`schema.binpb` and `runtime.binpb` are the compiled runtime artifacts that
`cmdproto` consumes. We do not read raw `.proto` text in the app process.
`dist/` is only the default location, not a hard requirement; for example,
`runMain({ handlers, schemaPath: "/some/other/schema.binpb", manifestPath: "/some/other/runtime.binpb" })`
works too.

## MCP tools and resources

The `cmdproto/mcp`, `cmdproto/mcp/http` and `cmdproto/mcp/stdio` exports use the
official MCP SDK. Tool names and input schemas come from the generated command
manifest, with no second tool registry. A command path such as `math add`
becomes `math.add`; dashes within a token become underscores. A successful tool
returns the same application JSON as CLI/execjson, without a success envelope.

Every server requires an explicit method allowlist and authorization callback.
An empty allowlist exposes nothing; only a literal `true` authorizes. HTTP additionally requires transport
authentication, which runs before initialization and runtime resolution. HTTP
uses a fresh request binding and stateless transport; no principal or grants
are cached in an MCP session. Hosts own credentials, origins, TLS and policy.

```ts
import { createCmdProtoMcpHttpServer } from "cmdproto/mcp/http";

const endpoint = createCmdProtoMcpHttpServer({
  info: { name: "app", version: "1" },
  runtime: request => createAppRuntimeForRequest(request),
  allowMethods: ["example.v1.AppService.Read"],
  authenticateRequest: request => authenticateCurrentRequest(request),
  createRequestContext: call => makeContext(call.httpRequest, call.signal),
  authorize: call => authorizeCurrentCommand(call),
});
// Mount endpoint.handleRequest on the host; close it during shutdown.
```

The callbacks above are consumer-owned functions. Invocation context receives
the actual HTTP request and cancellation signal; tool arguments cannot supply
a trusted principal. Protobuf validation precedes dispatch. The stdio/server
adapter carries SDK cancellation to that same context. In stateless HTTP,
request abort/transport close cancels that request; cancellation notifications
do not coordinate separate HTTP server instances. Applications may expose an
explicit cancellation command for durable work.

For MCP resources, set `resources: { list: LIST_METHOD, read: READ_METHOD }`.
Both methods must be annotated commands in the allowlist. The list method
accepts `{}` and returns the MCP `{ resources: [...] }` data shape; the read
method accepts `{ uri }` and returns `{ contents: [...] }`. Binary content uses
protobuf JSON's base64 representation. These are ordinary commands available
to CLI/execjson too, with identical authorization and output validation.

`createRuntimeFromBinary(handlers, schemaBytes, manifestBytes)` loads embedded
assets through the same descriptor-hash verification as file loading.
`describeCommands(runtime)` exposes the compiler-owned command metadata.
Neither API recompiles or reads raw proto source during application execution.

See `examples/mcp-consumer` for an independent, package-only CLI/MCP example.
Unexpected exceptions are redacted; network adapters expose only typed public
command errors. Close/cancelled response bodies release HTTP transports.

## Unary Connect Control Plane

Connect support is opt-in per consumer, but the server bootstrap is owned by
cmdproto. A consumer provides an explicit fully-qualified method allowlist, an
authorization callback, and one mount/lifecycle hook for its existing listener.
An empty allowlist exposes no routes, and cmdproto never exposes every
annotated command automatically.

```ts
import { createServer } from "node:http";
import { createCmdProtoBunNodeHandler } from "cmdproto/connect/bun";
import { createAppRuntime, METHOD_NAME } from "./src/cmdproto/app.mjs";

const connect = createCmdProtoBunNodeHandler({
  runtime: createAppRuntime(),
  allowMethods: [METHOD_NAME],
  singletonHeaders: ["x-capability"],
  createRequestContext(request) {
    return { capability: request.requestHeader.get("x-capability") };
  },
  authorize(request) {
    return request.requestContext.capability === process.env.CONTROL_CAPABILITY;
  }
});

const server = createServer(connect);
// The consumer may attach server.on("upgrade", ...) on this same authority.
server.listen(3000, "127.0.0.1");
```

`createCmdProtoBunNodeHandler()` is the production Bun choice when raw header
fidelity matters. It runs under Bun's `node:http` compatibility layer, rejects
duplicate auth, authority, origin, and protocol singleton headers before
authorization, accepts custom singleton header names, and leaves WebSocket
upgrade ownership with the same consumer-created server.
`createCmdProtoNodeHandler()` provides the same request listener for Node.

`createCmdProtoFetchHandler()` returns a standard Fetch handler.
`createCmdProtoBunHandler()` is a native `Bun.serve` compatibility/development
surface only: Bun currently normalizes duplicate non-cookie headers before the
handler can inspect them. Do not use it for a production control plane; use the
Bun-node adapter so authentication and capability headers retain raw fidelity.

### CLI-first dual mode

Consumers can expose the same handler map through a reserved package-owned
internal mode without adding a public `serve` command:

```ts
import { runMain } from "cmdproto";
import { createCmdProtoInternalServer } from "cmdproto/connect/bootstrap";

await runMain({
  handlers,
  internalServer: createCmdProtoInternalServer({
    allowMethods: [METHOD_NAME],
    authorize,
    mount: (handler) => appListener.mountConnect(handler)
  })
});
```

Services which already own their listener can provide `start(runtime)` instead
of the mount configuration; the two lifecycle forms are mutually exclusive.
Cmdproto still performs the reserved-mode dispatch and passes the descriptor-led
runtime to that lifecycle hook.

Native clients call `ensureCmdProtoServer({ readCapability, ... })`. If the
capability is absent, cmdproto starts the same executable with the reserved
`--cmdproto-internal-connect` argument and waits for the consumer's capability
to appear. Calls with the same explicit `lockKey`, or the same capability-reader
function when no key is supplied, share one in-process startup. Independent
readers remain independent, and a concurrent child that exits non-zero keeps
polling for the winning process's capability through the configured timeout.
Clean exits, signals, and spawn errors remain prompt failures. Existing
operational `start` commands can remain, but generated clients never need to
shell to them.

Remote CLI and `execjson` calls select methods explicitly. Methods not in
`remoteMethods` continue to execute in process:

```ts
import { createCmdProtoConnectTransport } from "cmdproto/connect";

const transport = createCmdProtoConnectTransport({
  remoteMethods: [METHOD_NAME],
  baseUrl: "http://127.0.0.1:3000",
  headers: { authorization: `Bearer ${process.env.CONTROL_TOKEN}` }
});

await runMain({ handlers, transport });
```

The canonical route is descriptor-derived:
`/<protobuf.package.Service>/<Method>`. Binary protobuf is the normative wire
format. Strict Connect JSON is available for diagnostics. Responses are the
declared protobuf response directly, without cmdproto result/stdout envelopes.
Typed cmdproto failures map to canonical Connect codes; JSON-compatible details
round-trip as `google.protobuf.Value` error details. Internal and unknown custom
`CmdProtoError` messages/details and untyped exceptions are not exposed. A
handler or interceptor that deliberately throws `ConnectError` is declaring a
public wire error and its message, metadata, and details pass through; never put
secrets in an explicit `ConnectError`.

There are no REST aliases, listeners, TLS lifecycle, auth lifecycle, streaming
RPCs, or automatic all-command exposure in this package.

### Connect conformance scope

The official `connectrpc/conformance` runner passes all 88 applicable unary
Connect HTTP/1, identity-compression, protobuf/JSON server cases for the Node,
Fetch, and production Bun-node adapters. The native `Bun.serve` Fetch host
passes 81/88; its seven excluded cases require duplicate request-header
preservation that Bun 1.3.14 removes before handler entry (Basic unary proto and
JSON, Duplicate Metadata success/error proto and JSON, and Server Empty Requests).

Streaming, Connect GET, compression, TLS, HTTP/2+, gRPC, and gRPC-Web cases are
outside this intentionally unary adapter contract.

Reproduce the matrix with `npm run test:connect-conformance`. The checked
fixture pins both the official conformance runner and the matching Connect-ES
conformance service by commit, downloads them into ignored `tmp/`, and asserts
the expected case totals. This slower network/Go/Bun check is intentionally not
part of `npm run check`.

In this repo specifically:

- `npm run schema:build` builds the library's own `proto/` schema to `dist/schema.binpb` and `dist/runtime.binpb`.
- `npm run schema:build:greeter` builds the example app schema to `examples/greeter/dist/schema.binpb` and `examples/greeter/dist/runtime.binpb`.
- `npm run example:greeter -- greet Ada -s` uses the example-owned schema file, not the root one.
- consumer repos do not need Go locally; the package ships the build-time
  helpers as WASM-backed commands
- this repo still uses Go to rebuild `dist/wasm/` and to run `npm run test:plugin`

The remaining transport roadmap is tracked in [future_plan.md](future_plan.md).

## Development

```sh
npm install
npm run check
npm run schema:build:greeter
npm run example:greeter -- greet Ada -s
npm run example:greeter -- greet --help
npm run example:greeter -- greet --help --json
npm run example:greeter -- cmdproto execjson greet '{"name":"Ada","shout":true}'
npm --prefix examples/greeter install
npm --prefix examples/greeter run check
```

### Launcher compatibility

Source-backed launchers run in both CommonJS and ESM package scopes. Exact older
managed templates remain recognizable and refresh on reinstall; a modified or
foreign file still cannot be overwritten. Package lookup stops at a nested Git
repository boundary, so installation never adopts an enclosing checkout by
accident. Use an explicit `--cwd` to select a different repository.

## Code mode

`cmdproto/code-mode` binds a compiled runtime, an explicit command allowlist,
current request policies, and a receipt store. Its two operations are catalog
search and bounded execution. The optional `cmdproto/mcp/code-mode` adapter
exposes only `catalog.search` and `code.execute`; it derives the request context
from the host, never from tool arguments.

Pass the body of an async JavaScript function to `code.execute`. For example,
`const a = await command("greet", {name: "Ada"}); return a.message;` uses the
same typed handler and result contract as CLI and Connect. The caller reuses
the same execution ID for an exact retry. Method and arguments are validated
from the descriptor before authorization. Each operation rechecks its own
grants on replay and again after reservation, before dispatch.

`cmdproto/code-mode/quickjs` runs the script in a fresh bounded QuickJS Wasm
context. The guest gets no filesystem, network, process, credentials, timers,
or scheduler. Run commands sequentially and await their promises. The engine
limits source and result size, command count, interpreter polls, pending jobs,
memory, and stack. Static-module hosts can supply the precompiled
`@jitl/quickjs-wasmfile-release-sync/wasm` asset to
`createQuickJsCodeModeEngine`.

Run the Workerd conformance probe against the exact tarball intended for
consumers. The probe installs it in a fresh directory and reports its SHA-256.
Set `CMDPROTO_MINIFLARE_MODULE` to the absolute entry path of the installed
Miniflare v5 module.

```sh
npm run test:code-mode-workerd -- /absolute/path/to/cmdproto-0.3.0.tgz
```

The host owns the authenticated receipt namespace and effects. It may bind an
explicit private SQLite connection using `cmdproto/code-mode/sqlite-receipts`.
Completed receipts replay the exact result; a missing acknowledgement leaves
a pending operation for the domain owner to reconcile. A batch is not a
transaction across multiple commands. Earlier admitted operations can
complete before a later operation is refused. Host handlers remain responsible
for their own cancellation and durable effects.

Authorization receives both `originalParams` (submitted JSON) and `params`
(descriptor-validated canonical values). Both are included in the receipt
fingerprint, so an explicit null cannot be replayed as an omission. A host
that can read an authoritative domain acknowledgement may use
`confirmCompleted` on its SQLite adapter to close a pending step without
running the effect again. Receipt confirmation does not authorize the read
or determine whether the observation is authoritative.
