#!/usr/bin/env bun

import { assertCanonicalBunApplicationRuntime } from "../src/application-runtime.mjs";

assertCanonicalBunApplicationRuntime("Secret manager daemon");

const { default: process } = await import("node:process");
const { configureSecretManager } = await import("../src/config.mjs");
const { runSecretBrokerDaemon } = await import("../src/lib/daemon/secret-server.mjs");

const args = process.argv.slice(2);
let appName = process.env.SECRET_MANAGER_APP_NAME || "secret-manager";
let stateRoot = null;
let socketPath = null;
let pidFile = null;

while (args.length > 0) {
  const token = args.shift();
  if (token === "--app-name") { appName = args.shift() || appName; continue; }
  if (token.startsWith("--app-name=")) { appName = token.slice("--app-name=".length) || appName; continue; }
  if (token === "--state-root") { stateRoot = args.shift() || null; continue; }
  if (token.startsWith("--state-root=")) { stateRoot = token.slice("--state-root=".length) || null; continue; }
  if (token === "--socket") { socketPath = args.shift() || null; continue; }
  if (token.startsWith("--socket=")) { socketPath = token.slice("--socket=".length) || null; continue; }
  if (token === "--pid-file") { pidFile = args.shift() || null; continue; }
  if (token.startsWith("--pid-file=")) { pidFile = token.slice("--pid-file=".length) || null; continue; }
  throw new Error(`Unknown secret broker option: ${token}`);
}

if (!socketPath) throw new Error("--socket is required");
configureSecretManager({ appName, stateRoot });
await runSecretBrokerDaemon({ socketPath, pidFile });
