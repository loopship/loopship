import { existsSync, realpathSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { CmdProtoError, createRuntimeFromFile, runMain } from "cmdproto";
import { configureSecretManager } from "../config.mjs";
import { executeHostCommand, executeItemCommand, executeSessionCommand, SecretCommandError } from "../commands.mjs";
import { assertCanonicalBunApplicationRuntime } from "../application-runtime.mjs";

const modulePath = fileURLToPath(import.meta.url);
const root = resolve(dirname(modulePath), "../..");
export const SECRET_MANAGER_SCHEMA_PATH = join(root, "dist/cmdproto/schema.binpb");
export const SECRET_MANAGER_MANIFEST_PATH = join(root, "dist/cmdproto/runtime.binpb");
export const SECRET_MANAGER_METHODS = Object.freeze({ session: "cueintent.secretmanager.v1.SecretManagerService.Session", item: "cueintent.secretmanager.v1.SecretManagerService.Item", host: "cueintent.secretmanager.v1.SecretManagerService.Host" });
export const handlers = {
  [SECRET_MANAGER_METHODS.session]: async (params) => executeSessionCommand(params),
  [SECRET_MANAGER_METHODS.item]: async (params) => executeItemCommand(params),
  [SECRET_MANAGER_METHODS.host]: async (params) => executeHostCommand(params),
};

export function createSecretManagerRuntime({ schemaPath = SECRET_MANAGER_SCHEMA_PATH, manifestPath = SECRET_MANAGER_MANIFEST_PATH, additionalHandlers = {} } = {}) {
  ensureAssets(schemaPath, manifestPath);
  return createRuntimeFromFile({ ...handlers, ...additionalHandlers }, schemaPath, manifestPath);
}

export async function runSecretManagerCmdprotoCli(argv = process.argv.slice(2), { schemaPath = SECRET_MANAGER_SCHEMA_PATH, manifestPath = SECRET_MANAGER_MANIFEST_PATH, stdin } = {}) {
  assertCanonicalBunApplicationRuntime("Secret manager cmdproto CLI");
  configureSecretManager({ appName: process.env.SECRET_MANAGER_APP_NAME || "secret-manager" });
  ensureAssets(schemaPath, manifestPath);
  return runMain({ handlers: wrapHandlers(), schemaPath, manifestPath, argv, stdin });
}

function wrapHandlers() { return Object.fromEntries(Object.entries(handlers).map(([method, handler]) => [method, async (params) => { try { return await handler(params); } catch (error) { if (error instanceof SecretCommandError) throw new CmdProtoError(error.code.toUpperCase().replace(/[^A-Z0-9]+/g, "_"), error.message); throw error; } }])); }
function ensureAssets(schemaPath, manifestPath) { const missing = [schemaPath, manifestPath].filter((entry) => !existsSync(entry)); if (missing.length) throw new Error(`Secret manager cmdproto assets are missing: ${missing.join(", ")}; run npm run cmdproto:schema`); }

if (process.argv[1] && realpathSync(resolve(process.argv[1])) === realpathSync(modulePath)) await runSecretManagerCmdprotoCli();
