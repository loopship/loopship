import {
  DEFAULT_SECRET_STORE,
  ensureLoginSecretRef,
  ensureSecretStoreReadyInteractive,
  enrollSecretStoreUnattended,
  clearSecretStoreEnrollment,
  ensureNamedSecretRef,
  captureSecureSecretItem,
  captureSecureLoginSecret,
  getSecretStoreStatusSummary,
  clearSecretStoreSession,
  findBrokerLoginSecretRef,
  resolveBrokerSecretLocator,
  resolveBrokerSecretRef,
  deleteBrokerSecretRef,
  normalizeSecretLocator,
  normalizeSecretRef,
} from "./index.mjs";
import { acceptHostCredentialImport, hostCredentialStatus, prepareHostCredentialImport, provisionHostCredentialImport } from "./lib/host/credential-provisioning.mjs";
import { migrateBrokerSecretStoreProfile } from "./lib/daemon/secret-client.mjs";

export async function executeSessionCommand({ action, store = DEFAULT_SECRET_STORE, noPromptIfLocked = false, replace = false, prompt } = {}) {
  try {
    if (!["status", "ensure", "clear", "enroll", "forget", "migrate"].includes(action)) throw new SecretCommandError("invalid-request", "session action must be status, ensure, clear, enroll, forget, or migrate");
    const result = action === "status"
      ? { secret_store: await getSecretStoreStatusSummary({ store }) }
      : action === "migrate"
        ? { migration: await runProfileMigration(store) }
      : action === "clear"
        ? (await clearSecretStoreSession({ store }), { secret_store: await getSecretStoreStatusSummary({ store }) })
        : action === "enroll"
          ? { enrollment: await enrollSecretStoreUnattended({ store, replace: replace === true, prompt, requireConfirmation: true }) }
          : action === "forget"
            ? (await clearSecretStoreEnrollment({ store }), { secret_store: await getSecretStoreStatusSummary({ store }) })
        : { secret_store: await ensureSecretStoreReadyInteractive({ store, promptIfLocked: noPromptIfLocked !== true, prompt }) };
    return { schemaVersion: "secret-manager/session-response/v1", action, store, result: camelizeValue(result) };
  } catch (error) {
    throw asSessionCommandError(error);
  }
}

async function runProfileMigration(store) {
  const response = await migrateBrokerSecretStoreProfile({ store });
  if (!response?.ok) throw new SecretCommandError(response?.error?.code || "secret-operation-failed", response?.error?.message || "Bitwarden profile migration failed.");
  return response.migration || { migrated: false };
}

export async function executeItemCommand({ action, payload } = {}) {
  if (!["resolve", "ensure", "delete", "capture"].includes(action)) throw new SecretCommandError("invalid-request", "item action must be resolve, ensure, delete, or capture");
  const body = payload && typeof payload === "object" && !Array.isArray(payload) ? payload : {};
  if (action === "resolve") {
    const selector = body.selector && typeof body.selector === "object" ? body.selector : body;
    if (selector.kind === "login") {
      const response = await findBrokerLoginSecretRef({ store: selector.store || DEFAULT_SECRET_STORE, username: requireString(selector.username, "item resolve login requires username"), uris: requireUris(selector.uris, "item resolve login requires uris") });
      if (!response?.ok) throw brokerError(response, "Failed to resolve login secret ref.");
      return itemResponse(action, { ref: normalizePublicRef(response.ref) });
    }
    if (selector.kind === "locator") {
      const locator = selector.locator;
      if (!locator) throw new SecretCommandError("invalid-request", "item resolve locator requires locator");
      const response = await resolveBrokerSecretLocator({ locator: normalizeSecretLocator(locator), context: selector.context || {} });
      if (!response?.ok) throw brokerError(response, "Failed to resolve secret locator.");
      return itemResponse(action, response.result || response);
    }
    if (selector.kind === "ref") {
      const response = await resolveBrokerSecretRef({ ref: normalizeSecretRef(selector.ref), context: selector.context || {} });
      if (!response?.ok) throw brokerError(response, "Failed to resolve secret ref.");
      return itemResponse(action, response.result || response);
    }
    throw new SecretCommandError("invalid-request", 'item resolve requires selector kind "login", "locator", or "ref".');
  }
  if (action === "ensure") {
    if (body.kind === "named_secret") {
      const ref = await ensureNamedSecretRef({ store: body.store || DEFAULT_SECRET_STORE, name: requireString(body.name, "item ensure requires name"), value: requireString(body.value, "item ensure requires value"), notes: body.notes ?? null, replace: body.replace === true });
      return itemResponse(action, { ref: normalizePublicRef(ref) });
    }
    if (body.kind !== "login") throw new SecretCommandError("invalid-request", 'item ensure supports kind "login" or "named_secret".');
    const ref = await ensureLoginSecretRef({ store: body.store || DEFAULT_SECRET_STORE, name: requireString(body.name, "item ensure requires name"), username: requireString(body.username, "item ensure requires username"), password: requireString(body.password, "item ensure requires password"), notes: body.notes ?? null, uris: requireUris(body.uris, "item ensure requires uris") });
    return itemResponse(action, { ref: normalizePublicRef(ref) });
  }
  if (action === "capture") {
    if (body.kind === "login" || body.username !== undefined) {
      const ref = await captureSecureLoginSecret({ store: body.store || DEFAULT_SECRET_STORE, name: requireString(body.name, "item capture login requires name"), username: requireString(body.username, "item capture login requires username"), uris: requireUris(body.uris, "item capture login requires uris"), password: body.password });
      return itemResponse(action, { ref: normalizePublicRef(ref) });
    }
    const ref = body.ref && typeof body.ref === "object" ? body.ref : body;
    const objectId = requireString(ref.objectId ?? ref.object_id, "item capture requires objectId");
    const fieldPath = typeof (ref.fieldPath ?? ref.field_path) === "string" ? (ref.fieldPath ?? ref.field_path) : "/password";
    const capturedRef = await captureSecureSecretItem({ store: ref.store || DEFAULT_SECRET_STORE, objectId, fieldPath });
    return itemResponse(action, { ref: normalizePublicRef(capturedRef) });
  }
  const ref = await deleteBrokerSecretRef({ ref: normalizeSecretRef({ type: "secret_ref", store: body.store || DEFAULT_SECRET_STORE, object_id: requireString(body.objectId ?? body.object_id, "item delete requires objectId") }) });
  if (!ref?.ok) throw brokerError(ref, "Failed to delete secret ref.");
  return itemResponse(action, { deleted: true, ...(ref.ref ? { ref: normalizePublicRef(ref.ref) } : {}) });
}

export async function executeHostCommand({ action, payload } = {}) {
  const input = payload && typeof payload === "object" && !Array.isArray(payload) ? payload : {};
  if (Object.hasOwn(input, "now")) throw new SecretCommandError("invalid-request", "host operation clocks are controlled by the host.");
  if (action === "prepare") return hostResponse(action, await prepareHostCredentialImport(input));
  if (action === "provision") return hostResponse(action, await provisionHostCredentialImport(input));
  if (action === "accept") return hostResponse(action, await acceptHostCredentialImport(input));
  if (action === "status") return hostResponse(action, hostCredentialStatus(input));
  throw new SecretCommandError("invalid-request", "host action must be prepare, provision, accept, or status");
}

export class SecretCommandError extends Error {
  constructor(code, message) { super(message); this.name = "SecretCommandError"; this.code = code; }
}

function asSessionCommandError(error) {
  if (error instanceof SecretCommandError) return error;
  if (error && typeof error === "object" && typeof error.code === "string" && /^[A-Z][A-Z0-9_-]*$/u.test(error.code)) {
    return new SecretCommandError(error.code, error.message || "Secret-store session operation failed.");
  }
  return error;
}

function itemResponse(action, result) { return { schemaVersion: "secret-manager/item-response/v1", action, result: camelizeValue(result) }; }
function hostResponse(action, result) { return { schemaVersion: "secret-manager/host-response/v1", action, result: camelizeValue(result) }; }
function requireString(value, message) { const normalized = typeof value === "string" ? value.trim() : ""; if (!normalized) throw new SecretCommandError("invalid-request", message); return normalized; }
function requireUris(value, message) { if (!Array.isArray(value) || value.length === 0 || value.some((entry) => typeof entry !== "string" || !entry.trim())) throw new SecretCommandError("invalid-request", message); return value.map((entry) => entry.trim()); }
function normalizePublicRef(ref) { const value = normalizeSecretRef(ref); return { type: value.type, store: value.store, objectId: value.object_id, ...(value.field_path ? { fieldPath: value.field_path } : {}) }; }
function brokerError(response, fallback) { return new SecretCommandError("secret-operation-failed", response?.error?.message || fallback); }
function camelizeValue(value) { if (Array.isArray(value)) return value.map(camelizeValue); if (!value || typeof value !== "object") return value; return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase()), camelizeValue(entry)])); }
