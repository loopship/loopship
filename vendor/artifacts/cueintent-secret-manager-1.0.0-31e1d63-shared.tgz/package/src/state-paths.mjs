import crypto from "node:crypto";
import os from "node:os";
import path from "node:path";
import { getSecretManagerConfig, readSecretManagerEnv, deriveSecretManagerStateDirName, deriveSecretManagerDaemonShortPrefix } from "./config.mjs";

const UNIX_DAEMON_PATH_LIMIT = 104;
const DAEMON_SOCKET_PATH_BUFFER = 48;

export function resolveGlobalStateRoot() {
  return getSecretManagerConfig().globalStateRoot;
}

export function resolveSharedGlobalStateRoot() {
  // An explicit stateRoot is authoritative, including in detached daemon
  // processes that inherit a parent-home override from their launcher.
  if (getSecretManagerConfig().stateRootExplicit) {
    return resolveGlobalStateRoot();
  }
  const parentHome = resolveParentHomeOverride();
  return parentHome ? path.join(parentHome, deriveSecretManagerStateDirName()) : resolveGlobalStateRoot();
}

export function resolveParentHomeOverride() {
  const config = getSecretManagerConfig();
  for (const candidate of [process.env[`${config.envPrefix}_PARENT_HOME`], process.env.CODEX_ROTATE_REAL_HOME]) {
    if (typeof candidate === "string" && candidate.trim()) return path.resolve(candidate.trim());
  }
  return null;
}

export function resolveGlobalDaemonDir(globalStateRoot = resolveGlobalStateRoot()) {
  const config = getSecretManagerConfig();
  const override = readSecretManagerEnv("DAEMON_DIR");
  if (override?.trim()) return override.trim();
  const defaultDir = path.join(globalStateRoot, "daemon");
  if (process.platform !== "win32" && defaultDir.length + DAEMON_SOCKET_PATH_BUFFER > UNIX_DAEMON_PATH_LIMIT) {
    const hash = crypto.createHash("sha1").update(globalStateRoot).digest("hex").slice(0, 12);
    return path.join(os.tmpdir(), `${deriveSecretManagerDaemonShortPrefix(config)}-${hash}`);
  }
  return defaultDir;
}
