export interface SecretRef {
  type: "secret_ref";
  store: string;
  object_id: string;
  field_path: string | null;
}

export interface SecretLocator {
  kind: "login_lookup" | "named_secret" | "env_var" | "secret_ref";
  store?: string;
  username?: string;
  uris?: string[];
  name?: string;
  object_id?: string;
  field_path?: string | null;
}

export interface SecretResolution {
  payload: unknown;
  metadata?: Record<string, unknown>;
}

export interface SecretBrokerMetadata {
  presence: "present" | "absent" | "unknown";
  source: string;
  authoritative?: boolean;
  reason?: string;
  cached_until?: string;
}

export interface SecretBrokerMetadataResponse {
  ok: boolean;
  pid?: number;
  startedAt?: string;
  buildId?: string;
  secret_store?: Record<string, unknown>;
  runtime?: { supported: boolean; version?: string; reason?: string };
  metadata?: SecretBrokerMetadata;
  diagnostics?: Record<string, unknown>;
}

export interface HostCredentialOperation {
  kind?: "bitwarden-enrollment-v1";
  account?: { email: string; serverUrl: string };
  operationId: string;
  hostId: string;
  hostIdentity: string;
  recipient: string;
  approvedBindings: string[];
  createdAt: string;
  expiresAt: string;
  state: "prepared" | "accepting" | "complete";
}

export interface HostCredentialReceipt {
  version: 1;
  kind?: "bitwarden-enrollment-v1";
  operationId: string;
  hostId: string;
  acceptedAt: string;
  bindings: string[];
  state: "complete";
}

export interface BitwardenEnrollmentPromptDetails {
  field: "email" | "clientId" | "clientSecret" | "masterPassword" | "confirmation";
  type?: "confirmation";
  label: string;
  secret: boolean;
  message?: string;
  account?: string;
  provider?: "Bitwarden";
  scope?: string;
  persistence?: string;
  productName?: string;
}

export interface BitwardenCliStream {
  on(event: "data", listener: (chunk: string | Uint8Array) => void): this;
  on(event: "error", listener: (error: Error) => void): this;
}

export interface BitwardenCliWritableStream {
  write(chunk: string | Uint8Array): boolean;
  end(): void;
}

export interface BitwardenCliChildProcess {
  readonly pid?: number;
  readonly stdin: BitwardenCliWritableStream | null;
  readonly stdout: BitwardenCliStream | null;
  readonly stderr: BitwardenCliStream | null;
  kill(signal?: string): boolean;
  on(event: "close" | "exit", listener: (code: number | null, signal: string | null) => void): this;
  on(event: "error", listener: (error: Error) => void): this;
  once(event: "close" | "exit", listener: (code: number | null, signal: string | null) => void): this;
  once(event: "error", listener: (error: Error) => void): this;
}

export type BitwardenEnrollmentPrompt =
  ((details: BitwardenEnrollmentPromptDetails) => string | boolean | Promise<string | boolean>) |
  {
    confirm?: boolean | ((details: BitwardenEnrollmentPromptDetails) => string | boolean | Promise<string | boolean>);
    confirmation?: boolean | ((details: BitwardenEnrollmentPromptDetails) => string | boolean | Promise<string | boolean>);
    ask?: (details: BitwardenEnrollmentPromptDetails) => string | boolean | Promise<string | boolean>;
    [field: string]: unknown;
  };

export declare const DEFAULT_SECRET_STORE: string;
export declare function configureSecretManager(options?: {
  appName?: string;
  productName?: string;
  stateRoot?: string | null;
  envPrefix?: string | null;
}): Readonly<Record<string, unknown>>;
export declare function resetSecretManager(): Readonly<Record<string, unknown>>;
export declare function getSecretManagerConfig(): Readonly<Record<string, unknown>>;
export declare function normalizeSecretRef(ref: unknown, options?: Record<string, unknown>): SecretRef;
export declare function normalizeSecretLocator(locator: unknown, options?: Record<string, unknown>): SecretLocator;
export declare function isSecretRefValue(value: unknown): boolean;
export declare function isSecretLocatorValue(value: unknown): boolean;
export declare function resolveSecretRef(ref: unknown, context?: Record<string, unknown>): Promise<SecretResolution>;
export declare function resolveSecretLocator(locator: unknown, context?: Record<string, unknown>): Promise<SecretResolution>;
export declare function getSecretStoreStatusSummary(options?: Record<string, unknown>): Promise<Record<string, unknown>>;
export declare function getBrokerSecretMetadata(options?: { store?: string; locator?: SecretLocator }): Promise<SecretBrokerMetadataResponse>;
export declare function getBrokerSecretStoreStatus(options?: { store?: string; readOnly?: boolean }): Promise<Record<string, unknown>>;
export declare function activateSecretStoreSession(options?: Record<string, unknown>): Promise<Record<string, unknown> | null>;
export declare function clearSecretStoreSession(options?: Record<string, unknown>): Promise<void>;
export declare function ensureLoginSecretRef(options?: Record<string, unknown>): Promise<SecretRef>;
export declare function enrollSecretStoreUnattended(options?: Record<string, unknown>): Promise<Record<string, unknown> | null>;
export declare function collectBitwardenEnrollmentCredentials(options?: {
  email?: string;
  apiKey?: unknown;
  clientId?: string;
  clientSecret?: string;
  masterPassword?: string;
  prompt?: BitwardenEnrollmentPrompt;
}): Promise<{ email: string; clientId: string; clientSecret: string; masterPassword: string }>;
export declare function prepareBitwardenEnrollmentCredentials(options?: {
  email?: string;
  apiKey?: unknown;
  clientId?: string;
  clientSecret?: string;
  masterPassword?: string;
  prompt?: BitwardenEnrollmentPrompt;
  requireConfirmation?: boolean;
}): Promise<{ email: string; clientId: string; clientSecret: string; masterPassword: string }>;
export declare function confirmBitwardenEnrollment(options: { email: string; prompt?: BitwardenEnrollmentPrompt }): Promise<true>;
export declare function clearSecretStoreEnrollment(options?: Record<string, unknown>): Promise<void>;
export declare function migrateSecretStoreProfile(options?: { store?: string }): Promise<Record<string, unknown>>;
export declare function finalizeBitwardenProfileMigration(options?: { store?: string }): Promise<Record<string, unknown>>;
export declare function spawnBitwardenCli(
  args: string[],
  options?: { cwd?: string; stdio?: "pipe" | "ignore" | "inherit" | Array<"pipe" | "ignore" | "inherit"> },
): BitwardenCliChildProcess;
export declare function ensureNamedSecretRef(options?: Record<string, unknown>): Promise<SecretRef>;
export declare function captureBitwardenCliItem(options?: Record<string, unknown>): Promise<SecretRef>;
export declare function captureSecureSecretItem(options?: Record<string, unknown>): Promise<SecretRef>;
export declare function captureSecureLoginSecret(options?: Record<string, unknown>): Promise<SecretRef>;
export declare function assertSecretStoreReady(options?: Record<string, unknown>): Promise<void>;
export declare function ensureSecretStoreReadyInteractive(options?: {
  store?: string;
  promptIfLocked?: boolean;
  prompt?: BitwardenEnrollmentPrompt;
}): Promise<Record<string, unknown>>;
export declare function inspectHostCredentialStore(): {
  backend: "macos-keychain" | "secret-service";
  available: boolean;
  unlocked: boolean;
  bitwardenProfile: { supported: boolean; reason?: string; version?: string; cliSha256?: string; adapterSha256?: string; entry?: string; node?: string; adapterPath?: string };
  age: { available: boolean; age: Record<string, string> | null; ageKeygen: Record<string, string> | null };
};
export declare function prepareHostCredentialImport(options: {
  hostId: string;
  bindings: string[];
  kind?: "bitwarden-enrollment-v1";
  account?: { email: string; serverUrl: string };
}): Promise<HostCredentialOperation>;
export declare function provisionHostCredentialImport(options: {
  prepared: HostCredentialOperation;
  bindings: Array<{ name: string; ref: SecretRef | { store: string; objectId: string; fieldPath?: string | null } }>;
}): Promise<{ operationId: string; hostId: string; kind?: "bitwarden-enrollment-v1"; expiresAt: string; bindings: string[]; envelope: string }>;
export declare function acceptHostCredentialImport(options: {
  operationId: string;
  hostId: string;
  envelope: string;
}): Promise<HostCredentialReceipt>;
export declare function hostCredentialStatus(options?: { operationId?: string }): Record<string, unknown>;
export declare function readHostCredential(binding: string): string;
/** Internal consumption only: never serialize the result. */
export declare function resolveHostCredential(binding: string): Promise<string>;
