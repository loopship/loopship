import { accessSync, constants } from "node:fs";
import { delimiter, join } from "node:path";

export const BUN_RUNTIME_REQUIRED_ERROR_CODE = "SECRET_MANAGER_BUN_RUNTIME_REQUIRED";

export function assertCanonicalBunApplicationRuntime(component = "secret-manager application entrypoint") {
  if (process.versions?.bun) return process.execPath;
  const error = new Error(`${BUN_RUNTIME_REQUIRED_ERROR_CODE}: ${component} requires Bun as its canonical application runtime.`);
  error.code = BUN_RUNTIME_REQUIRED_ERROR_CODE;
  throw error;
}

export function resolveCanonicalBunExecutable() {
  const executableName = process.platform === "win32" ? "bun.exe" : "bun";
  const candidates = new Set(process.versions?.bun ? [process.execPath] : []);
  for (const directory of String(process.env.PATH || "").split(delimiter)) if (directory) candidates.add(join(directory, executableName));
  for (const candidate of candidates) {
    try { accessSync(candidate, constants.X_OK); return candidate; } catch { /* keep looking */ }
  }
  throw new Error("secret-manager daemons require an executable Bun runtime on PATH.");
}
