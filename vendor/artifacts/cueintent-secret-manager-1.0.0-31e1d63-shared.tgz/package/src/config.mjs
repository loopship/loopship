import os from "node:os";
import path from "node:path";

const DEFAULT_APP_NAME = process.env.SECRET_MANAGER_APP_NAME || "secret-manager";
const resetHooks = new Set();
let activeConfig = deriveSecretManagerConfig(DEFAULT_APP_NAME);

export function configureSecretManager({
  appName = activeConfig.appName,
  productName = null,
  stateRoot = null,
  envPrefix = null,
} = {}) {
  activeConfig = deriveSecretManagerConfig(appName, {
    productName,
    stateRoot,
    envPrefix,
  });
  for (const reset of resetHooks) reset();
  return activeConfig;
}

export function resetSecretManager() {
  activeConfig = deriveSecretManagerConfig(DEFAULT_APP_NAME);
  for (const reset of resetHooks) reset();
  return activeConfig;
}

export function getSecretManagerConfig() {
  return activeConfig;
}

export function registerSecretManagerResetHook(reset) {
  if (typeof reset !== "function") throw new TypeError("reset must be a function");
  resetHooks.add(reset);
  return () => resetHooks.delete(reset);
}

export function getSecretManagerEnvName(suffix) {
  return `${activeConfig.envPrefix}_${String(suffix || "").trim().replace(/^_+/, "")}`;
}

export function readSecretManagerEnv(suffix) {
  return process.env[getSecretManagerEnvName(suffix)];
}

export function deriveSecretManagerConfig(appName = DEFAULT_APP_NAME, options = {}) {
  const normalizedAppName = normalizeAppName(appName);
  const appSlug = slugifyAppName(normalizedAppName);
  const derivedPrefix = appSlug.toUpperCase().replace(/[^A-Z0-9]+/g, "_");
  const normalizedPrefix = String(options.envPrefix || derivedPrefix).trim().replace(/[^A-Za-z0-9_]+/g, "_").toUpperCase();
  const homeEnvName = `${normalizedPrefix}_HOME`;
  const configuredHome = options.stateRoot || process.env[homeEnvName];
  if (configuredHome && !path.isAbsolute(configuredHome)) {
    throw new TypeError(`${homeEnvName} must be an absolute path`);
  }
  const globalStateRoot = path.resolve(configuredHome || path.join(os.homedir(), `.${appSlug}`));
  return Object.freeze({
    appName: normalizedAppName,
    appSlug,
    productName: String(options.productName || appSlug).trim() || appSlug,
    envPrefix: normalizedPrefix,
    homeEnvName,
    stateRootExplicit: Boolean(options.stateRoot),
    daemonDirEnvName: `${normalizedPrefix}_DAEMON_DIR`,
    globalStateRoot,
  });
}

function normalizeAppName(value) {
  const normalized = String(value || "").trim();
  if (!normalized) throw new Error("secret-manager appName must be a non-empty string.");
  return normalized;
}

function slugifyAppName(value) {
  const slug = normalizeAppName(value).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  if (!slug) throw new Error("secret-manager appName must include at least one letter or number.");
  return slug;
}

export function deriveSecretManagerStateDirName(config = activeConfig) {
  return `.${config.appSlug}`;
}

export function deriveSecretManagerDaemonShortPrefix(config = activeConfig) {
  const parts = config.appSlug.split("-").filter(Boolean);
  const base = parts.length > 1 ? parts.map((part) => part[0]).join("") : config.appSlug.slice(0, 3);
  return `${base || "smd"}d`;
}
