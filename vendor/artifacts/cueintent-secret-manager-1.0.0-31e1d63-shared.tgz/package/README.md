# `@cueintent/secret-manager`

Reusable CueIntent secret contracts, Bitwarden CLI integration, app-scoped
session persistence, and the local secret broker.

The package exposes a library for embedding in applications and a standalone
cmdproto CLI:

```bash
secret-manager session status --store bitwarden-cli
secret-manager item resolve --json @payload.json
```

Library consumers should call `configureSecretManager({ appName })` before
resolving secrets. State is app-scoped by default, preserving separate broker
sockets and session namespaces for each consuming application.

When working from source, initialize the repository recursively so generated
cmdproto assets and runtime sources are present:

```bash
git clone --recurse-submodules https://github.com/cueintent/secret-manager.git
```

Resolved secret values stay in memory. Use stdin or `@file` payloads for secret
input rather than plaintext command arguments.

## Use as a Git submodule

Consumers that need a source-level dependency can pin Secret Manager as a
submodule and install it from that checked-out tree:

```bash
git submodule add -b main https://github.com/cueintent/secret-manager.git vendor/secret-manager
git submodule update --init --recursive
npm --prefix vendor/secret-manager ci
npm --prefix vendor/secret-manager run test
npm --prefix vendor/secret-manager run test:types
npm --prefix vendor/secret-manager run proto:check
npm --prefix vendor/secret-manager run cmdproto:assets:check
npm install --save ./vendor/secret-manager
```

The `npm install` command records a local `file:` dependency in the consumer,
so import the package normally and configure an app-scoped name at startup:

```js
import { configureSecretManager } from "@cueintent/secret-manager";

configureSecretManager({ appName: "my-app" });
```

For reproducible releases, commit the submodule at a reviewed commit and commit
the consumer's updated package manifest and lockfile. To deliberately follow
Secret Manager `main` during development, update the submodule explicitly:

```bash
git -C vendor/secret-manager fetch origin main
git -C vendor/secret-manager checkout main
git -C vendor/secret-manager pull --ff-only origin main
npm install --save ./vendor/secret-manager
```

After cloning a consumer, run `git submodule update --init --recursive` before
installing dependencies. Keep the submodule's generated assets and lockfile
under review; do not replace the dependency with a dirty worktree or copy
credentials into the repository. Secret Manager continues to keep enrollment
credentials in macOS Keychain and app sessions in each consumer's own state
namespace.

## Local secret broker deadlines and metadata

Broker requests carry the caller's transport deadline. Queued admission and
every blocking Bitwarden phase are capped by the remaining caller window, so
producer work can no longer outlive a shorter caller deadline. Requests that
cannot finish return a bounded `deadline_expiry` outcome with the
`SECRET_BROKER_DEADLINE_EXPIRED` code while the connection is still alive,
instead of dying silently at the caller's socket timeout. Client disconnects
and explicit cancellation still abort owned CLI child work immediately, and the
next request proceeds on a free queue. `cancelled`, `queue_timeout`,
`deadline_expiry`, runtime-unsupported, and ordinary failures stay distinct
diagnostic outcomes.

The `secret_metadata` broker method (client wrapper:
`getBrokerSecretMetadata({ store, locator })`) answers broker responsiveness,
read-only store state, runtime support, and named-secret presence without
resolving anything. It never syncs, reads items, fetches payloads, or echoes
the query: responses contain no secret names, item IDs, values, raw CLI
output, or locator reflections. Presence is `present`, `absent`, or
`unknown`. Only safe, already-verified sources answer: `env_var` presence is
authoritative from the process environment, and a recently resolved locator
can report `present` from the broker's resolution cache with its expiry
timestamp. Absence for vault secrets is never guessed, because no complete
authoritative metadata source exists without a sync or item read; those cases
return `unknown` with `reason: "no_safe_authoritative_metadata_source"`. A
responsive broker, an unlocked store, and a supported runtime are independent
facts: none of them alone implies that a specific credential exists, is
usable, or is present.

## Bitwarden enrollment

Run `secret-manager session ensure` interactively on first use. When the
managed app profile is unauthenticated, Secret Manager asks for the Bitwarden
account email, confirms the all-CueIntent-apps-on-this-Mac scope, and captures
the personal API client ID, client secret, and master password through hidden
native or terminal prompts. The values are validated with `bw login --apikey`
and `bw unlock`, then stored in macOS Keychain. The API key is not created or
displayed by this package; retrieve it from **Bitwarden Web Vault → Settings →
Security → Keys → View API key**.

The enrollment is shared by CueIntent applications on this Mac, while each
application retains its own managed Bitwarden CLI profile and session record.
It remains until `session forget` or `session enroll --replace`. Use
`session enroll` for deliberate setup and `session enroll --replace` after
rotating credentials. Invalid credentials fail closed and require replace or
forget. Enrollment refuses to overwrite an existing record unless
`--replace` is supplied; replacement validates the new credentials first and
keeps the previous enrollment on failure. `session forget` removes only the
shared enrollment; app-scoped CLI profiles and session records are managed
separately and remain until their own session/profile cleanup. An already
authenticated app reuses its saved Keychain/Secret Service session. If that
session has expired, Secret Manager recovers it through the existing shared
enrollment without asking for the master password again.
`--no-prompt-if-locked` suppresses unlock and first-use enrollment UI while
still permitting that noninteractive enrolled recovery. Interactive status and
ensure reuse enrolled credentials when no UI is needed; read-only status
inspection remains passive.

Profiles created by older releases can still contain Bitwarden state in the
managed `data.json` file. Status and ensure report those profiles as requiring
migration and leave them untouched. Run `session migrate` to stage the legacy
database into the host secure store, verify its account, server, and session,
and replace the disk database with an empty read-only marker. Migration is
repeatable, serialized with enrollment and profile operations, and retains
rollback material in secure storage until the secure profile is verified.

If a legacy enrollment item from an older release keeps requesting the login
keychain password, run `session forget` once and then repeat `session ensure`.
The managed Keychain identity is reused thereafter, so routine status and
session checks do not rewrite the item or request another authorization.

The ambient Bitwarden CLI profile is never reused. Existing Duo/WebAuthn
protection remains enabled; API-key login is used because this CLI path does
not support those interactive factors. Never place API credentials or the
master password in command arguments, shell exports, chat, logs, clipboard,
or files. The native Keychain helper is installed as the stable
`cueintent-secret-manager-keychain-helper` identity, and concurrent CueIntent
enrollment attempts are serialized so one confirmation and one Keychain write
serve every app on the Mac.


## Host-local Bitwarden enrollment

The existing `host prepare` / `host provision` / `host accept` flow accepts
`kind: "bitwarden-enrollment-v1"`, exact `account: {email, serverUrl}` metadata,
and an approved binding-name list. Provision supplies exact Bitwarden item IDs
and JSON Pointer fields for those bindings. Existing selective imports remain
supported when `kind` is omitted.

The source broker reads its enrollment internally. Only standard age armor and
public request metadata cross the explicitly authorized Codex relay. Never put
plaintext credentials, sessions, private keys, or ciphertext in repository files,
logs, task artifacts or receipts. Real enrollment follows managed landing and
activation and a successful synthetic relay/native-decryption test.

Enrollment, sessions and imports share the host-local storage boundary: existing
Keychain identities on macOS and configured Secret Service on Linux. Linux needs
an accessible, unlocked provider in the actual noninteractive environment;
there is no file fallback. The destination validates a fresh isolated CLI profile,
API login, unlock, account and server, then persists a new local session. Pending
imports are blocked; identical completed retries return metadata receipts.

Enrolling a personal account gives the host access to that account's entire vault.
Binding restrictions apply to manager consumers, not the underlying account, and
do not provide independent host revocation. Do not transfer the source session,
Bitwarden profile, GitHub/Git/SSH or Codex authentication state.

GitHub and Git wrappers resolve enrolled bindings through the local broker at
runtime. They retain process-scoped authentication and the protected credential
helper flow. whichllm additionally needs a supported credential input; a public
AA snapshot or local Codex catalog does not prove AA authentication.

New host enrollment requires the manager's audited secure-profile runtime for
`bw 2026.9.1` or `2026.10.0`, with each runtime's Node requirement enforced.
Its process-local Lowdb adapter writes the CLI authentication and refresh state
to Keychain/Secret Service, leaving only an empty, read-only `data.json` marker.
CLI, adapter, storage, and lock package hashes are checked before execution.
This is a manager adapter, not a native Bitwarden secure-storage feature.
Unsupported or tampered builds, nonempty disk profiles, unsafe profile paths,
and locked stores stop import without a plaintext fallback. Expired pending
imports remove their secure profile record. Existing legacy profiles are
migrated only by an explicit `session migrate`; status and ensure never erase
or migrate them automatically.
